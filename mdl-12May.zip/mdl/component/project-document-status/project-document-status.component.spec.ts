import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectDocumentStatusComponent } from './project-document-status.component';

describe('ProjectDocumentStatusComponent', () => {
  let component: ProjectDocumentStatusComponent;
  let fixture: ComponentFixture<ProjectDocumentStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectDocumentStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectDocumentStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
