import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-document-status',
  templateUrl: './project-document-status.component.html',
  styleUrls: ['./project-document-status.component.scss']
})
export class ProjectDocumentStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
