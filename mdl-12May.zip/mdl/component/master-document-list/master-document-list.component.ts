import { Component, OnInit, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { MatOptionSelectionChange } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IPost } from '../../../../interfaces';
import { map, startWith } from 'rxjs/operators';
import { MatDialog } from '@angular/material';
import { RootStoreState, MdlStoreActions, MdlStoreSelectors } from '../../../../root-store';

//services
import { TranslateService } from '@ngx-translate/core';

//component
import { SharedComponent } from './../../../../shared/component/shared/shared.component';
import { MdlHistoryModalComponent } from '../../modals/mdl-history-modal/mdl-history-modal.component';
import { SaveViewModalComponent } from '../../modals/save-view-modal/save-view-modal.component';
import { ReplanNotesComponent } from '../../modals/replan-notes/replan-notes.component';
import { PublishReviseComponent } from '../../modals/publish-revise/publish-revise.component';
import { MdlEditDocModalComponent } from '../../modals/mdl-edit-doc-modal/mdl-edit-doc-modal.component';

import { ThemePalette } from '@angular/material/core';
import { MdePopoverTrigger } from '@material-extended/mde';

export interface PeriodicElement {
  actionId: number;
  docNo: number;
  suezNo: number;
  status: string;
  description: string;
  isEdit: boolean;
  isDeleted: boolean;
}
export interface SuezNoInt {
  suezNo: any;
  isSelected: boolean;
}
export interface DocNoInterface {
  docNo: string;
  isSelected: boolean;
}

@Component({
  selector: 'app-master-document-list',
  templateUrl: './master-document-list.component.html',
  styleUrls: ['./master-document-list.component.scss']
})

export class MasterDocumentListComponent extends SharedComponent implements OnInit {
  @ViewChildren(MdePopoverTrigger) trigger: QueryList<MdePopoverTrigger>;
  result$: Observable<IPost[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;
  isLoggedIn: boolean = true;
  displayedColumns = ['select', 'docNo', 'suezNo', 'status', 'description', 'actionId'];

  ELEMENT_DATA: PeriodicElement[] = [
    { docNo: 9234321, actionId: 1, suezNo: 958795550100100, status: 'Complete', description: 'title1', isEdit: false, isDeleted: false },
    { docNo: 8234322, actionId: 2, suezNo: 858795550100101, status: 'Pending', description: 'title2', isEdit: false, isDeleted: false },
    { docNo: 7234323, actionId: 3, suezNo: 658795550100102, status: 'Complete', description: 'title3', isEdit: false, isDeleted: false },
    { docNo: 6234324, actionId: 4, suezNo: 558795550100103, status: 'Client Re-schedule', description: 'title4', isEdit: false, isDeleted: false },
    { docNo: 5234325, actionId: 5, suezNo: 458795550100104, status: 'Pending', description: 'title5', isEdit: false, isDeleted: false },
    { docNo: 4234326, actionId: 6, suezNo: 358795550100105, status: 'Complete', description: 'title6', isEdit: false, isDeleted: false },
    { docNo: 3234327, actionId: 7, suezNo: 258795550100106, status: 'Complete', description: 'title7', isEdit: false, isDeleted: false },
    { docNo: 2234328, actionId: 8, suezNo: 158795550100107, status: 'Pending', description: 'title8', isEdit: false, isDeleted: false },
    { docNo: 1234329, actionId: 9, suezNo: 758795550100108, status: 'Client Re-schedule', description: 'title9', isEdit: false, isDeleted: false },
    { docNo: 2234320, actionId: 10, suezNo: 258795550100109, status: 'Complete', description: 'title10', isEdit: false, isDeleted: false },
  ];

  dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);
  filterDocNo = new FormControl();
  filterSuezNo = new FormControl();
  filteredResultDocNo: Observable<string[]>;
  filteredResultSuezNo: Observable<string[]>;
  checked: boolean = false;
  showAddColumnDiv: boolean = false;

  filterTitle_options: string[] = ['Select All', 'Hypochlorite	System	SKID', 'AUT	Valve	Datasheet', 'adeg	General	Arrangement', 'Compressor	&	Receiver	GA', 'deg	General	Arrangement	Ip'];
  filterStatus_options: string[] = ['Complete', 'Pending', 'Client Re-schedule'];

  addMore_column_Array: any = [
    { id: 1, colName: 'description' },
    { id: 1, colName: 'Issuer' },
    { id: 1, colName: 'status' },
    { id: 1, colName: 'Discipline' },
    { id: 1, colName: 'Project	No#' },
    { id: 1, colName: 'Process' },
    { id: 1, colName: 'Phase' },
    { id: 1, colName: 'Doc Type' },
    { id: 1, colName: 'Client	Document' },
    { id: 1, colName: '%	Complete' },
    { id: 1, colName: 'Planned	Date' },
    { id: 1, colName: 'Due Date' },
    { id: 1, colName: 'Chronological' },
    { id: 1, colName: 'Replanned' },
    { id: 1, colName: 'Liquidated' },
    { id: 1, colName: 'Damages' },
    { id: 1, colName: 'Replanned	Notes' },
    { id: 1, colName: 'Platform' },
    { id: 1, colName: 'Project	Status' },
    { id: 1, colName: 'Department' }
  ]
  activeView: any;
  views: any[] = [
    {
      id: 1, viewName: 'Standard View', displayColumn: ['select', 'docNo', 'suezNo', 'status', 'description', 'actionId'],
      advancedFilter: {
        region: 'America',
        market: 'std market',
        group: 'std group',
        portfolio: 'std portfolio',
        role: 'superadmin',
        userNameID: 'Eric',
        selected_projects: [123456, 121212, 232323, 156611, 156611, 222222]
      },
      displayedColumnsHeader: ['select-header', 'docNo-header', 'suezNo-header', 'status-header', 'description-header', 'actionId-header'],
      tableFilter: {
        documentNo: [9234321, 8234322, 7234323, 6234324, 5234325, 4234326, 3234327, 2234328, 1234329, 2234320],
        suezNo: [958795550100100, 858795550100101, 658795550100102, 558795550100103, 458795550100104, 358795550100105, 258795550100106, 158795550100107, 758795550100108, 258795550100109],
        status: ['Complete', 'Pending', 'Client Re-schedule'],
        title: ['title1', 'title2', 'title3', 'title4', 'title5', 'title6', 'title7', 'title8', 'title9', 'title10']
      }
    },
    {
      id: 1, viewName: 'default View', displayColumn: ['select', 'docNo', 'status', 'description', 'actionId'],
      advancedFilter: {
        region: 'Africa',
        market: 'market1',
        group: 'group1',
        portfolio: 'portfolio1',
        role: 'project manager',
        userNameID: 'alberto',
        selected_projects: [123456, 121212, 222222]
      },
      displayedColumnsHeader: ['select-header', 'docNo-header', 'status-header', 'description-header', 'actionId-header'],
      tableFilter: {
        documentNo: [9234321, 8234322, 7234323, 6234324],
        suezNo: [958795550100100, 858795550100101, 758795550100102],
        status: ['Complete', 'Pending'],
        title: ['title1']
      }
    },
    {
      id: 2, viewName: 'ABC View', displayColumn: ['select', 'docNo', 'suezNo', 'description', 'actionId'],
      advancedFilter: {
        region: 'Asia',
        market: 'market2',
        group: 'group2',
        portfolio: 'portfolio2',
        role: 'admin',
        userNameID: 'pooja',
        selected_projects: [232323, 156611],
      },
      displayedColumnsHeader: ['select-header', 'docNo-header', 'suezNo-header', 'description-header', 'actionId-header'],
      tableFilter: {
        documentNo: [5234325, 4234326, 3234327],
        suezNo: [658795550100104, 558795550100105, 458795550100106],
        status: ['Complete', 'Client Re-schedule'],
        title: ['title1']
      }
    },
    {
      id: 3, viewName: 'XYZ View', displayColumn: ['select', 'docNo', 'suezNo', 'status', 'actionId'],
      advancedFilter: {
        region: 'Europe',
        market: 'market3',
        group: 'group3',
        portfolio: 'portfolio3',
        role: 'Lead',
        userNameID: 'sarah',
        selected_projects: [123456, 156611]
      },
      displayedColumnsHeader: ['select-header', 'docNo-header', 'suezNo-header', 'status-header', 'actionId-header'],
      tableFilter: {
        documentNo: [2234328, 1234329, 2234320],
        suezNo: [358795550100105, 258795550100106, 158795550100107],
        status: ['Client Re-schedule', 'Pending'],
        title: ['title1']
      }
    }
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;

  bulkOptions: string[] = ['Edit', 'Delete', 'Replan	with	Notes', 'Publish	/	Revise', 'Restore', 'Build for Transmittal']
  selectDisabled: boolean = true;

  displayedColumnsHeader: any = ['select-header', 'docNo-header', 'suezNo-header', 'status-header', 'description-header', 'actionId-header'];

  newArr = [];
  filterDocNo_options = [];
  selectedDocNo: any = [];
  filteredDocNo: Observable<DocNoInterface[]>;
  lastFilter: string = '';

  filterSuezNo_options: any = [];
  selectedSuezNo: any = [];
  filteredSuezNo: Observable<SuezNoInt[]>

  constructor(private store: Store<RootStoreState.State>, private translate: TranslateService, public dialog: MatDialog) {
    super(translate)
  }

  createFilterOptions() {
    this.activeView = this.views[0];
    localStorage.setItem('activeView', JSON.stringify(this.activeView))
    for (var i = 0; i < this.ELEMENT_DATA.length; i++) {
      let isDocSel;
      let isSuezSel;
      if (this.activeView['tableFilter']['documentNo'].indexOf(this.ELEMENT_DATA[i]['docNo']) >= 0) {
        isDocSel = true;
      } else {
        isDocSel = false;
      }

      if (this.activeView['tableFilter']['suezNo'].indexOf(this.ELEMENT_DATA[i]['suezNo']) >= 0) {
        isSuezSel = true;
      } else {
        isSuezSel = false;
      }

      this.filterDocNo_options.push({ 'docNo': this.ELEMENT_DATA[i]['docNo'].toString(), 'isSelected': isDocSel })
      this.filterSuezNo_options.push({ 'suezNo': this.ELEMENT_DATA[i]['suezNo'].toString(), 'isSelected': isSuezSel })
    }
  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.applyFilter();
    this.createFilterOptions();

    this.error$ = this.store.select(
      MdlStoreSelectors.selectMyFeatureError
    );

    this.isLoading$ = this.store.select(
      MdlStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(MdlStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);

    if (!this.isLoaded) {
      this.store.dispatch(new MdlStoreActions.LoadRequestAction());
      this.result$ = this.store.select(MdlStoreSelectors.selectAllMyFeatureItems);
    } else {
      this.result$ = this.store.select(MdlStoreSelectors.selectAllMyFeatureItems);
    }

  }


  filterbyDocNo(filter: string): DocNoInterface[] {
    this.lastFilter = filter;
    if (filter) {
      return this.filterDocNo_options.filter(option => {
        return option.docNo.toLowerCase().indexOf(filter.toLowerCase()) >= 0;
      })
    } else {
      return this.filterDocNo_options.slice();
    }
  }

  filterbySuezNo(filter: string): SuezNoInt[] {
    this.lastFilter = filter;
    if (filter) {
      return this.filterSuezNo_options.filter(option => {
        return option.suezNo.toLowerCase().indexOf(filter.toLowerCase()) >= 0;
      })
    } else {
      return this.filterSuezNo_options.slice();
    }
  }

  optionClicked(event: Event, user: DocNoInterface) {
    event.stopPropagation();
    this.toggleSelection(user);
  }

  suezOptionClicked(event: Event, user: SuezNoInt) {
    event.stopPropagation();
    this.suezToggleSelection(user);
  }

  toggleSelection(user: DocNoInterface) {
    user.isSelected = !user.isSelected;
    if (user.isSelected) {
      this.selectedDocNo.push(user.docNo);
    } else {
      const i = this.selectedDocNo.findIndex(value => value.docNo === user.docNo);
      this.selectedDocNo.splice(i, 1);
    }
    this.filterDocNo.setValue(this.selectedDocNo);
  }

  suezToggleSelection(user: SuezNoInt) {
    user.isSelected = !user.isSelected;
    if (user.isSelected) {
      this.selectedSuezNo.push(user.suezNo);
    } else {
      const i = this.selectedSuezNo.findIndex(value => value.docNo === user.suezNo);
      this.selectedSuezNo.splice(i, 1);
    }
    this.filterSuezNo.setValue(this.selectedSuezNo);
  }



  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  removeSelectedRows() {
    this.selection.selected.forEach(item => {
      let index: number = this.ELEMENT_DATA.findIndex(d => d === item);
      this.dataSource.data.splice(index, 1);
      this.dataSource = new MatTableDataSource<PeriodicElement>(this.dataSource.data);
    });
    this.selection = new SelectionModel<PeriodicElement>(true, []);
  }

  checkedData: any = [];
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(event) {
    // console.log(this.dataSource.data)
    this.checkedData = this.dataSource.data;
    console.log(this.checkedData)

    this.selectDisabled = !this.selectDisabled
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.docNo + 1}`;
  }


  singleCheckboxClick(data) {
    console.log(data)
    this.checkedData.push(data)
    console.log(this.checkedData)
    this.selectDisabled = !this.selectDisabled
    event.stopPropagation();
  }


  someMethod(isselected, state: any) {
    this.selectDisabled = true;
    if (isselected) {
      this.activeView = this.views[state];
      localStorage.setItem('activeView', JSON.stringify(this.views[state]))
      this.displayedColumns = this.views[state].displayColumn;
      this.displayedColumnsHeader = this.views[state].displayedColumnsHeader;
    }

  }

  applyFilter() {

    // filter suezNo
    this.filteredSuezNo = this.filterSuezNo.valueChanges.pipe(
      startWith<string | SuezNoInt[]>(''),
      map(value => typeof value === 'string' ? value : this.lastFilter),
      map(filter => this.filterbySuezNo(filter))
    );

    // filter docNo
    this.filteredDocNo = this.filterDocNo.valueChanges.pipe(
      startWith<string | DocNoInterface[]>(''),
      map(value => typeof value === 'string' ? value : this.lastFilter),
      map(filter => this.filterbyDocNo(filter))
    );
  }

  checkedDocNo(event, val) {
    event.stopPropagation();
    let i = this.selectedDocNo.indexOf(val);
    if (i > -1) {
      this.selectedDocNo.splice(i, 1);
    } else {
      this.selectedDocNo.push(val)
    }
  }

  applyFilterForAllCol() {
    this.dataSource.data = this.filterOptions(this.selectedDocNo, this.selectedSuezNo);
  }

  filterOptions(docNoVal?: string[], suezNoVal?: string[]): PeriodicElement[] {
    console.log(docNoVal)
    console.log(suezNoVal)
    if ((!docNoVal || docNoVal.length === 0) && !suezNoVal) {
      return this.ELEMENT_DATA;
    }
    const filtered = this.ELEMENT_DATA.filter((periodicElement) => {
      return ((docNoVal ? docNoVal.indexOf(periodicElement.docNo + '') !== -1 : false) ||
        (suezNoVal ? suezNoVal.indexOf(periodicElement.suezNo + '') !== -1 : false))
      // return (docNoVal ? docNoVal.indexOf(periodicElement.docNo + '') !== -1 : false)
    });
    return filtered;
  }

  openHistoryModal() {
    const dialogRef = this.dialog.open(MdlHistoryModalComponent);
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  onOpenedChange(e: boolean) {
    console.log("Final open", e);
  }

  // optionClicked(event: Event) {
  //   event.stopPropagation();
  // }

  addNewColumns() {
    this.showAddColumnDiv = !this.showAddColumnDiv;

    let arr = JSON.parse(localStorage.getItem('activeView'));
    this.addMore_column_Array.some(
      v => {
        var r = arr['displayColumn'].includes(v['colName'])
        if (r == true) {
          v['selected'] = true;
        }
      })
  }

  addMoreColumn(colName) {
    let len: number = this.displayedColumns.length - 1;
    var a = this.displayedColumns.indexOf(colName);
    if (a === -1) {
      this.displayedColumns.splice(len, 0, colName)
    } else {
      this.displayedColumns.splice(a, 1)
    }
  }

  applyBgc: boolean;
  advFilterSelected(id?: number) {
    // this.trigger.toArray()[id].togglePopover();
    this.applyBgc = !this.applyBgc;
  }

  saveView() {
    const dialogRef = this.dialog.open(SaveViewModalComponent, {
      data: {
        role: 'admin',
        showOption: true
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


  openReplanNotesModal() {
    console.log(this.checkedData)
    const dialogRef = this.dialog.open(ReplanNotesComponent, {
      data: {
        checkedData: this.checkedData
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  openPublishReviseModal() {
    const dialogRef = this.dialog.open(PublishReviseComponent, {
      data: {
        checkedData: this.checkedData
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  showFiltetByArea: boolean = false
  filterBy() {
    this.showFiltetByArea = !this.showFiltetByArea;
  }

  removeFromFilter(val) {
    let activeView = JSON.parse(localStorage.getItem('activeView'))
    let index = this.views.findIndex(obj => obj.viewName == activeView.viewName);
    var a = activeView.tableFilter.documentNo.indexOf(val);
    if (a > -1) {
      activeView.tableFilter.documentNo.splice(a, 1);
      localStorage.setItem('activeView', JSON.stringify(activeView));
      this.views[index] = activeView;
    }
  }

  inr = 0;
  showAllOptions: boolean = true;
  showSaveOption: boolean = false
  editDoc(val) {
    // event.stopPropagation()
    this.ELEMENT_DATA.map(function (a) {
      a.isEdit = false;
    })
    this.ELEMENT_DATA[val].isEdit = true;
  }

  openOptionActionPopover(id: number, val) {
    this.showAllOptions = true;
    this.trigger.toArray()[id].togglePopover();
  }

  checkAllDocNo: boolean;
  checkAllSuezNo: boolean;
  checkedAllOption(val) {
    event.stopPropagation();
    if (val == 'docNo') {
      this.checkAllDocNo = !this.checkAllDocNo;
    }
    else if (val == 'suezNo') {
      this.checkAllSuezNo = !this.checkAllSuezNo;
    }
  }


  globalSearchFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  bulkActions(action) {
    // 'Edit', 'Delete', 'Replan	with	Notes', 'Publish	/	Revise', 'Restore', 'Build for Transmittal'
    if (action == 'Edit') {
      const dialogRef = this.dialog.open(MdlEditDocModalComponent, {
        data: {
          checkedData: this.checkedData
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log(`Dialog result: ${result}`);
      });
    }
    else if (action == 'Replan	with	Notes') {
      let dialogRef = this.dialog.open(ReplanNotesComponent, {
        data: {
          checkedData: this.checkedData
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log(`Dialog result: ${result}`);
      });
    }
    else if (action == 'Publish	/	Revise') {
      let dialogRef = this.dialog.open(PublishReviseComponent, {
        data: {
          checkedData: this.checkedData
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        console.log(`Dialog result: ${result}`);
      });
    }
    else if (action == 'Delete') {
      this.removeSelectedRows();
    }
    else if (action == 'Restore') {

    }
    else if (action == 'Build for Transmittal') {

    }
  }
}







