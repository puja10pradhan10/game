import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcelFileUploadComponent } from './excel-file-upload.component';

describe('ExcelFileUploadComponent', () => {
  let component: ExcelFileUploadComponent;
  let fixture: ComponentFixture<ExcelFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExcelFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcelFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
