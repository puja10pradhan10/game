import { Injectable } from "@angular/core";

import { Actions, Effect, ofType } from "@ngrx/effects";
import { Action } from "@ngrx/store";

import { Observable, of } from "rxjs";
import { map, mergeMap, catchError } from "rxjs/operators";

import { MdlService } from "../mdl.service";

import * as mdlActions from "../state/mdl.actions";
import { Mdl } from "./../mdl-inteface.model";


@Injectable()
export class MdlEffect {
  constructor(
    private actions$: Actions,
    private mdlService: MdlService
  ) {}

  @Effect()
  loadCustomers$: Observable<Action> = this.actions$.pipe(
    ofType<mdlActions.LoadCustomers>(
      mdlActions.MdlActionTypes.LOAD_CUSTOMERS
    ),
    mergeMap((action: mdlActions.LoadCustomers) =>
      this.mdlService.getCustomers().pipe(
        map(
          (mdl: Mdl[]) =>
            new mdlActions.LoadCustomersSuccess(mdl)
        ),
        catchError(err => of(new mdlActions.LoadCustomersFail(err)))
      )
    )
  );
  
  @Effect()
  loadCustomerstest$: Observable<Action> = this.actions$.pipe(
    ofType<mdlActions.LoadCustomersTest>(
      mdlActions.MdlActionTypes.LOAD_CUSTOMERS_Test
    ),
    mergeMap((action: mdlActions.LoadCustomersTest) =>
      this.mdlService.getCustomers().pipe(
        map(
          (mdl: Mdl[]) =>
            new mdlActions.LoadCustomersSuccessTest(mdl)
        ),
        catchError(err => of(new mdlActions.LoadCustomersFailTest(err)))
      )
    )
  );


}
