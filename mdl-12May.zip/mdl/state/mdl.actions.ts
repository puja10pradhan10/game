import { Action } from "@ngrx/store";
import { Update } from "@ngrx/entity";
import { Mdl } from "./../mdl-inteface.model";


export enum MdlActionTypes {
  LOAD_CUSTOMERS = "[Customer] Load Customers",
  LOAD_CUSTOMERS_SUCCESS = "[Customer] Load Customers Success",
  LOAD_CUSTOMERS_FAIL = "[Customer] Load Customers Fail",
  LOAD_CUSTOMERS_Test = "[Customer] Load Customers Test",
  LOAD_CUSTOMERS_Test_SUCCESS = "[Customer] Load Customers sTest Success",
  LOAD_CUSTOMERS_Test_FAIL = "[Customer] Load Customers Test Fail",
}

export class LoadCustomers implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS;
}

export class LoadCustomersSuccess implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS_SUCCESS;

  constructor(public payload: Mdl[]) {}
}

export class LoadCustomersFail implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS_FAIL;

  constructor(public payload: string) {}
}


export class LoadCustomersTest implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS_Test;
}

export class LoadCustomersSuccessTest implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS_Test_SUCCESS;

  constructor(public payload: Mdl[]) {}
}

export class LoadCustomersFailTest implements Action {
  readonly type = MdlActionTypes.LOAD_CUSTOMERS_Test_FAIL;

  constructor(public payload: string) {}
}


export type Action =
  | LoadCustomers
  | LoadCustomersSuccess
  | LoadCustomersFail
  | LoadCustomersTest
  | LoadCustomersSuccessTest
  | LoadCustomersFailTest;
 
