import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdlEditDocModalComponent } from './mdl-edit-doc-modal.component';

describe('MdlEditDocModalComponent', () => {
  let component: MdlEditDocModalComponent;
  let fixture: ComponentFixture<MdlEditDocModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdlEditDocModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdlEditDocModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
