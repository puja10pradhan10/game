import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdlHistoryModalComponent } from './mdl-history-modal.component';

describe('MdlHistoryModalComponent', () => {
  let component: MdlHistoryModalComponent;
  let fixture: ComponentFixture<MdlHistoryModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdlHistoryModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdlHistoryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
