import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublishReviseComponent } from './publish-revise.component';

describe('PublishReviseComponent', () => {
  let component: PublishReviseComponent;
  let fixture: ComponentFixture<PublishReviseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublishReviseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublishReviseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
