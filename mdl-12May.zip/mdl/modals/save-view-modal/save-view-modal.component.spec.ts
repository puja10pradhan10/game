import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveViewModalComponent } from './save-view-modal.component';

describe('SaveViewModalComponent', () => {
  let component: SaveViewModalComponent;
  let fixture: ComponentFixture<SaveViewModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveViewModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveViewModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
