import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface DialogData {
  role: string;
  showOption: boolean;
}

@Component({
  selector: 'app-save-view-modal',
  templateUrl: './save-view-modal.component.html',
  styleUrls: ['./save-view-modal.component.scss']
})
export class SaveViewModalComponent implements OnInit {
  showOptions: boolean;

  constructor(
    public dialogRef: MatDialogRef<SaveViewModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  ngOnInit() {
    console.log(this.data)
    this.showOptions = this.data.showOption;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }
}
