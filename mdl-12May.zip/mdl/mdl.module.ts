import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainViewComponent } from './component/main-view/main-view.component';
import { ReportsComponent } from './component/reports/reports.component';
import { ProjectDocumentStatusComponent } from './component/project-document-status/project-document-status.component';
import { ExcelFileUploadComponent } from './component/excel-file-upload/excel-file-upload.component';
import { VaultVirtualDocumentsComponent } from './component/vault-virtual-documents/vault-virtual-documents.component';

import { SharedModule } from '../../shared/shared.module';

import { Routes, RouterModule } from '@angular/router';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { MdlStoreEffects } from '../../root-store/mdl-store/effects';
import { MdlActionPopoverComponent } from './popovers/mdl-action-popover/mdl-action-popover.component';
import { MdlHistoryModalComponent } from './modals/mdl-history-modal/mdl-history-modal.component';
import { MasterDocumentListComponent } from './component/master-document-list/master-document-list.component';
import { MdlAddNewDocPopoverComponent } from './popovers/mdl-add-new-doc-popover/mdl-add-new-doc-popover.component';
import { ProjectSummaryComponent } from './component/project-summary/project-summary.component';

import { MatFileUploadModule } from 'angular-material-fileupload';
import { AdvancedFilterComponent } from './popovers/advanced-filter/advanced-filter.component';
import { SaveViewModalComponent } from './modals/save-view-modal/save-view-modal.component';
import { ReplanNotesComponent } from './modals/replan-notes/replan-notes.component';
import { PublishReviseComponent } from './modals/publish-revise/publish-revise.component';

// store
import { mdlReducer } from "./state/mdl.reducer";
import { MdlEffect } from "./state/mdl.effects";
import { MdlEditDocModalComponent } from './modals/mdl-edit-doc-modal/mdl-edit-doc-modal.component';
import { MdlUploadDocPopoverComponent } from './popovers/mdl-upload-doc-popover/mdl-upload-doc-popover.component';

const MDLRoutes: Routes = [
  {
    path: '',
    component: MainViewComponent
  }
];

@NgModule({
  declarations: [MainViewComponent, ReportsComponent, ProjectDocumentStatusComponent,
    ExcelFileUploadComponent, VaultVirtualDocumentsComponent, MdlActionPopoverComponent,
    MdlHistoryModalComponent,
    MasterDocumentListComponent, ProjectSummaryComponent, AdvancedFilterComponent, SaveViewModalComponent,
    MdlAddNewDocPopoverComponent, ReplanNotesComponent, PublishReviseComponent, MdlEditDocModalComponent, MdlUploadDocPopoverComponent],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(MDLRoutes),
    MatFileUploadModule,
    StoreModule.forFeature('mdl', mdlReducer),
    EffectsModule.forFeature([MdlEffect]),
  ],
  entryComponents: [MdlHistoryModalComponent,
    SaveViewModalComponent, ReplanNotesComponent, PublishReviseComponent, MdlEditDocModalComponent]
})
export class MDLModule { }
