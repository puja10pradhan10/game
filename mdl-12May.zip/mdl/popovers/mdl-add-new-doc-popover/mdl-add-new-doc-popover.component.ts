import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import { SharedComponent } from './../../../../shared/component/shared/shared.component';
import {SelectionModel} from '@angular/cdk/collections';
import {MatTableDataSource} from '@angular/material';


@Component({
  selector: 'app-mdl-add-new-doc-popover',
  templateUrl: './mdl-add-new-doc-popover.component.html',
  styleUrls: ['./mdl-add-new-doc-popover.component.scss']
})
export class MdlAddNewDocPopoverComponent implements OnInit {


addDocForm: FormGroup;

  formErrors = {
    'issuer': '',
    'discipline': '',
		'sion': '',
    'doctype': '',
		'chronological': '',
    'suezdocno': '',
    'title1': '',
    'title2': '',
    'title3': '',
    'notes': '',
    'docowner': '',
    'department': '',
    'issuedfor': '',
    'baselinedate': '',
    'contractduedate': '',
    'replanneddate': '',
    'replannedreasoncode': '',
    'replannednotes': '',
    'ppno': '',
    'clientdoc': '',
    'supplierdoc': '',
    'ref': '',
    'clientdoccode1': '',
    'clientdoccode2': '',
    'uploadcomments': '',
    'revisiondate': '',
    'revision': '',
    'revisionnotes': '',

  };


    validationMessages = {
    'issuer': {
      'required': 'Issuer is required.',
   },
    'discipline': {
      'required': 'Discipline is required.'
    },
		'sion': {
      'required': 'Sion is required.',
   },
    'doctype': {
      'required': 'Doc Type is required.'
    },

		'chronological': {
      'required': 'Chronological is required.',
   },
    'suezdocno': {
      'required': 'SUEZ Doc No is required.'
    },
    'title1': {
      'required': 'Title1 is required.'
    },
    'title2': {
      'required': 'Title2 is required.'
    },
    'title3': {
      'required': 'Title3 is required.'
    },
    'notes': {
      'required': 'Notes is required.'
    },
    'docowner': {
      'required': 'Doc Owner is required.'
    },
    'department': {
      'required': 'Department is required.'
    },
    'issuedfor': {
      'required': 'Issued For is required.'
    },
    'baselinedate': {
      'required': 'Baseline Date is required.'
    },
    'contractduedate': {
      'required': 'Contract Due Date is required.'
    },
   	'replanneddate': {
      'required': 'Replanned Date is required.'
    },
    'replannedreasoncode': {
      'required': 'Replanned Reason Code is required.'
    },
    'replannednotes': {
      'required': 'Replanned Notes is required.'
    },
    'ppno': {
      'required': 'PP No is required.'
    },
    'clientdoc': {
      'required': 'Client Doc is required.'
    },
    'supplierdoc': {
      'required': 'Supplier Doc Notes is required.'
    },
    'ref': {
      'required': 'Ref is required.'
    },
    'clientdoccode1': {
      'required': 'Client Doc Code 1 is required.'
    },
    'clientdoccode2': {
      'required': 'Client Doc Code 2 is required.'
    },
    'uploadcomments': {
      'required': 'Upload Comments is required.'
    },
    'revisiondate': {
      'required': 'Revision Date is required.'
    },
    'revision': {
      'required': 'Revision is required.'
    },
    'revisionnotes': {
      'required': 'Revision Notes is required.'
    },
  } 




displayedColumns: string[] = ['replanneddate', 'replannedreasoncode', 'replannednotes'];
dataSource = new MatTableDataSource<ClientElement>(ELEMENT_DATA);
selection = new SelectionModel<ClientElement>(true, []);


displayedColumns1: string[] = ['pp', 'description','star'];
dataSource1 = new MatTableDataSource<ClientElement1>(ELEMENT_DATA1);
selection1 = new SelectionModel<ClientElement1>(true, []);


displayedColumns2: string[] = ['revision', 'daterevisionno','revisionnotes'];
dataSource2 = new MatTableDataSource<ClientElement2>(ELEMENT_DATA2);
selection2 = new SelectionModel<ClientElement2>(true, []);


displayedColumns3: string[] = ['transmittalno', 'transmittaldate','reason','rev','custtrans','custdate','custstatus','suez','statusdelay'];
dataSource3 = new MatTableDataSource<ClientElement3>(ELEMENT_DATA3);
selection3 = new SelectionModel<ClientElement3>(true, []);



  constructor(private translate: TranslateService, public dialog: MatDialog, public fb: FormBuilder) { }

  ngOnInit() {


this.addDocForm = this.fb.group({
      issuer: ['', [Validators.required]],
      discipline: ['', Validators.required],
		  sion: ['', [Validators.required]],
      doctype: ['', Validators.required],
			chronological: ['', [Validators.required]],
      suezdocno: ['', Validators.required],
      title1: ['', Validators.required],
      title2: ['', Validators.required],
      title3: ['', Validators.required],
      notes: ['', Validators.required],
      docowner: ['', Validators.required],
      department: ['', Validators.required],
      issuedfor: ['', Validators.required],
      baselinedate: ['', Validators.required],
      contractduedate: ['', Validators.required],
      replanneddate: ['', Validators.required],
      replannedreasoncode: ['', Validators.required],
      replannednotes: ['', Validators.required],
      ppno: ['', Validators.required],
      clientdoc: ['', Validators.required],
      supplierdoc: ['', Validators.required],
      ref: ['', Validators.required],
      clientdoccode1: ['', Validators.required],
      clientdoccode2: ['', Validators.required],
      uploadcomments: ['', Validators.required],
      revisiondate: ['', Validators.required],
      revision: ['', Validators.required],
      revisionnotes: ['', Validators.required],
    });

   this.addDocForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.addDocForm);
    }); 


  }


logValidationErrors(group: FormGroup = this.addDocForm, status?:string): void {
    console.log("first ", this.addDocForm);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }  

}

export interface ClientElement {
  replanneddate: string;
  replannedreasoncode: string;
  replannednotes: string;
}

export interface ClientElement1 {
  pp: string;
  description: string;
}

export interface ClientElement2 {
  revision: string;
  daterevisionno: string;
  revisionnotes: string;
}


export interface ClientElement3 {
  transmittalno: string;
  transmittaldate: string;
  reason: string;
  rev: string;
  custtrans: string;
  custdate: string;
  custstatus: string;
  suez: string;
  statusdelay: string;

}

const ELEMENT_DATA: ClientElement[] = [

   {
 		"replanneddate": "10-APR-2019",
 		"replannedreasoncode": "Delay",
 		"replannednotes": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
 	},

	{
 		"replanneddate": "12-APR-2019",
 		"replannedreasoncode": "In Progress",
 		"replannednotes": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
 	},
];
  


const ELEMENT_DATA1: ClientElement1[] = [

  {
 		"pp": "P009",
 		"description": "Lorem Ipsum is simply dummy text",
 	},

	{
 		"pp": "P009",
 		"description": "Lorem Ipsum is simply dummy text",
 	},
];


const ELEMENT_DATA2: ClientElement2[] = [

  {
 		"revision": "10-APR-2019",
 		"daterevisionno": "A",
    "revisionnotes": "Lorem Ipsum is simply dummy text of the printing and typesebng industry",
 	},

	{
 		"revision": "12-APR-2019",
 		"daterevisionno": "B",
    "revisionnotes": "Lorem Ipsum is simply dummy text of the printing and typesebng industry",
 	},
];


const ELEMENT_DATA3: ClientElement3[] = [

  {
 		"transmittalno": "TR-0001",
 		"transmittaldate": "15/FEB/2019",
     "reason": "FA",
     "rev": "B",
     "custtrans": "--",
     "custdate": "--",
     "custstatus": "--",
     "suez": "--",
     "statusdelay": "0",
},

	  {
 		"transmittalno": "TR-0003",
 		"transmittaldate": "25/FEB/2019",
     "reason": "FA",
     "rev": "B",
     "custtrans": "28",
     "custdate": "22/MAR/2019",
     "custstatus": "A",
     "suez": "Complete",
     "statusdelay": "n/a",
},

  {
 		"transmittalno": "TR-0003",
 		"transmittaldate": "25/FEB/2019",
     "reason": "FA",
     "rev": "B",
     "custtrans": "15",
     "custdate": "15/MAY/2019",
     "custstatus": "RR",
     "suez": "Re-submit",
     "statusdelay": "65",
},

  {
 		"transmittalno": "TR-00025",
 		"transmittaldate": "05/MAR/2019",
     "reason": "F1",
     "rev": "C",
     "custtrans": "22",
     "custdate": "01/MAY/2019",
     "custstatus": "RR",
     "suez": "Re-submit",
     "statusdelay": "43",
},

  {
 		"transmittalno": "TR-00025",
 		"transmittaldate": "01/APR/2019",
     "reason": "F1",
     "rev": "D",
     "custtrans": "35",
     "custdate": "01/MAY/2019",
     "custstatus": "A",
     "suez": "Complete",
     "statusdelay": "n/a",
},

];