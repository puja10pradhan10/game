import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mdl-action-popover',
  templateUrl: './mdl-action-popover.component.html',
  styleUrls: ['./mdl-action-popover.component.scss']
})
export class MdlActionPopoverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
