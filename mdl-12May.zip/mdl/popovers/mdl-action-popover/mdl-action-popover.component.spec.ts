import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdlActionPopoverComponent } from './mdl-action-popover.component';

describe('MdlActionPopoverComponent', () => {
  let component: MdlActionPopoverComponent;
  let fixture: ComponentFixture<MdlActionPopoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdlActionPopoverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdlActionPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
