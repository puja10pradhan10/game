import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdlUploadDocPopoverComponent } from './mdl-upload-doc-popover.component';

describe('MdlUploadDocPopoverComponent', () => {
  let component: MdlUploadDocPopoverComponent;
  let fixture: ComponentFixture<MdlUploadDocPopoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdlUploadDocPopoverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdlUploadDocPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
