import { Component, OnInit } from '@angular/core';

export interface uploadHistoryData {
  docno: number;
  date: any;
  name: string;
  fileName: string;
  time: any;
}


@Component({
  selector: 'app-mdl-upload-doc-popover',
  templateUrl: './mdl-upload-doc-popover.component.html',
  styleUrls: ['./mdl-upload-doc-popover.component.scss']
})
export class MdlUploadDocPopoverComponent implements OnInit {

  displayedColumns = ['docno', 'date', 'name', 'fileName', 'time'];
  uploadHistory: uploadHistoryData[] = [
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' },
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' },
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' },
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' },
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' },
    { docno: 123456, date: '25-FEB-2019', name: 'Steve Smith', fileName: 'Panel_SM_01', time: '03:12 PM' }
  ];
  constructor() { }

  ngOnInit() {
  }

}
