import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advanced-filter',
  templateUrl: './advanced-filter.component.html',
  styleUrls: ['./advanced-filter.component.scss']
})
export class AdvancedFilterComponent implements OnInit {

  projectName_response: any[] = [
    { id: 123456, projectName: 'Lorem Ipsum', isSelected: false },
    { id: 121212, projectName: 'OCI', isSelected: false },
    { id: 232323, projectName: 'Fortune', isSelected: false },
    { id: 156611, projectName: 'Lorem Ipsum', isSelected: false },
    { id: 156611, projectName: 'Lorem Ipsum', isSelected: false },
    { id: 222222, projectName: 'Lorem Ipsum', isSelected: false }
  ];

  regionData: any[] = [
    { id: 1, region: "America", isSelected: false },
    { id: 1, region: "Africa", isSelected: false },
    { id: 2, region: "Asia", isSelected: false },
    { id: 3, region: "Europe", isSelected: true }
  ];

  marketData: any[] = [
    { id: 1, market: "std market", isSelected: false },
    { id: 1, market: "market1", isSelected: false },
    { id: 2, market: "market2", isSelected: false },
    { id: 3, market: "market3", isSelected: false }
  ];

  groupData: any[] = [
    { id: 1, group: "std group", isSelected: false },
    { id: 1, group: "group1", isSelected: false },
    { id: 2, group: "group2", isSelected: false },
    { id: 3, group: "group3", isSelected: false },
  ];

  portfolioData: any[] = [
    { id: 1, portfolio: "std portfolio", isSelected: false },
    { id: 1, portfolio: "portfolio1", isSelected: false },
    { id: 2, portfolio: "portfolio2", isSelected: false },
    { id: 3, portfolio: "portfolio3", isSelected: false },
  ];

  roles: any[] = [
    { id: 1, role: "superadmin", isSelected: false },
    { id: 1, role: "project manager", isSelected: false },
    { id: 2, role: "admin", isSelected: false },
    { id: 3, role: "Lead", isSelected: false }
  ];

  constructor() { }
  activeView: any;
  ngOnInit() {
    this.activeView = JSON.parse(localStorage.getItem('activeView'))

    for (var i = 0; i < this.projectName_response.length; i++) {
      if (this.activeView['advancedFilter']['selected_projects'].indexOf(this.projectName_response[i]['id']) >= 0) {
        this.projectName_response[i]['isSelected'] = true;
      }
    }
  }

}
