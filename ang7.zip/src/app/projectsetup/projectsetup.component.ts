import {Component} from '@angular/core';

@Component({
    selector:'app-project-setup',
    templateUrl: './projectsetup.component.html',
    styleUrls:['./projectsetup.component.css']
})
export class ProjectSetupComponent{

}