import {Component} from '@angular/core';

@Component({
    selector:'app-additional-info',
    templateUrl:'./additionalinfo.component.html',
    styleUrls:['./additionalinfo.component.css']
})

export class additionalInfoComponent{
    
}
