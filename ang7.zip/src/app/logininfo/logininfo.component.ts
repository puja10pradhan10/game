import { Component } from "@angular/core";
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Router } from "@angular/router";
import { map, catchError } from 'rxjs/operators';

@Component({
    selector: 'app-login-info',
    templateUrl: './logininfo.component.html',
    styleUrls: ['./logininfo.component.css']
})

export class logininfoComponent {
   
    constructor(private http: HttpClient, public router: Router, public headers: HttpHeaders) {

    }

    checkLogin() {
       
        let username = "pujapradhan"
        let password = "password";
        this.headers = new HttpHeaders();
        this.headers.append('Content-Type', 'application/x-www-form-urlencoded');

        this.http.get('./assets/sample.json', {
            headers: this.headers
          })
            .subscribe(response => {
                console.log('working')
                console.log(response);
                this.router.navigate(['/dashboard']);
            },
                error => { console.log(error) }
            );
    }
}