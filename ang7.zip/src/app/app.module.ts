import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProjectSetupComponent } from '../app/projectsetup/projectsetup.component';
import {additionalInfoComponent} from '../app/additionalinfo/additionalinfo.component';
import { procurementComponent } from './procurement/procurement.component';
import { logininfoComponent } from './logininfo/logininfo.component';
 
@NgModule({
  declarations: [
    AppComponent,
    ProjectSetupComponent,
    additionalInfoComponent,
    procurementComponent,
    logininfoComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
