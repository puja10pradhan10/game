import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { logininfoComponent } from './logininfo/logininfo.component'
import { ProjectSetupComponent } from './projectsetup/projectsetup.component'

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: logininfoComponent },
  { path: 'dashboard', component: ProjectSetupComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
