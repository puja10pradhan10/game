// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AdminBroadcastMessagesComponent } from './admin-broadcast-messages.component';

// describe('AdminBroadcastMessagesComponent', () => {
//   let component: AdminBroadcastMessagesComponent;
//   let fixture: ComponentFixture<AdminBroadcastMessagesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AdminBroadcastMessagesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AdminBroadcastMessagesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
