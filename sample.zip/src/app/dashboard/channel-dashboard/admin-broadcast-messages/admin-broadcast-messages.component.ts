import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter, Input } from '@angular/core';
// import { connect, connection, receiveLatestMessage } from '@assets/js/chat.js';
import { MatDialogRef, MatDialog } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import * as $ from 'jquery';

declare var jQuery: any;
declare var $: any;

import { connectionXmpp, LoaderStrings, googleMapStrings } from '@app/shared/base.constants';
import { CreateOneOnOneResponse, ForwardListResponse, GetOldMessageResponse, MessagePayload } from '@app/dashboard/dashboard.messages';
import { BaseComponent } from '@app/shared/base/base.component'
import { BaseService } from '@app/shared/base.service';
import { ToastrService } from 'ngx-toastr';
import { LoggerService } from '@app/shared/logger/logger.service';
import { CommunityService } from '@app/community/community.service';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { AdminFollowerChatComponent } from '@app/dashboard/channel-dashboard/admin-follower-chat/admin-follower-chat.component';
import { showImgComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { map } from 'rxjs/operators';
import { isUndefined } from 'util';

@Component({
  selector: 'app-admin-broadcast-messages',
  templateUrl: './admin-broadcast-messages.component.html',
  styleUrls: ['./admin-broadcast-messages.component.scss'],
})

export class AdminBroadcastMessagesComponent extends BaseComponent implements OnInit {
  broadcastMessages: any;
  firstMsg: boolean = false;
  timeInmillis: string;
  communityCreatedTime: boolean = false;
  MessageList: any
  channelData: any;
  chnlBroadcastMessage = [];
  textMessage: string;
  textMessageArrayList = [];
  adminBroadcastMessages: any;
  @ViewChild(AdminFollowerChatComponent) AdminFollowerChatComponent: AdminFollowerChatComponent;
  messagePayload = new MessagePayload();
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();

  constructor(public router: Router, public loggerService: LoggerService, public check: ActivatedRoute,
    private dashboardService: DashboardService, public baseService: BaseService, public dialog: MatDialog,
    public toastr: ToastrService, public communityService: CommunityService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
    localStorage.removeItem('ChatList')
    localStorage.removeItem('sendmsg')
    this.textMessage = "";
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
    else if (connectionXmpp.connection == undefined && BaseComponent.onlineOffline) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe((res) => {
        this.latestMessage();
        this.getOldMessages();
      }, (complete) => { });
    }
    else {
      this.latestMessage();
      this.getOldMessages();
    }
    let global = this;
    $(function () {
      $("#msgTextarea").keypress(function (e) {
        if (e.which == 13 && !e.shiftKey) {
          if (this.textMessage != '')
            global.sendMessage("", "", "plainMessage", "", "", "", "")
          $(this).val("");
          e.preventDefault();
        }
      });
    })
  }

  openDialogMsgInfo() {
    this.dialog.open(MsgInfoPopupComponent);
  }

  latestMessage() {
    let global = this;
    connectionXmpp.connection.addHandler((msg) => {
      this.firstMsg = false;
      console.log('listner call in admin');
      console.log(msg);

      let latestMsg;
      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());
        });
      });

      // let followerDetails = JSON.parse(localStorage.getItem('Selectedfollower'));
      // if (latestMsg.communityId == global.channelData.communityKey) {
      //   if (global.channelData.isMember) {
      //     global.chnlDetails();
      //   }
      // }
      // else {
      //   console.log('not match');
      // }
      return true
    }, null, 'message', 'headline')
  }

  getOldMessages() {
    this.dashboardService.showLoader();
    this.dashboardService.oldMessages(this.channelData.communityKey).subscribe(response => this.handleresponseOfOldMessages(response),
      error => this.handleError(error));
  }

  handleresponseOfOldMessages(response: GetOldMessageResponse) {
    this.adminBroadcastMessages = [];
    this.adminBroadcastMessages = response.messagesList.slice().reverse();
    localStorage.setItem('oldMessages', JSON.stringify(this.adminBroadcastMessages))

    if (response.success && response.messagesList.length) {
      this.firstMsg = false;
      //this.chnlDetails();
      this.dashboardService.hideLoader();
      let global = this;
      for (let i = 0; i < this.adminBroadcastMessages.length; i++) {
        this.adminBroadcastMessages[i].createdDatetime = this.dashboardService.timeSince(this.adminBroadcastMessages[i].createdDatetime)
      }
      $(document).ready(function () {
        if ($("#chatAudio").length || $("#chatVideo").length) {
          $('#chatAudio, #chatVideo').mediaelementplayer({
            success: function (media) {
              var isNative = /html5|native/i.test(media.rendererName);
              // var isYoutube = ~media.rendererName.indexOf('youtube');
            }
          });
          $('#chatAudio, #chatVideo').each(function () {
            $(this).remove();
          });
        }
      });
      // message always show bottom code
      $("#style-1").animate({ scrollTop: $('#style-1').prop("scrollHeight") }, 1000);
    } else {
      this.dashboardService.hideLoader();
      this.firstMsg = true;
    }
  }

  chnlDetails() {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    this.chnlBroadcastMessage = this.channelData.Broadcast;
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }

    // Messages list comming from service
    new Observable(this.dashboardService.getMessages).subscribe(
      (res) => {
        this.adminBroadcastMessages = res
        if (!this.adminBroadcastMessages.length) {
          this.firstMsg = true;
          this.dashboardService.hideLoader();
        } else {
          this.dashboardService.hideLoader();
          this.firstMsg = false;
          let global = this;
          for (let i = 0; i < this.adminBroadcastMessages.length; i++) {
            this.adminBroadcastMessages[i].createdDatetime = this.dashboardService.timeSince(this.adminBroadcastMessages[i].createdDatetime)
          }

          $(document).ready(function () {
            if ($("#chatAudio").length || $("#chatVideo").length) {
              $('#chatAudio, #chatVideo').mediaelementplayer({
                success: function (media) {
                  var isNative = /html5|native/i.test(media.rendererName);
                  // var isYoutube = ~media.rendererName.indexOf('youtube');
                }
              });
              $('#chatAudio, #chatVideo').each(function () {
                $(this).remove();
              });
            }
          });
          // message always show bottom code
          $("#style-1").animate({ scrollTop: $('#style-1').prop("scrollHeight") }, 1000);
        }
        this.dashboardService.hideLoader();
      })
  }

  userImagePopup(channelProfileImageUrl, srcType) {
    this.dialog.open(showImgComponent, {
      panelClass: 'my-full-screen-dialog',
      data: {
        imgSrc: channelProfileImageUrl,
        srcType: srcType,
      }
    });
  }

  deleteMessage(message) {
    localStorage.setItem("msgClicked", JSON.stringify(message))
    this.dialog.open(confirmDeleteMesagePopupComponent);

  }

  sendMessage(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText, storageBucketName) {
    localStorage.removeItem('forwardMsg');
    let msg = this.textMessage;
    this.textMessage = "";
    this.adminBroadcastMessages = JSON.parse(localStorage.getItem('oldMessages'))

    this.dashboardService.hideLoader();

    if (connectionXmpp.connection != undefined && BaseComponent.onlineOffline) {
      this.dashboardService.sendMessage(nodeKey, messageKey, source, messageSmallThumbUrl,
        actualMessageUrl, messageText, storageBucketName, msg).subscribe(response => {
          console.log(response);
          localStorage.setItem('tempArr', JSON.stringify(response))

          if (source == 'plainMessage') {
            this.showMessages()
          }
        })
      //this.latestMessage();
    } else {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
  }

  showMessages() {
    this.firstMsg = false;
    this.adminBroadcastMessages.push(JSON.parse(localStorage.getItem('tempArr')))
    localStorage.setItem('oldMessages', JSON.stringify(this.adminBroadcastMessages));
    localStorage.removeItem('tempArr');
  }

  openDialogFarward(messageText, mediaType) {
    let forward = this.dialog.open(AdminDashboardForwardPopupComponent);
  }

  goToLocation(mapData) {
    this.showLocation(mapData);
  }

  generateMessagetime() {
    let date = new Date();
    return this.timeInmillis = date.getTime().toString();
  }

}



@Component({
  selector: 'app-delete-message-confirm-popup',
  template: `
  <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
<h2 mat-dialog-title>Are you sure you want to delete this message? </h2>
<mat-dialog-actions class="twoBtn">
  <button type="button" class="btnPopup btnBlack" (click)="onNoClick('no')" mat-dialog-close>No</button>
  <button type="submit" class="btnPopup btnRed" (click)="yesClick('yes')" mat-dialog-close>Yes</button>
</mat-dialog-actions>
</div>`
})
export class confirmDeleteMesagePopupComponent implements OnInit {
  constructor(private dashboardService: DashboardService, public dialogRef: MatDialogRef<confirmDeleteMesagePopupComponent>, private toastr: ToastrService,
    public dialog: MatDialog, private router: Router) { }
  ngOnInit() {
  }
  onNoClick(option: string): void {
    this.dialogRef.close(option);
  }
  debuggingMode: true;

  yesClick(option: string): void {
    this.dashboardService.showLoader()

    let message = JSON.parse(localStorage.getItem('msgClicked'))
    let channelData = JSON.parse(localStorage.getItem('createCommunityData'));


    let nodeName: string;
    let node: string;
    nodeName = channelData.communityKey
    connectionXmpp.connection.pubsub.items(nodeName, function (status) {

      $(status).find("items").each(function () {
        node = $(this).attr("node")
        $(status).find("item").each(function () {
          connectionXmpp.connection.pubsub.deleteItem(
            node,
            message.messageGuid,
            (status) => {
            }
          );
        });
      });
      this.dashboardService.hideLoader()

    });
  }
}


@Component({
  selector: 'app-delete-message-popup',
  template: `
  <div class="forwardMsgPopup checkboxCss">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn"><i class="zmdi zmdi-close"></i></button><span> Forward Message to</span>
  </mat-dialog-actions>
  <mat-dialog-content>
      <div class="green-input-line">
              <mat-form-field class="full-wid searchOuter">
                  <span matPrefix><i class="zmdi zmdi-search"></i></span>
                      <input matInput placeholder="Search Followers" value="">
              </mat-form-field>
          </div>
      <div class="forwardMsgContent pad-all-md-lg">
          <mat-list class="mat-pad-none mrgn-none">
               <mat-list-item class="mrgn-b-sm">
                  <mat-checkbox matListAvatar>
                   <img matListAvatar src="assets/img/agri_business.jpg" />
                   <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
                  </mat-checkbox>
               </mat-list-item>
               <mat-list-item class="mrgn-b-sm">
               <mat-checkbox matListAvatar>
                <img matListAvatar src="assets/img/agri_business.jpg" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
               </mat-checkbox>
            </mat-list-item>
            
          </mat-list>
      </div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
        <div class="forwardBtn">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-mail-send"></i>
              </a>
          </div>
  </mat-dialog-actions>
</div><!-- end forward msg -->
`
})
export class AdminDashboardForwardPopupComponent extends BaseComponent implements OnInit {

  constructor(public loggerService: LoggerService, public toastr: ToastrService, public router: Router, public dialogRef: MatDialogRef<AdminDashboardForwardPopupComponent>, public dialog: MatDialog) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
  }

}


/* msg info popup */
@Component({
  selector: 'app-msg-info-popup',
  template: `
  <div class="forwardMsgPopup blockedFollower msgInfo">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn">
          <i class="zmdi zmdi-close"></i>
      </button>
      <span> Message Information</span>
  </mat-dialog-actions>
  <mat-dialog-content>
      <div class="forwardMsgContent pad-all-md-lg">
          <mat-list class="mat-pad-none mrgn-none">
              <mat-list-item class="mrgn-b-sm">
                  <img matListAvatar src="assets/img/default_user.png" />
                  <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah <span class="msgTiming">18 April 4:00 PM</span></h4>
                  <p class="readColor">Read</p>
              </mat-list-item>

              <mat-list-item class="mrgn-b-sm">
                <img matListAvatar src="assets/img/default_user.png" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah <span class="msgTiming">18 April 4:00 PM</span></h4>
                <p class="deliveredColor">Delivered</p>
              </mat-list-item>

              <mat-list-item class="mrgn-b-sm">
                <img matListAvatar src="assets/img/default_user.png" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah <span class="msgTiming">18 April 4:00 PM</span></h4>
                <p class="sendColor">Send</p>
              </mat-list-item>

              
          </mat-list>
          <div>
              <p> No message info found</p>
          </div>

      </div>
  </mat-dialog-content>
</div>
`
})
export class MsgInfoPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<MsgInfoPopupComponent>, public dialog: MatDialog) { }
  ngOnInit() {
  }
}