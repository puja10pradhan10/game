// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AdminFollowerChatComponent } from './admin-follower-chat.component';

// describe('AdminFollowerChatComponent', () => {
//   let component: AdminFollowerChatComponent;
//   let fixture: ComponentFixture<AdminFollowerChatComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AdminFollowerChatComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AdminFollowerChatComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
