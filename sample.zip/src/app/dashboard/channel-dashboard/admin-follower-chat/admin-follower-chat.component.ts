import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { Observable } from 'rxjs/Observable';
import { BaseComponent } from '@app/shared/base/base.component';
import { LoggerService } from '@app/shared/logger/logger.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MatDialog } from '@angular/material';
import { connectionXmpp } from '@app/shared/base.constants';
import { CreateOneOnOneResponse, ForwardListResponse } from '@app/dashboard/dashboard.messages';
import { showImgComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';

declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-admin-follower-chat',
  templateUrl: './admin-follower-chat.component.html',
  styleUrls: ['./admin-follower-chat.component.scss']
})

export class AdminFollowerChatComponent extends BaseComponent implements OnInit {
  channelData: any;
  adminMessage = [];
  followerMessage: any;
  textMessage: string;
  textMessageArrayList: any;
  followerDetails: any;
  UserDetails: any;
  UserId: any;
  communityCreatedTime: boolean = false;

  constructor(private dashboardService: DashboardService, public dialog: MatDialog, public loggerService: LoggerService, public router: Router, public toastr: ToastrService) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
    if (connectionXmpp.connection == undefined) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          // this.adminOneOnOneChat();
          this.getOldChatMessages();
          this.latestMessage();
        },
        (complete) => {
        }
      );
    } else {
      // this.adminOneOnOneChat();
      this.getOldChatMessages()
      this.latestMessage();
    }
    this.textMessage = "";

    localStorage.setItem("ChatList", "OneOnOne")
    this.followerDetails = JSON.parse(localStorage.getItem('Selectedfollower'));

    this.UserDetails = JSON.parse(localStorage.getItem('userDetails'));
    this.UserId = this.UserDetails['user']['userId'];

    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let global = this;
    $(function () {
      $("#msgTextarea").keypress(function (e) {
        if (e.which == 13 && !e.shiftKey) {
          if (global.textMessage != '')
            global.sendOneToOneMsg(global.followerDetails.communityJabberId, "", "plainMessage", "", "", "", "", global.textMessage)
          $(this).val("");
          e.preventDefault();
        }
      });
    })
  }

  latestMessage() {
    let global = this;
    connectionXmpp.connection.addHandler((msg) => {
      console.log('listner call in 1:1 admin broadcast');
      console.log(msg);
      let latestMsg;
      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());
        });
      });

      this.dashboardService.hideLoader();
      if (latestMsg.communityId == global.followerDetails.communityJabberId) {

        if (global.channelData.isMember) {
          this.adminOneOnOneChat();
        }
      } else {
        console.log('not match');
      }
      return true;
    }, null, 'message')
  }

  getOldChatMessages() {
    this.dashboardService.showLoader();
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    this.dashboardService.oldMessages(this.channelData.communityKey).subscribe(response => this.handleresponseOfGetOldChatMessages(response),
      error => this.handleError(error));
  }

  handleresponseOfGetOldChatMessages(response) {
    this.dashboardService.hideLoader();
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }
    console.log(response);
    //this.followerMessage = response.messagesList.slice().reverse();
    
    if (response.success && response.messagesList.length) {
      this.dashboardService.hideLoader();
      this.followerMessage = response.messagesList.slice().reverse();
      localStorage.setItem('oldMessages', JSON.stringify(this.followerMessage));
      
      for (let i = 0; i < this.followerMessage.length; i++) {
        this.followerMessage[i].createdDatetime = this.dashboardService.timeSince(this.followerMessage[i].createdDatetime)
      }
    } else {
      this.dashboardService.hideLoader();
      console.log('not send message yet');
    }
  }

  adminOneOnOneChat() {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }

    new Observable(this.dashboardService.getMessages).subscribe(
      (res) => {
        console.log(res)
        this.followerMessage = res
        if (!this.followerMessage.length) {
          this.dashboardService.hideLoader();
        } else {
          for (let i = 0; i < this.followerMessage.length; i++) {
            this.followerMessage[i].createdDatetime = this.dashboardService.timeSince(this.followerMessage[i].createdDatetime)
          }
          this.dashboardService.hideLoader();

          $(document).ready(function () {
            if ($("#audioMedia").length || $("#videoMedia").length) {
              $('#audioMedia, #videoMedia').mediaelementplayer({
                success: function (media) {
                  var isNative = /html5|native/i.test(media.rendererName);
                  // var isYoutube = ~media.rendererName.indexOf('youtube');
                }
              });
              $('#audioMedia, #videoMedia').each(function () {
                $(this).remove();
              });
            }
          });
          // message always show bottom code
          $("#style-1").animate({ scrollTop: $('#style-1').prop("scrollHeight") }, 1000);
        }
      })
  }

  sendMessage(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText, storageBucketName) {
    localStorage.removeItem('forwardMsg')
    let Selectedfollower = JSON.parse(localStorage.getItem('Selectedfollower'))
    localStorage.setItem("ChatList", "OneOnOne")
    localStorage.setItem("sendmsg", "OneOnOne")
    nodeKey = this.channelData.communityKey + '_' + Selectedfollower.ownerId;
    this.dashboardService.sendMessage(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText, storageBucketName, this.textMessage)
  }

  sendOneToOneMsg(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText, storageBucketName, textMessage) {
    if (connectionXmpp.connection != undefined && BaseComponent.onlineOffline) {
      this.dashboardService.sendOnetoOneMessage(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl,
        messageText, storageBucketName, textMessage).subscribe(response => {
          console.log(response);
          localStorage.setItem('tempArr', JSON.stringify(response))

          if (source == 'plainMessage') {
            this.showMessages()
          }
        })

      // if (source == 'plainMessage' || source == 'location') {
      //   setTimeout(() => {
      //     this.adminOneOnOneChat();
      //   }, 1500);
      // } else {
      //   setTimeout(() => {
      //     this.adminOneOnOneChat();
      //   }, 3000);
      // }
      // this.textMessage = "";
      // this.latestMessage();
    } else {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
  }

  showMessages() {
    this.dashboardService.hideLoader();
    this.followerMessage.push(JSON.parse(localStorage.getItem('tempArr')))
    localStorage.setItem('oldMessages', JSON.stringify(this.followerMessage));
    localStorage.removeItem('tempArr');
  }

  openDialogFarward(messageText, mediaType) {
    let forward = this.dialog.open(AdminOneOnOneDashboardForwardPopupComponent);

  }

  userImagePopup(channelProfileImageUrl, srcType) {
    this.dialog.open(showImgComponent, {
      panelClass: 'my-full-screen-dialog',
      data: {
        imgSrc: channelProfileImageUrl,
        srcType: srcType
      }
    });
  }

  goToLocation(mapData) {
    this.showLocation(mapData);
  }
}


@Component({
  selector: 'app-delete-message-popup',
  template: `
  <div class="forwardMsgPopup checkboxCss">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn"><i class="zmdi zmdi-close"></i></button><span> Forward Message to</span>
  </mat-dialog-actions>
  <mat-dialog-content>
      <div class="green-input-line">
              <mat-form-field class="full-wid searchOuter">
                  <span matPrefix><i class="zmdi zmdi-search"></i></span>
                      <input matInput placeholder="Search Followers" value="">
              </mat-form-field>
          </div>
      <div class="forwardMsgContent pad-all-md-lg">
          <mat-list class="mat-pad-none mrgn-none">
               <mat-list-item class="mrgn-b-sm">
                  <mat-checkbox matListAvatar>
                   <img matListAvatar src="assets/img/agri_business.jpg" />
                   <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
                  </mat-checkbox>
               </mat-list-item>
               <mat-list-item class="mrgn-b-sm">
               <mat-checkbox matListAvatar>
                <img matListAvatar src="assets/img/agri_business.jpg" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah,</h4>
               </mat-checkbox>
            </mat-list-item>
          </mat-list>
      </div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
        <div class="forwardBtn">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-mail-send"></i>
              </a>
          </div>
  </mat-dialog-actions>
</div><!-- end forward msg -->
`
})

export class AdminOneOnOneDashboardForwardPopupComponent extends BaseComponent implements OnInit {

  constructor(public loggerService: LoggerService, public toastr: ToastrService, public router: Router, public dialogRef: MatDialogRef<AdminOneOnOneDashboardForwardPopupComponent>, public dialog: MatDialog) {
    super(loggerService, router, toastr)
  }

  ngOnInit() { }

}
