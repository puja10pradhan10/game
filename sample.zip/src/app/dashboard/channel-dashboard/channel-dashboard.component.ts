import { Component, OnInit, Output, EventEmitter, ViewChild, Inject, Optional, ElementRef, Pipe } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { BaseComponent } from '@app/shared/base/base.component'
import { LoggerService } from '@app/shared/logger/logger.service';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { FollowerListInterface } from '@app/dashboard/dashboard-interface';
import { AdminFollowerChatComponent } from '@app/dashboard/channel-dashboard/admin-follower-chat/admin-follower-chat.component';
import { AdminBroadcastMessagesComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';

declare var jQuery: any;
declare var $: any;

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { connect, connection } from '@assets/js/chat.js';
import { Router } from '@angular/router';
import { connectionXmpp, DefaultColor } from '@app/shared/base.constants';
import { Strings, LoaderStrings, PassParamsToDrawer } from '@app/shared/base.constants';

import { CommunityService } from '@app/community/community.service';
import { BaseService } from '@app/shared/base.service';
import { Observable } from 'rxjs/Observable';
import { ToastrService } from 'ngx-toastr';
import ImageCompressor from 'image-compressor.js';
// import { } from '@types/googlemaps';
/// <reference types="googlemaps" />
import { error, isUndefined } from 'util';
import { OneOnOneUserListResponse } from '@app/dashboard/dashboard.messages';
declare var google: any;
declare let MediaRecorder: any;
import {
  MediaPopupComponent, ImagePopupComponent, VideoPopupComponent, AudioOptionPopupComponent,
  locationStepOnePopupComponent, locationStepTwoPopupComponent, CameraShowTwoPopupComponent,
  RecordAudionPopupComponent, RecordAudioStopPopupComponent
} from '@app/dashboard/media-popup/media-popup.component';
import { ShowFollowerProfileComponent } from '@app/profile/user/show-follower-profile/show-follower-profile.component';
import { ShowChannelProfileComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';

@Component({
  selector: 'app-channel-dashboard',
  templateUrl: './channel-dashboard.component.html',
  styleUrls: ['./channel-dashboard.component.scss'],
  providers: [DashboardService]
})
export class ChannelDashboardComponent extends BaseComponent implements OnInit {

  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  menuListSideNav: boolean = false;
  showUserProfileSideNav: boolean = false;
  editUserProfileSideNav: boolean = false;
  editChannelProfileSideNav: boolean = false;
  showChannelProfileSideNav: boolean = false;
  channelData: any;
  communityName: string;
  communityImage: string;
  channelColor = DefaultColor.color;
  followerListService: FollowerListInterface[];
  adminBroadcastMsg: boolean = false;
  adminFollowerChat: boolean = false;
  personName: any = "Broadcast";
  chatWindowColor: string;
  channelServiceData: any;
  userName: string;
  msgKey: any;
  file: any
  filename: string
  fileToCompress: any;
  OneOnOneChatList = [];
  OneOnOneChat: any;
  userDetails: any;
  followerName: string;
  privacy: string;
  showOnetoOneList: boolean = false;
  @ViewChild(AdminFollowerChatComponent) AdminFollowerChatComponent: AdminFollowerChatComponent;
  @ViewChild(AdminBroadcastMessagesComponent) AdminBroadcastMessagesComponent: AdminBroadcastMessagesComponent;
  @ViewChild(ShowFollowerProfileComponent)
  private memberProfile: ShowFollowerProfileComponent;

  @ViewChild(ShowChannelProfileComponent)
  private channel_profile: ShowChannelProfileComponent;

  constructor(private dashboardService: DashboardService, public router: Router, public loggerService: LoggerService, private _DashboardService: DashboardService
    , public dialog: MatDialog, private communityService: CommunityService, public toastr: ToastrService) {
    super(loggerService, router, toastr);
    // Discover Search
    jQuery(document).ready(function () {
      var sliBtn = '.search-btn',
        sliCont = '.search-slide',
        sliTxt = '.search-slide input[type=search]',
        sliDis = '.search-close-bar',
        sliSpd = 300;

      $(sliBtn).click(function () {
        $(sliCont).animate(
          { 'width': '16.5625em' }, sliSpd
        );
        $(sliTxt).focus();
      });
      $(sliDis).click(function () {
        $(sliCont).animate(
          { 'width': 0 }, sliSpd
        );
      });

    });
  }

  ngOnInit() {
    localStorage.removeItem('Selectedfollower');
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'))
    this.followerName = this.userDetails.user.username;
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (connectionXmpp.connection == undefined && BaseComponent.onlineOffline) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          this.dashboardService.hideLoader()
          this.adminBroadcastMsg = true;
          this.OneOnOneList();
          this.broadcastMsgs();
          // this.latestOneOnOneList();
        },
        (complete) => {
          this.dashboardService.hideLoader()
        }
      );
    } else {
      if (BaseComponent.onlineOffline) {
        this.dashboardService.hideLoader()
        this.adminBroadcastMsg = true;
        this.OneOnOneList();
        this.broadcastMsgs();
        // this.latestOneOnOneList();
      } else {
        this.dashboardService.hideLoader()
        this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
      }
    }

    let currentTime = this.communityService.generateMessagetime();


    this.communityName = this.channelData.communityName;
    this.communityImage = this.channelData.communityImageBigThumbUrl;
    this.channelColor = this.channelData.communityDominantColour;
    this.chatWindowColor = this.channelData.communityDetailscommunityDominantColour;
    this.privacy = this.channelData.privacy;
    $(".chatOuter .right").css("background-color", this.channelData.communityDominantColour);
    if (localStorage.getItem(Strings.DISABLE_BACK) && localStorage.getItem(Strings.DISABLE_BACK) == Strings.DISABLE) {
      this.disableBack()
    }
  }


  setChnlDashboardStyles() {
    let styles;
    styles = {
      'background': this.channelData.communityDominantColour + " ! important",
    }
    return styles;
  }

  latestOneOnOneList() {

    let global = this;
    connectionXmpp.connection.addHandler((msg) => {
      console.log('listner call in channel dashboard');
      console.log(msg);
      let latestMsg;

      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());

          if (global.OneOnOneChat.length)
            for (let i = 0; i < global.OneOnOneChat.length; i++) {
              if (latestMsg.communityId == global.OneOnOneChat[i]['communityJabberId']) {

                global.OneOnOneChat[i]['messageAt'] = global.dashboardService.timeSince(latestMsg.createdDatetime);
                $('#time_' + latestMsg.communityId).html(global.dashboardService.timeSince(latestMsg.createdDatetime));

                if (latestMsg.mediaType == "location") {
                  $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-pin'></i><b>Location</b>")
                }
                else if (latestMsg.mediaType == "audio") {
                  $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-audio'></i><b>Audio</b>")
                }
                else if (latestMsg.mediaType == "video") {
                  $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-camera'></i><b>Video</b>")
                }
                else if (latestMsg.mediaType == "image") {
                  $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-camera'></i><b>Image</b>")
                }
                else {
                  $('#' + latestMsg.communityId).html(latestMsg.contentField1)
                }

                global.OneOnOneChat.sort(function (a, b) {
                  return b.messageAt - a.messageAt;
                });

              } else {

                //console.log(latestMsg.contentField1);
              }
            }

            // if (localStorage.getItem('Selectedfollower') && localStorage.getItem('ChatList') == 'OneOnOne') {
            //   let followerDetails = JSON.parse(localStorage.getItem('Selectedfollower'));
            //   if (latestMsg.communityId == followerDetails.communityJabberId) {

            //     if (global.channelData.isMember) {
            //       localStorage.setItem('tempArr', JSON.stringify(latestMsg))
            //       this.AdminFollowerChatComponent.showMessages();
            //     }
            //   } else {
            //     console.log('not match');
            //   }
            // }
        });
      });
      return true
    }, null, 'message')
  }


  OneOnOneList() {
    this.OneOnOneChatList = [];
    this.OneOnOneChat = [];
    this.dashboardService.showLoader()
    this.dashboardService.getOneToOneUserList(this.channelData.communityKey).subscribe(response => this.handleresponseOfOneOnOneList(response),
      error => this.handleError(error));
  }

  handleresponseOfOneOnOneList(response: OneOnOneUserListResponse) {
    this.dashboardService.hideLoader();
    if (response.success == true) {
      this.OneOnOneChat = response.myChats;
      if (this.OneOnOneChat.length) {
        this.showOnetoOneList = true;

        this.OneOnOneChat = this.OneOnOneChat.sort((a, b) => b.messageAt - a.messageAt)
        this.latestOneOnOneList();
      } else {
        this.showOnetoOneList = false;
      }
    } else {
      this.showOnetoOneList = true;
      this.dashboardService.hideLoader()
      this.toastr.error('Error to get Mychat list', 'Error !!')
    }
  }

  locationStepOnePopup() {
    let dialogRef = this.dialog.open(locationStepOnePopupComponent);
    dialogRef.componentInstance.chanlKey = this.channelData.communityJabberId;
    const sub = dialogRef.componentInstance.onList.subscribe((data) => {
      if (data == 'stepOneLocation') {
        if (localStorage.getItem('Selectedfollower')) {
          this.AdminFollowerChatComponent.showMessages();
        } else {
          this.AdminBroadcastMessagesComponent.showMessages();
        }
        dialogRef.close();
      }
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  openDialogCameraOption(optionFor) {
    let dialogRef = this.dialog.open(CameraShowTwoPopupComponent);
    if (optionFor == "audioCapture") {
      dialogRef.componentInstance.optionFor = optionFor;
    } else if (optionFor == "videoImageCapture") {
      dialogRef.componentInstance.optionFor = optionFor;
    }

    const sub = dialogRef.componentInstance.onUploadSuccess.subscribe((data) => {
      console.log(data)
      if (data == 'imageUploaded') {
        if (localStorage.getItem('Selectedfollower')) {
          this.AdminFollowerChatComponent.showMessages();
        } else {
          this.AdminBroadcastMessagesComponent.showMessages();
        }
      }
      dialogRef.close();
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  openDrawer(name: string): void {
    this.loggerService.info('name : ', name)
    this.dashboardService.hideLoader()
    if (name == 'showOtherUserProfile') {
      localStorage.setItem('closeDrawer', 'closeRight');
    } else if (name == 'updateDashboard') {
      this.ngOnInit();
    }
    else if (name == 'showChannelProfile') {
      if (this.channel_profile) {
        this.channel_profile.ngOnInit()
      }
      this.showDrawer(name);
    }
    else if (name == 'newMessage') {
      console.log('newMessage');

      console.log(isUndefined(this.AdminFollowerChatComponent))
    }
    else {
      this.showDrawer(name);

      if (this.memberProfile) {
        this.memberProfile.ngOnInit()
      }
    }
  }

  clickedFOllower: any;
  chatWithFollower(follower) {
    this.dashboardService.showLoader();
    localStorage.setItem("ChatList", "OneOnOne")
    localStorage.setItem('Selectedfollower', JSON.stringify(follower));
    localStorage.setItem('closeDrawer', 'closeRight');

    this.adminFollowerChat = true;
    this.adminBroadcastMsg = false;
    this.personName = follower.communityName + " " + follower.lastName;
    this.chatWindowColor = 'gainsboro';
    this.clickedFOllower = JSON.parse(localStorage.getItem('Selectedfollower'))
    this.communityImage = follower.communityImageUrl;
    if (this.AdminFollowerChatComponent != undefined && localStorage.getItem('Selectedfollower')) {
      this.AdminFollowerChatComponent.adminOneOnOneChat();
    }
  }

  setFollowerData() {
    localStorage.setItem('Selectedfollower', JSON.stringify(this.clickedFOllower));
    this.openDrawer('showFollowerProfileOnChnl');
  }

  broadcastMsgs() {
    localStorage.removeItem('Selectedfollower')
    localStorage.removeItem('ChatList')
    this.adminFollowerChat = false;
    this.adminBroadcastMsg = true;
    this.personName = "Broadcast";
    this.chatWindowColor = this.channelData.communityDominantColour;
    if (this.AdminBroadcastMessagesComponent != undefined)
      this.AdminBroadcastMessagesComponent.getOldMessages()
  }

  imageUpload(event: any) {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    }
    this.filename = event.target.files[0]['name'];

    let index = this.filename.lastIndexOf(".");
    var strsubstring = this.filename.substring(index, this.filename.length);
    this.fileToCompress = event.target.files[0];

    if (strsubstring == '.zip' || strsubstring == '.mp3' || strsubstring == '.mp4' || strsubstring == '.gif' || strsubstring == '.mov') {
      this.toastr.info('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Info !!');

    } else if (event.target.files[0]['size'] <= 10000000 && (strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png')) {

      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      this.file = event.target.files[0];
      let fileUrl;
      let dialogRef;
      reader.onload = (e: Event) => {
        let fileUrl = e.target['result'];
        dialogRef = this.dialog.open(ImagePopupComponent);
        dialogRef.componentInstance.uploadState = "gallery";
        dialogRef.componentInstance.imageUrl = fileUrl;
        dialogRef.componentInstance.communityKey = this.channelData.communityKey;
        dialogRef.componentInstance.file = this.file;
        dialogRef.componentInstance.filename = this.filename;
        BaseService.fileToCompress = this.fileToCompress
        new Observable(this.communityService.compressFile).subscribe(result => {
          dialogRef.componentInstance.fileToCompress = result
        })

        const sub = dialogRef.componentInstance.onUpload.subscribe((data) => {
          if (data == 'sendImage') {
            if (localStorage.getItem('Selectedfollower')) {
              this.AdminFollowerChatComponent.showMessages();
            } else {
              this.AdminBroadcastMessagesComponent.showMessages();
            }
          }
          dialogRef.close();
        });
        dialogRef.afterClosed().subscribe(() => {
          sub.unsubscribe();
        });

      }
    } else {
      this.toastr.info('Image size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    }
  }

  videoUpload(event: any) {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    }
    let base64String;
    let dialogRef;
    let videoExtension = event.target.files[0]['type']
    if (event.target.files[0]['size'] > 10000000) {
      this.toastr.info('Video size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    }
    // if (videoExtension == 'video/mp4' || videoExtension == 'video/x-msvideo' || videoExtension == 'video/3gpp' || videoExtension == 'video/quicktime') 
    if (videoExtension == 'video/mp4') {
      this.filename = event.target.files[0]['name'];
      var videoFileObj = event.target.files[0]
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (e: Event) => {
        base64String = e.target['result'];
        if (base64String != '') {
          dialogRef = this.dialog.open(VideoPopupComponent);
          dialogRef.componentInstance.uploadState = "gallery";
          dialogRef.componentInstance.videoUrl = base64String;
          dialogRef.componentInstance.chanlKey = this.channelData.communityKey;
          dialogRef.componentInstance.videoFileObj = videoFileObj;
          dialogRef.componentInstance.filename = this.filename
        } else {
        }
      }
    } else {
      this.toastr.info('Video format should be mp4', 'Info !!'); return false;
    }
  }

  audioUpload(event: any) {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    let audioExtension = event.target.files[0]['type']

    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    }
    if (audioExtension == 'audio/mp3' || audioExtension == 'audio/ogg' || audioExtension == 'audio/wav' || audioExtension == 'audio/mpeg') {
      if (event.target.files[0]['size'] / 1000 / 1000 < 10) {

        this.filename = event.target.files[0]['name'];
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        this.file = event.target.files[0];
        let fileUrl;
        let dialogRef;
        reader.onload = (e: Event) => {
          let fileUrl = e.target['result']
          if (fileUrl != '') {
            dialogRef = this.dialog.open(AudioOptionPopupComponent);
            dialogRef.componentInstance.audioUrl = fileUrl;
            dialogRef.componentInstance.communityKey = this.channelData.communityDetails.communityKey;
            dialogRef.componentInstance.audioUrl = this.file;
            dialogRef.componentInstance.file = this.file
            dialogRef.componentInstance.filename = this.filename
          }
          else {

          }
        }
      }
      else {
        this.toastr.info('Audio size should be less than or equal to 10 MB ', 'Info !!'); return false;
      }
    }
    else {
      this.toastr.info('Audio format should be mp3/ogg/wav/mpeg', 'Info !!'); return false;
    }
  }
}
