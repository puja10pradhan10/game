import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WelcomeDashboardComponent, discoverListPopupComponent } from '@app/dashboard/welcome-dashboard/welcome-dashboard.component';

import { RouterModule } from '@angular/router';
import { SharedModule } from '@app/shared/shared.module';
import { ChannelDashboardComponent } from '@app/dashboard/channel-dashboard/channel-dashboard.component';
import { AdminBroadcastMessagesComponent, confirmDeleteMesagePopupComponent, AdminDashboardForwardPopupComponent, MsgInfoPopupComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';
import { AdminFollowerChatComponent, AdminOneOnOneDashboardForwardPopupComponent } from '@app/dashboard/channel-dashboard/admin-follower-chat/admin-follower-chat.component';
import { AdminBroadcastedMessagesComponent, FollowerDashboardForwardPopupComponent } from '@app/dashboard/welcome-dashboard/admin-broadcasted-messages/admin-broadcasted-messages.component';
import { FollowerAdminChatComponent, DeletePopupComponent, FollowerOneOnOneForwardPopupComponent, confirmDeleteMesageAdminOneOnOnePopupComponent } from '@app/dashboard/welcome-dashboard/follower-admin-chat/follower-admin-chat.component';
import {
  MediaPopupComponent, ImagePopupComponent, VideoPopupComponent, AudioOptionPopupComponent,
  locationStepOnePopupComponent, locationStepTwoPopupComponent, CameraShowTwoPopupComponent,
  RecordAudionPopupComponent, RecordAudioStopPopupComponent
} from '@app/dashboard/media-popup/media-popup.component';
import { DiscoverChannelsService } from '@app/community/discover/discover-channels/discover-channels.service';
import { DashboardService } from '@app/dashboard/dashboard.service';

@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    SharedModule
  ],
  entryComponents: [
    confirmDeleteMesagePopupComponent,
    confirmDeleteMesageAdminOneOnOnePopupComponent,
    discoverListPopupComponent,
    VideoPopupComponent,
    RecordAudionPopupComponent,
    AudioOptionPopupComponent,
    RecordAudioStopPopupComponent,
    DeletePopupComponent,
    AdminDashboardForwardPopupComponent,
    AdminOneOnOneDashboardForwardPopupComponent,
    FollowerDashboardForwardPopupComponent,
    FollowerOneOnOneForwardPopupComponent, ImagePopupComponent, MediaPopupComponent,
    locationStepOnePopupComponent,
    locationStepTwoPopupComponent,
    CameraShowTwoPopupComponent,
    MsgInfoPopupComponent
  ],
  declarations: [confirmDeleteMesagePopupComponent, confirmDeleteMesageAdminOneOnOnePopupComponent, discoverListPopupComponent, WelcomeDashboardComponent, ChannelDashboardComponent,
    AdminBroadcastMessagesComponent, AdminFollowerChatComponent, AdminBroadcastedMessagesComponent, FollowerAdminChatComponent, VideoPopupComponent,
    MediaPopupComponent,
    RecordAudionPopupComponent,
    AudioOptionPopupComponent,
    RecordAudioStopPopupComponent,
    DeletePopupComponent,
    AdminDashboardForwardPopupComponent,
    AdminOneOnOneDashboardForwardPopupComponent,
    FollowerDashboardForwardPopupComponent,
    FollowerOneOnOneForwardPopupComponent, ImagePopupComponent, locationStepOnePopupComponent, locationStepTwoPopupComponent,
    CameraShowTwoPopupComponent,
    MsgInfoPopupComponent
  ],
  providers: [DiscoverChannelsService, DashboardService, AdminBroadcastMessagesComponent]
})
export class DashboardModule { }
