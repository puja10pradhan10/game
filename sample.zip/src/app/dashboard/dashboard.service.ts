import { Injectable } from '@angular/core';
import { Http, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { catchError, map } from 'rxjs/operators';
import { Observable, of, BehaviorSubject } from 'rxjs';
import 'rxjs/add/operator/catch';

// import { Observable } from 'rxjs/Observable';
import { FollowerListInterface } from '@app/dashboard/dashboard-interface';
import { environment } from '@env/environment';
import { ToastrService } from 'ngx-toastr';

//Service
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';

import {
  MyChatsListRequest, MyChatsListResponse, MessagePayload, CreateOneOnOneRequest,
  CreateOneOnOneResponse, GetOldMessageResponse, CommonChannelResponse, OneOnOneUserListResponse, getMuteResponse, muteDetailsRequest
} from '@app/dashboard/dashboard.messages'
import { connectionXmpp } from '@app/shared/base.constants';
import { UserStrings } from '@app/shared/base.constants';

import { HeaderString, FacebookLoginStrings, ApiUrl } from '@app/shared/base.constants';
import * as $ from 'jquery';
// import { AdminBroadcastMessagesComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';

declare var jQuery: any;
declare var $: any;


@Injectable()
export class DashboardService extends BaseService {
  result: any;
  request = new MyChatsListRequest();
  messagePayload = new MessagePayload()
  broadcastMessages = [];
  firstMsg: boolean = false;
  timeInmillis: string;
  communityCreatedTime: boolean = false;
  channelData: any;
  sendSucess: any;
  interval: any;
  textMessage: string;
  textMessageArrayList = [];
  userDetails: any;

  constructor(private http: Http, public baseService: BaseService, public loggerService: LoggerService, public toastr: ToastrService, ) {
    super(loggerService, http);
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'))
  }

  getMyChatsList(): Observable<MyChatsListResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));

    let currentTime = this.baseService.generateMessagetime();
    let getMychatListUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.GET_MYCHAT_LIST + '?page_size=100&page_number=1&search_text=&CURRENT_TIMESTAMP=' + currentTime;

    return this._http.get(getMychatListUrl, options)
      .map((response: Response) => <MyChatsListResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }

  getOneToOneUserList(communityKey): Observable<OneOnOneUserListResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));

    let currentTime = this.baseService.generateMessagetime();
    let getOneToOneUserListUrl = environment.oAuthConfig.API_BASE_URL + 'users/current/onetoone/' + communityKey + '?page_size=100&page_number=1&search_text=&CURRENT_TIMESTAMP=' + currentTime;

    return this._http.get(getOneToOneUserListUrl, options)
      .map((response: Response) => <OneOnOneUserListResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }

  getCommonChannels(followerId): Observable<CommonChannelResponse> {

    let options = this.getHeaderForAPICall();

    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));

    let currentTime = this.baseService.generateMessagetime();
    let getCommonChannelUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.COMMUNITIES + '/' + ApiUrl.MEMBERS + '/' + followerId + ApiUrl.URL_PARAMS + '&CURRENT_TIMESTAMP=' + currentTime;

    return this._http.get(getCommonChannelUrl, options)
      .map((response: Response) => <CommonChannelResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }

  getMessages(observer) {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let UserDetails = JSON.parse(localStorage.getItem('userDetails'));
    let communityJabberId;
    let oldMessageList = [];
    let reverseoldMessageList = [];
    let messageList = [];
    let global = this;
    let selectedFollower;

    if (localStorage.getItem("ChatList") == "OneOnOne") {
      if (localStorage.getItem('currentPath') == '/channel-dashboard') {
        selectedFollower = JSON.parse(localStorage.getItem('Selectedfollower'))
        communityJabberId = selectedFollower.communityJabberId
      }
      else if (localStorage.getItem('currentPath') == '/welcome-dashboard') {
        selectedFollower = JSON.parse(localStorage.getItem('createCommunityData'))
        communityJabberId = selectedFollower.userCommunityJabberId
      }
    } else {
      communityJabberId = this.channelData.communityJabberId
    }

    connectionXmpp.connection.pubsub.items(communityJabberId, function (status) {
      $(status).each(function () {

        $(status).find("title").each(function () {
          let messageObject = JSON.parse($(this).html());


          oldMessageList.push(messageObject);
        });
      });
      // to reverse array for display corect order 
      reverseoldMessageList = oldMessageList.slice().reverse()
      global.broadcastMessages = reverseoldMessageList

      if (!global.broadcastMessages.length) {
        global.firstMsg = true;
      } else {
        global.firstMsg = false;
      }
      // To send message list into component file
      $.LoadingOverlay('hide')
      observer.next(global.broadcastMessages);
      observer.complete();

    }, function error(res) {
    })
    return { unsubscribe(): any { } };
  }

  timeSince(date) {
    // console.log(new Date(date).valueOf())     
    // var myDate = new Date(date);
    // console.log(myDate.toUTCString() + "<br>" + myDate.toLocaleString());

    // let finalTime = myDate.toUTCString();

    this.interval = 0;
    var todayDate: any;
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    // todayDate = new Date().valueOf()
    // var seconds = Math.floor((todayDate - date) / 1000);
    var seconds = Math.floor((new Date().valueOf() - date) / 1000);
    this.interval = Math.floor(seconds / 31556926);

    if (this.interval >= 1) {
      var d = new Date(date);
      var date1 = monthNames[d.getMonth()]
      return d.getUTCDate() + " " + date1;
    }
    this.interval = Math.floor(seconds / 2629743);
    if (this.interval >= 1) {
      var d = new Date(date);
      var date1 = monthNames[d.getMonth()]
      return d.getUTCDate() + " " + date1;
    }

    this.interval = Math.floor(seconds / 604800);
    if (this.interval >= 1) {
      var d = new Date(date);
      var date1 = monthNames[d.getMonth()]
      return d.getUTCDate() + " " + date1;
    }
    this.interval = Math.floor(seconds / 172800);
    if (this.interval >= 1) {
      var d = new Date(date);
      var date1 = monthNames[d.getMonth()]
      return d.getUTCDate() + " " + date1;
    }
    this.interval = Math.floor(seconds / 86400);
    if (this.interval >= 1) {
      return " yesterday";
    }

    this.interval = Math.floor(seconds / 3600);
    if (this.interval >= 1) {
      return this.interval + " hrs. ago";
    }
    this.interval = Math.floor(seconds / 60);
    if (this.interval >= 1) {
      return this.interval + " min ago";
    }
    // return Math.floor(seconds) + " NOW";
    return " NOW";

    // var seconds = Math.floor((new Date().valueOf() - date) / 1000);

    // var interval = Math.floor(seconds / 31536000);

    // if (interval >= 1) {
    //   return interval + " years";
    // }
    // interval = Math.floor(seconds / 2592000);
    // if (interval >= 1) {
    //   return interval + " months";
    // }
    // interval = Math.floor(seconds / 86400);
    // if (interval >= 1) {
    //   return interval + " days";
    // }
    // interval = Math.floor(seconds / 3600);
    // if (interval >= 1) {
    //   return interval + " hours";
    // }
    // interval = Math.floor(seconds / 60);
    // if (interval >= 1) {
    //   return interval + " minutes";
    // }
    // return Math.floor(seconds) + " seconds";
  }

  sendAdminBroadcastMessage(payload, messageGuid): Observable<any> {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let global = this;
    localStorage.setItem('payload', JSON.stringify(payload))
    connectionXmpp.connection.pubsub.publish(this.channelData.communityJabberId,
      JSON.stringify(payload), messageGuid, this.onPublish(response => {

        localStorage.removeItem('fileUploads')
        localStorage.removeItem('sendmsg')
        this.sendSucess = 'sent';
      }))
    // this.textMessage = "";
    this.firstMsg = false;
    return Observable.of(this.messagePayload).map(o => o);

  }

  sendMessage(nodeKey,
    messageKey,
    source,
    messageSmallThumbUrl,
    actualMessageUrl,
    messageText,
    storageBucketName,
    textMessage): Observable<any> {

    let messageGuid;
    let userDetails = JSON.parse(localStorage.getItem('userDetails'))
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let storageBucketFileName;
    this.textMessage = textMessage;

    if (source == 'plainMessage' && this.textMessage == undefined) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.length == 0) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.charCodeAt(0) == 32) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.charCodeAt(0) == 10) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else {
      if (source == 'plainMessage') {
        this.textMessage = this.textMessage.trim();
        storageBucketName = ''
        this.messagePayload.mediaType = "text";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(textMessage);
        this.messagePayload.contentField2 = "";
        this.messagePayload.contentField3 = "";
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = "";
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = this.baseService.generateMessageGuid();
      }
      else if (source == 'location') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "";
        this.messagePayload.messageType = "location";
        this.messagePayload.contentField1 = "";
        this.messagePayload.contentField2 = storageBucketName.columnThree
        this.messagePayload.contentField3 = storageBucketName.columnFour;
        this.messagePayload.contentField4 = storageBucketName.columnOne;
        this.messagePayload.contentField5 = storageBucketName.columnTwo;
        this.messagePayload.contentField6 = "";
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'image') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "image";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = messageSmallThumbUrl;
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'audio') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "audio";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = "";
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = messageSmallThumbUrl;
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'video') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "video";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = messageSmallThumbUrl;
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField8 = textMessage;
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }

      this.messagePayload.communityId = this.channelData.communityKey;
      this.messagePayload.senderId = this.channelData.ownerId;
      this.messagePayload.jabberId = this.channelData.communityJabberId;
      this.messagePayload.createdDatetime = this.generateMessagetime();
      this.messagePayload.deletedDatetime = "";
      this.messagePayload.hiddenDatetime = "";
      this.messagePayload.hiddenbyUserId = "";
      this.messagePayload.deletedbyUserId = "";

      // this.loggerService.info('payload  : ', this.messagePayload)

      let callbackPayload = {
        "messageStatus": this.messagePayload.messageStatus,
        "messageType": this.messagePayload.messageType,
        "mediaType": this.messagePayload.mediaType,
        "contentField1": this.messagePayload.contentField1,
        "contentField2": this.messagePayload.contentField2,
        "contentField3": this.messagePayload.contentField3,
        "contentField4": this.messagePayload.contentField4,
        "contentField5": this.messagePayload.contentField5,
        "contentField6": this.messagePayload.contentField6,
        "contentField7": this.messagePayload.contentField7,
        "contentField8": this.messagePayload.contentField8,
        "contentField9": this.messagePayload.contentField9,
        "contentField10": this.messagePayload.contentField10,
        "id": this.messagePayload.id,
        "communityId": this.messagePayload.communityId,
        "senderId": this.messagePayload.senderId,
        "jabberId": this.messagePayload.jabberId,
        "createdDatetime": this.timeSince(this.messagePayload.createdDatetime),
        "deletedDatetime": this.messagePayload.deletedbyUserId,
        "hiddenDatetime": this.messagePayload.hiddenDatetime,
        "hiddenbyUserId": this.messagePayload.hiddenbyUserId,
        "deletedbyUserId": this.messagePayload.deletedbyUserId
      }

      let global = this;
      localStorage.setItem('payload', JSON.stringify(this.messagePayload))
      connectionXmpp.connection.pubsub.publish(this.channelData.communityJabberId,
        JSON.stringify(this.messagePayload), messageGuid, this.onPublish(response => {

          localStorage.removeItem('fileUploads')
          localStorage.removeItem('sendmsg')
          this.sendSucess = 'sent';
        }))
      // this.textMessage = "";
      this.firstMsg = false;
      return Observable.of(callbackPayload).map(o => o);
    }
  }

  sendOnetoOneMessage(jabberId,
    messageKey,
    source,
    messageSmallThumbUrl,
    actualMessageUrl,
    messageText,
    storageBucketName,
    textMessage): Observable<any> {
    let messageGuid;
    let userDetails = JSON.parse(localStorage.getItem('userDetails'))
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let storageBucketFileName;
    this.textMessage = textMessage;

    if (source == 'plainMessage' && this.textMessage == undefined) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.length == 0) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.charCodeAt(0) == 32) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else if (source == 'plainMessage' && this.textMessage.charCodeAt(0) == 10) {
      this.toastr.info('Cannot Send Empty Message', 'Info !!');
      this.baseService.hideLoader()
    }
    else {
      if (source == 'plainMessage') {
        this.textMessage = this.textMessage.trim();
        storageBucketName = ''
        this.messagePayload.mediaType = "text";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(textMessage);
        this.messagePayload.contentField2 = "";
        this.messagePayload.contentField3 = "";
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = "";
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = this.baseService.generateMessageGuid();
      }
      else if (source == 'location') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "";
        this.messagePayload.messageType = "location";
        this.messagePayload.contentField1 = "";
        this.messagePayload.contentField2 = storageBucketName.columnThree
        this.messagePayload.contentField3 = storageBucketName.columnFour;
        this.messagePayload.contentField4 = storageBucketName.columnOne;
        this.messagePayload.contentField5 = storageBucketName.columnTwo;
        this.messagePayload.contentField6 = "";
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'image') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "image";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = messageSmallThumbUrl;
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField8 = "";
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'audio') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "audio";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = "";
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = "";
        this.messagePayload.contentField8 = messageSmallThumbUrl;
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }
      else if (source == 'video') {
        this.baseService.showLoader();
        this.messagePayload.mediaType = "video";
        this.messagePayload.messageType = "chat";
        this.messagePayload.contentField1 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField2 = actualMessageUrl;
        this.messagePayload.contentField3 = messageSmallThumbUrl;
        this.messagePayload.contentField4 = "";
        this.messagePayload.contentField5 = "";
        this.messagePayload.contentField6 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField7 = this.baseService.validateNotEmptyAndNull(messageText);
        this.messagePayload.contentField8 = textMessage;
        this.messagePayload.contentField9 = "";
        this.messagePayload.contentField10 = "";
        this.messagePayload.id = messageGuid = messageKey;
      }

      this.messagePayload.communityId = jabberId;
      this.messagePayload.senderId = this.userDetails.user.userId;
      this.messagePayload.jabberId = jabberId;
      this.messagePayload.createdDatetime = this.generateMessagetime();
      this.messagePayload.deletedDatetime = "";
      this.messagePayload.hiddenDatetime = "";
      this.messagePayload.hiddenbyUserId = "";
      this.messagePayload.deletedbyUserId = "";

      this.loggerService.info('payload  : ', JSON.stringify(this.messagePayload))

      let callbackPayload = {
        "messageStatus": this.messagePayload.messageStatus,
        "messageType": this.messagePayload.messageType,
        "mediaType": this.messagePayload.mediaType,
        "contentField1": this.messagePayload.contentField1,
        "contentField2": this.messagePayload.contentField2,
        "contentField3": this.messagePayload.contentField3,
        "contentField4": this.messagePayload.contentField4,
        "contentField5": this.messagePayload.contentField5,
        "contentField6": this.messagePayload.contentField6,
        "contentField7": this.messagePayload.contentField7,
        "contentField8": this.messagePayload.contentField8,
        "contentField9": this.messagePayload.contentField9,
        "contentField10": this.messagePayload.contentField10,
        "id": this.messagePayload.id,
        "communityId": this.messagePayload.communityId,
        "senderId": this.messagePayload.senderId,
        "jabberId": this.messagePayload.jabberId,
        "createdDatetime": this.timeSince(this.messagePayload.createdDatetime),
        "deletedDatetime": this.messagePayload.deletedbyUserId,
        "hiddenDatetime": this.messagePayload.hiddenDatetime,
        "hiddenbyUserId": this.messagePayload.hiddenbyUserId,
        "deletedbyUserId": this.messagePayload.deletedbyUserId
      }

      connectionXmpp.connection.pubsub.publish(jabberId,
        JSON.stringify(this.messagePayload), messageGuid, this.onPublish((response) => {
          localStorage.removeItem('fileUploads')
          localStorage.removeItem('sendmsg')
          this.sendSucess = 'sent';
        }))
      this.textMessage = "";
      this.firstMsg = false;
      return Observable.of(callbackPayload).map(o => o);
    }
  }

  onPublish(response) {

    console.log('on publish method')
    this.baseService.hideLoader();
    localStorage.removeItem('fileUploads')
    localStorage.removeItem('sendmsg')
    this.textMessage = "";
    this.firstMsg = false;
    this.sendSucess = 'sent';
  }

  initiateOneToOne(request: CreateOneOnOneRequest): Observable<CreateOneOnOneResponse> {
    let options = this.getHeaderForAPICall();

    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));

    let currentTime = this.baseService.generateMessagetime();
    let initiateOnetoOneUrl = environment.oAuthConfig.API_BASE_URL + 'users/current/onetoone';

    return this._http.post(initiateOnetoOneUrl, request, options)
      .map((response: Response) => <CreateOneOnOneResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }

  oldMessages(communityKey): Observable<GetOldMessageResponse> {
    let options = this.getHeaderForAPICall();

    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));
    let getoldMsgListUrl;
    let currentTime = this.baseService.generateMessagetime();

    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let global = this;
    
    if (localStorage.getItem('currentPath') == '/welcome-dashboard' && localStorage.getItem('OneOnOne') == 'Active') {
      getoldMsgListUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.COMMUNITIES + '/' + communityKey + '/' + ApiUrl.MESSAGES + ApiUrl.GET_OLD_MESSAGES_URL_PARAMS + this.channelData.userCommunityJabberId + '&CURRENT_TIMESTAMP=' + currentTime;
    }
    else if (localStorage.getItem('Selectedfollower')) {
      let followerData = JSON.parse(localStorage.getItem('Selectedfollower'))
      getoldMsgListUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.COMMUNITIES + '/' + communityKey + '/' + ApiUrl.MESSAGES + ApiUrl.GET_OLD_MESSAGES_URL_PARAMS + followerData.communityJabberId + '&CURRENT_TIMESTAMP=' + currentTime;
    } else {
      getoldMsgListUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.COMMUNITIES + '/' + communityKey + '/' + ApiUrl.MESSAGES + ApiUrl.GET_OLD_MESSAGES_URL_PARAMS + '&CURRENT_TIMESTAMP=' + currentTime;
    }

    return this._http.get(getoldMsgListUrl, options)
      .map((response: Response) => <GetOldMessageResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }

  updateMuteStatus(request: muteDetailsRequest): Observable<getMuteResponse> {

    let options = this.getHeaderForAPICall();

    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));
    //options.headers.append( 'Access-Control-Allow-Origin', '*');

    let details = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS))

    let muteUserUrl = environment.oAuthConfig.API_BASE_URL + "users/current/mychats/" + request.communityKey

    this.loggerService.info('mute request :   ', JSON.stringify(request))
    return this._http.put(muteUserUrl, request, options)
      .map((response: Response) => <getMuteResponse>response.json())
      //.do(data => this.loggerService.info('mute request Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  getFilteredMyChatsList(searchText: String): Observable<MyChatsListResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN));

    let currentTime = this.baseService.generateMessagetime();
    let getMychatListUrl = environment.oAuthConfig.API_BASE_URL + ApiUrl.GET_MYCHAT_LIST + '?page_size=100&page_number=1&search_text='+searchText+'&CURRENT_TIMESTAMP=' + currentTime;

    return this._http.get(getMychatListUrl, options)
      .map((response: Response) => <MyChatsListResponse>response.json())
      // .do(data => this.loggerService.info('Get mychat list Response: ' + data))
      .catch(this.handleError);
  }
}