import { Component, OnInit, Output, EventEmitter, ViewChild, Input, ViewChildren, ElementRef } from '@angular/core';
import { Router, NavigationEnd, Event as NavigationEvent } from '@angular/router';
declare var jQuery: any;
declare var $: any;

import { BaseComponent } from '@app/shared/base/base.component'
import * as Ps from 'perfect-scrollbar';
import { MatDialog, MatDialogRef } from '@angular/material';
import { PopUpString, DefaultColor, UserStrings, PassParamsToDrawer, connectionXmpp, Strings } from '@app/shared/base.constants';
import { Http } from '@angular/http';
import { DiscoverChannelsService } from '@app/community/discover/discover-channels/discover-channels.service';
import { DiscoverInterface } from '@app/community/discover/discover-channels/discover-interface';
import { LoggerService } from '@app/shared/logger/logger.service';
import { ProfileService } from '@app/profile/profile.service';

import {
  MediaPopupComponent, ImagePopupComponent, VideoPopupComponent, AudioOptionPopupComponent,
  locationStepOnePopupComponent, locationStepTwoPopupComponent, CameraShowTwoPopupComponent,
  RecordAudionPopupComponent, RecordAudioStopPopupComponent
} from '@app/dashboard/media-popup/media-popup.component';

import { AdminBroadcastedMessagesComponent } from '@app/dashboard/welcome-dashboard/admin-broadcasted-messages/admin-broadcasted-messages.component';
import { connect, connection } from '@assets/js/chat.js';
import { Subscription } from 'rxjs/Subscription';

import { Observable } from 'rxjs/Observable';

import { DashboardService } from '@app/dashboard/dashboard.service';
import { ToastrService } from 'ngx-toastr';

import { MyChatsListRequest, MyChatsListResponse } from '@app/dashboard/dashboard.messages'
import { BaseService } from '@app/shared/base.service';
import { CommunityService } from '@app/community/community.service';
import { AdminBroadcastMessagesComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';
import { flatten } from '@angular/compiler';
declare let MediaRecorder: any;
import { DatePipe } from '@angular/common';
import { ShowChannelProfileComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { ShowFollowerProfileComponent } from '@app/profile/user/show-follower-profile/show-follower-profile.component';
import { GetChannelDetailsResponse } from '@app/profile/profile.messages';
import { muteDetailsRequest } from '@app/dashboard/dashboard.messages';
import { FollowerAdminChatComponent } from '@app/dashboard/welcome-dashboard/follower-admin-chat/follower-admin-chat.component';

@Component({
  selector: 'app-welcome-dashboard',
  templateUrl: './welcome-dashboard.component.html',
  providers: [AdminBroadcastedMessagesComponent]
})

export class WelcomeDashboardComponent extends BaseComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  popUp: string;
  channelServiceData: any;
  adminBroadcastMsg: boolean;
  followerAdminChat: boolean;
  chatWindow: boolean;
  welcomeWindow: boolean = true;
  backArrow: boolean;
  clickedChannelName: any;
  clickedChannelImage: string;
  channelColor: string = DefaultColor.color;
  channelTopHeadColor: string = DefaultColor.color;
  catData: any;
  userDetails: any;
  myChatList = [];
  childTitle: any;
  showMyChatList: boolean = false;
  getMychatListRequest = new MyChatsListRequest();
  myChatChannelsList: any[];
  filename: string;
  file: any;
  fileToCompress: any;
  channelData: any;
  showChannelProfileSideNav: boolean = false;
  showAttachIcon: boolean = false;
  @ViewChild(AdminBroadcastedMessagesComponent)
  private adminMsgWindow: AdminBroadcastedMessagesComponent;
  clickedChnlDetails: any;
  channelPrivacy: string;
  @ViewChild(ShowChannelProfileComponent) showChnlProfile: ShowChannelProfileComponent;
  showChnlProfileDetails: any;
  @ViewChild(ShowFollowerProfileComponent)
  private memberProfile: ShowFollowerProfileComponent;
  currentTime: any;
  muteStatus: string = "Mute";
  isMute: boolean = false;
  @ViewChild('audioOptionChannelList') audioPlayerRef: ElementRef;
  @ViewChild(FollowerAdminChatComponent) FollowerAdminChatComponent: FollowerAdminChatComponent;
  searchText: string;
  constructor(
    public dialog: MatDialog,
    private communityService: CommunityService,
    private http: Http,
    public loggerService: LoggerService,
    public router: Router,
    public dashboardService: DashboardService,
    public toastr: ToastrService, public profileService: ProfileService) {
    super(loggerService, router, toastr
    );
  }

  ngOnInit() {
    this.currentTime = this.communityService.generateMessagetime();
    this.popUp = localStorage.getItem(PopUpString.GOT_IT);
    // localStorage.removeItem("createCommunityData   ");
    UserStrings.LOGGEDIN_USER_DETAILS = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS));

    this.userDetails = JSON.parse(localStorage.getItem('userDetails'))
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    // this.getMyChatList();
    if (UserStrings.LOGGEDIN_USER_DETAILS && UserStrings.LOGGEDIN_USER_DETAILS.user.userProfile.interests == '') {
      localStorage.setItem(Strings.NAVIGATE_FROM, Strings.REGISTRATION)
      this.router.navigate(['categories'])
    }
    else if (UserStrings.LOGGEDIN_USER_DETAILS && UserStrings.LOGGEDIN_USER_DETAILS.user.userProfile.state == '') {
      localStorage.setItem(Strings.NAVIGATE_FROM, Strings.REGISTRATION)
      this.router.navigate(['statefiled'])
    }

    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
    else if (connectionXmpp.connection == undefined && BaseComponent.onlineOffline) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          if (localStorage.getItem('createCommunityData') && (this.channelData.ownerId != this.userDetails.user.userId)) {
            this.showChannelChats(this.channelData)
          } else { localStorage.removeItem("createCommunityData"); }
          this.getMyChatList();
          //this.getLatestMyChatMsg();
        },
        (complete) => {
        }
      );
    }
    else {
      if (BaseComponent.onlineOffline) {
        if (localStorage.getItem('createCommunityData') && (this.channelData.ownerId != this.userDetails.user.userId)) {
          this.showChannelChats(this.channelData)
        } else { localStorage.removeItem("createCommunityData"); }
        this.getMyChatList();
        // this.getLatestMyChatMsg();
      } else {
        this.toastr.info('No internet connection, Please connect your internet', 'Info !!')
      }
    }
  }

  getLatestMyChatMsg() {
    connectionXmpp.connection.addHandler((msg) => {
      console.log('listner call in welcome dashboard');
      console.log(msg);
      let latestMsg;
      var global = this;
      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());

          for (let chk = 0; chk < global.myChatChannelsList.length; chk++) {
            if (latestMsg.communityId == global.myChatChannelsList[chk]['communityKey']) {

              global.myChatChannelsList[chk]['messageAt'] = latestMsg.createdDatetime;
              $('#time_' + latestMsg.communityId).html(global.dashboardService.timeSince(global.myChatChannelsList[chk]['messageAt']));

              if (latestMsg.messageType == "location") {
                global.myChatChannelsList[chk]['messageText'] = "Location";
                $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-pin'></i><b>Location</b>")
              }
              else if (latestMsg.mediaType == "audio") {
                global.myChatChannelsList[chk]['messageText'] = "Audio";
                $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-audio'></i><b>Audio</b>")
              }
              else if (latestMsg.mediaType == "video") {
                global.myChatChannelsList[chk]['messageText'] = "Video";
                // document.getElementById(latestMsg.communityId).innerHTML = <b>;
                $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-camera'></i><b>Video</b>")
              }
              else if (latestMsg.mediaType == "image") {
                global.myChatChannelsList[chk]['messageText'] = "<b>Image</b>";
                $('#' + latestMsg.communityId).html("<i class='zmdi zmdi-camera'></i><b>Image</b>")
              }
              else {
                // if(global.myChatChannelsList[chk]['ownerId']==global.userDetails.user.userId) && !mychat.messageText'
                global.myChatChannelsList[chk]['messageText'] = latestMsg.contentField1;
                $('#' + latestMsg.communityId).html(latestMsg.contentField1)
              }

              global.myChatChannelsList.sort(function (a, b) {
                return b.messageAt - a.messageAt;
              });
              
              if (global.myChatChannelsList[chk] && !(global.myChatChannelsList[chk].isMuted)) {

                if (global.audioPlayerRef) {
                  global.audioPlayerRef.nativeElement.play();
                  console.log("Audio Play " + latestMsg.contentField1)
                }
              }
              else
                console.log("Audio Mute " + latestMsg.contentField1);

              // global.myChatChannelsList[chk]['messageAt'] = latestMsg.createdDatetime;
              // global.myChatChannelsList[chk]['messageText'] = latestMsg.contentField1;

             
            }
          }
        });
      });
      // document.getElementById(latestMsg.communityId).innerHTML = latestMsg.contentField1;
      return true;
    }, null, 'message');
  }

  getChannels() {
    var ChatList = [];
    connectionXmpp.connection.pubsub.getSubscriptions(
      (iq) => {
        $(iq).find("subscription").each(function () {
          ChatList.push($(this).attr('node'));
        });
        this.myChatList = JSON.parse(JSON.stringify(ChatList));
        localStorage.setItem("ChatList", JSON.stringify(ChatList))
        if (!this.myChatList.length) {
          this.showMyChatList = true;
        } else {
          this.showMyChatList = false;
        }
      })
    $.LoadingOverlay('hide');
  }

  getMyChatList() {
    this.dashboardService.showLoader()
    this.dashboardService.getMyChatsList().subscribe(response => this.handleresponseOfGetMychatList(response),
      error => this.handleError(error));
  }

  handleresponseOfGetMychatList(response: MyChatsListResponse) {

    if (response.success) {
      this.dashboardService.hideLoader();
      console.log(response.myChats)
      this.myChatChannelsList = response.myChats;

      if (!this.myChatChannelsList.length) {
        this.showMyChatList = true;
      } else {
        for (let dt = 0; dt < this.myChatChannelsList.length; dt++) {
          if ((this.myChatChannelsList[dt]['ownerId'] == this.userDetails.user.userId) && !this.myChatChannelsList[dt]['messageText']) {
            this.myChatChannelsList[dt]['messageAt'] = this.myChatChannelsList[dt]['createddatetime'];
            // this.myChatChannelsList[dt]['messageText'] = "YOU CREATED CHANNEL";
          }
          $('#time_' + this.myChatChannelsList[dt]['communityKey']).html(this.dashboardService.timeSince(this.myChatChannelsList[dt]['createddatetime']))
        }
        this.myChatChannelsList.sort(function (a, b) {
          return b.messageAt - a.messageAt;
        });

        this.getLatestMyChatMsg();
        this.showMyChatList = false;
      }
      this.dashboardService.hideLoader();
      localStorage.setItem('mychatList', JSON.stringify(response.myChats));
    } else {
      this.dashboardService.hideLoader()
      this.toastr.error('Error to get Mychat list !!', 'Error')
    }
  }

  setChnlDashboardStyles() {
    let styles;
    styles = {
      'background': this.channelColor + " ! important",
    }
    return styles;
  }


  showChannelChats(mychat) {
    //mute
    if (mychat.isMuted) {
      this.muteStatus = "UmMute";
      this.isMute = true;
    } else {
      this.muteStatus = "Mute";
      this.isMute = false;
    }
    this.profileService.showLoader();
    this.profileService.getCommunityDetails(mychat.communityKey).subscribe(result => this.handleresponseOfGetCommunityDetails(result),
      error => this.handleError(error));
  }

  handleresponseOfGetCommunityDetails(result: GetChannelDetailsResponse) {
    let userId = this.userDetails.user.userId
    if (result.success) {
      let mychat = result.communityDetails;
      if (mychat.ownerId != userId) {
        this.showAttachIcon = false;
        this.clickedChannelName = mychat.communityName;
        this.clickedChannelImage = mychat.communityImageUrl;
        if (mychat.feed) {
          this.channelPrivacy = "RSS Feed Channel";
        } else {
          this.channelPrivacy = mychat.privacy + " Channel";
        }

        this.welcomeWindow = false;
        this.chatWindow = true;
        this.adminBroadcastMsg = true;
        this.followerAdminChat = false;
        this.backArrow = false;
        if (mychat.communityDominantColour.length > 7) {
          let hexColor = mychat.communityDominantColour;
          this.channelTopHeadColor = hexColor.slice(0, -2);
        } else if (mychat.communityDominantColour == "") {
          this.channelTopHeadColor = "#26b35a";
          this.channelColor = "#26b35a";
        }
        else {
          this.channelTopHeadColor = mychat.communityDominantColour;
        }
        this.channelColor = mychat.communityDominantColour;
        localStorage.setItem('createCommunityData', JSON.stringify(mychat))
        this.clickedChnlDetails = JSON.parse(localStorage.getItem('createCommunityData'))
        this.childTitle = 'follower';
        if (this.adminMsgWindow) {
          this.adminMsgWindow.ngOnInit()
        }
      }
      else {
        localStorage.setItem('createCommunityData', JSON.stringify(mychat))
        this.router.navigate(['channel-dashboard'])
      }
    }
  }


  openDrawer(name: string): void {
    if (name == PassParamsToDrawer.SHOWFOLLOWERADMINCHAT) {
      this.adminBroadcastMsg = false;
      this.followerAdminChat = true;
      this.backArrow = true;
      this.channelColor = 'transparent';
      if (this.clickedChnlDetails && this.clickedChnlDetails.communityDominantColour) {
        this.channelTopHeadColor = this.clickedChnlDetails.communityDominantColour;
      } else {
        this.channelTopHeadColor = 'transparent';
      }
      this.showAttachIcon = true;
    }
    else if (name == 'myChatReset') {
      localStorage.removeItem("createCommunityData");
      this.welcomeWindow = true;
      this.chatWindow = false;
      this.adminBroadcastMsg = false;
      this.followerAdminChat = false;
      this.backArrow = false;
      this.sidenavLeft.close();
      this.sidenavRight.close();
      this.setChnlDashboardStyles();
    }
    else if (name == 'editChannelProfile') {
      localStorage.setItem('closeDrawer', 'closeRight');
      this.showDrawer(name);
    }
    else if (name == 'successleave') {
      this.getMyChatList();
      localStorage.removeItem("createCommunityData");
      this.welcomeWindow = true;
      this.chatWindow = false;
      this.adminBroadcastMsg = false;
      this.followerAdminChat = false;
      this.backArrow = false;
      this.sidenavRight.close();
    }
    else if (name == 'setDashboard') {
      this.sidenavRight.close();
      this.showChannelChats(JSON.parse(localStorage.getItem('createCommunityData')))
    }
    // else if (name == PassParamsToDrawer.SHOWUSERPROFILE) {
    //   this.sidenavLeft.open();
    //   localStorage.setItem('closeDrawer', 'closeLeft');
    //   this.showDrawer(name);
    // }
    else {
      // this.showAttachIcon = false;
      // if (name == 'editChannelProfile') {
      //   localStorage.setItem('closeDrawer', 'closeRight');
      // } else {
      //   localStorage.setItem('closeDrawer', 'closeLeft');
      // }

      this.showDrawer(name);
      if (this.memberProfile) {
        this.memberProfile.ngOnInit()
      }
    }
  }

  backToAdminMsgs() {
    this.showAttachIcon = false;
    this.adminBroadcastMsg = true;
    this.followerAdminChat = false;
    this.backArrow = false;
    if (this.clickedChnlDetails && this.clickedChnlDetails.communityDominantColour) {
      this.channelColor = this.clickedChnlDetails.communityDominantColour;
      this.channelTopHeadColor = this.clickedChnlDetails.communityDominantColour;
    } else {
      this.channelColor = DefaultColor.color;
      this.channelTopHeadColor = DefaultColor.color
    }
  }

  openDiscoverPopUp() {
    if (!localStorage.getItem(PopUpString.GOT_IT)) {
      localStorage.setItem(PopUpString.GOT_IT, PopUpString.POP_UP);
      this.dialog.open(discoverListPopupComponent);
    }
  }

  showChannelProfileDrawer() {
    localStorage.setItem('closeDrawer', 'closeRight');
    this.showDrawer(PassParamsToDrawer.SHOWCHANNELPROFILE);
    if (this.showChnlProfile) {
      this.showChnlProfile.ngOnInit();
    }
  }

  openDialogVideo() {
    this.dialog.open(MediaPopupComponent);
  }


  showSearchDiv() {
    let searchDiv = document.getElementById("searchDiv");
    if (searchDiv.style.display == "none") {
      searchDiv.style.display = "block";
      this.getChannels();
    } else {
      searchDiv.style.display = "none";
    }
    this.getMyChatList();
    this.searchText = '';
  }

  imageUpload(event: any) {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'))
    let userId = this.userDetails['user']['username']
    this.filename = event.target.files[0]['name'];
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    let index = this.filename.lastIndexOf(".");
    var strsubstring = this.filename.substring(index, this.filename.length);
    this.fileToCompress = event.target.files[0];

    if (strsubstring == '.zip' || strsubstring == '.mp3' || strsubstring == '.mp4' || strsubstring == '.gif' || strsubstring == '.mov') {
      this.toastr.info('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Info !!');

    } else if (event.target.files[0]['size'] <= 10000000 && (strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png')) {

      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      this.file = event.target.files[0];
      let fileUrl;
      let dialogRef;
      reader.onload = (e: Event) => {
        let fileUrl = e.target['result'];
        dialogRef = this.dialog.open(ImagePopupComponent);
        dialogRef.componentInstance.uploadState = "gallery";
        dialogRef.componentInstance.imageUrl = fileUrl;
        if (localStorage.getItem('OneOnOne') !== null) {
          dialogRef.componentInstance.communityKey = this.channelData.communityKey + "_" + userId;
        }
        else {
          dialogRef.componentInstance.communityKey = this.channelData.communityKey;

        }
        dialogRef.componentInstance.file = this.file;
        dialogRef.componentInstance.filename = this.filename;
        BaseService.fileToCompress = this.fileToCompress
        new Observable(this.communityService.compressFile).subscribe(result => {
          dialogRef.componentInstance.fileToCompress = result
        })

        const sub = dialogRef.componentInstance.onUpload.subscribe((data) => {
          if (data == 'sendImage') {
            if (localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') {
              this.FollowerAdminChatComponent.showMessages();
            } else {
              console.log('not send message yet')
            }
          }
          dialogRef.close();
        });
        dialogRef.afterClosed().subscribe(() => {
          sub.unsubscribe();
        });
      }
    } else {
      this.toastr.info('Image size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    }
  }

  videoUpload(event: any) {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    }
    let base64String;
    let dialogRef;
    let videoExtension = event.target.files[0]['type']
    if (event.target.files[0]['size'] > 10000000) {
      this.toastr.info('Video size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    }
    if (videoExtension == 'video/mp4') {
      this.filename = event.target.files[0]['name'];
      var videoFileObj = event.target.files[0]
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (e: Event) => {
        base64String = e.target['result'];
        if (base64String != '') {
          dialogRef = this.dialog.open(VideoPopupComponent);
          dialogRef.componentInstance.uploadState = "gallery";
          dialogRef.componentInstance.videoUrl = base64String;
          dialogRef.componentInstance.chanlKey = this.channelData.communityKey;
          dialogRef.componentInstance.videoFileObj = videoFileObj;
          dialogRef.componentInstance.filename = this.filename
        } else {
        }
      }
    } else {
      this.toastr.info('Video format should be mp4', 'Info !!'); return false;
    }
  }

  locationStepOnePopup() {
    let dialogRef = this.dialog.open(locationStepOnePopupComponent);
    dialogRef.componentInstance.chanlKey = this.channelData.communityJabberId;

    const sub = dialogRef.componentInstance.onList.subscribe((data) => {
      if (data == 'stepOneLocation') {
        if (localStorage.getItem('Selectedfollower')) {
          this.FollowerAdminChatComponent.showMessages();
        } else {
          console.log('else in location popup')
        }
        dialogRef.close();
      }
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  openDialogCameraOption(optionFor) {
    let dialogRef = this.dialog.open(CameraShowTwoPopupComponent);
    if (optionFor == "audioCapture") {
      dialogRef.componentInstance.optionFor = optionFor;
    } else if (optionFor == "videoImageCapture") {
      dialogRef.componentInstance.optionFor = optionFor;
    }

    const sub = dialogRef.componentInstance.onUploadSuccess.subscribe((data) => {
      console.log(data)
      if (data == 'imageUploaded') {
        if (localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') {
          this.FollowerAdminChatComponent.showMessages();
        } else {
          console.log('else in location popup')
        }
      }
      dialogRef.close();
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  onMuteClick() {
    let seletedCommunity = JSON.parse(localStorage.getItem('createCommunityData'));
    let muteChannelDetails: muteDetailsRequest = new muteDetailsRequest();
    if (this.muteStatus == "UmMute") {
      muteChannelDetails.muteStatus = "false";
      this.muteStatus = "Mute";
      this.isMute = false;
    }
    else {
      muteChannelDetails.muteStatus = "true";
      this.muteStatus = "UmMute";
      this.isMute = true;
    }
    muteChannelDetails.communityKey = seletedCommunity.communityKey;
    this.dashboardService.updateMuteStatus(muteChannelDetails).subscribe(response => this.muteHandler(response),
      error => this.handleError(error));
  }

  muteHandler(response) {

    this.getMyChatList();
  }
  searchMyChat() {
    console.log("Search MyChat " + this.searchText);
    this.dashboardService.showLoader()
    this.dashboardService.getFilteredMyChatsList(this.searchText).subscribe(response => this.handleresponseOfGetMychatList(response),
      error => this.handleError(error));

  }

}


@Component({
  selector: 'app-discoverList-popup',
  template: `
 <div class="filterToDiscover" id="filterToDiscover">
        <div class="filterPopup pad-all-md-lg mrgn-b-lg">
          <p> <img src="../../assets/img/filter_24_white_yellowdot.png" alt="filterYellowImg"></p>
          <h5>Tap on filter to discover channels as per your interests.</h5>
        </div>
        <div class="text-center">
          <button mat-button class="btnGreen text-uppercase"  (click)="dialogRef.close()" type="submit">Got It</button>
        </div>
</div>
`
})
export class discoverListPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<discoverListPopupComponent>, public dialog: MatDialog) { }
  ngOnInit() {
  }
}