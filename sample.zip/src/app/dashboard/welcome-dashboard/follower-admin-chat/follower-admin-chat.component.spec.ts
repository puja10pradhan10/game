// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { FollowerAdminChatComponent } from './follower-admin-chat.component';

// describe('FollowerAdminChatComponent', () => {
//   let component: FollowerAdminChatComponent;
//   let fixture: ComponentFixture<FollowerAdminChatComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ FollowerAdminChatComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(FollowerAdminChatComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
