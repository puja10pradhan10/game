import { Component, OnInit, ViewChild, ElementRef, OnChanges } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { DefaultColor, connectionXmpp } from '@app/shared/base.constants';
import { DashboardService } from '@app/dashboard/dashboard.service';
import * as $ from 'jquery';
import { CreateOneOnOneRequest, CreateOneOnOneResponse, ForwardListResponse } from '@app/dashboard/dashboard.messages';
import { showImgComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { BaseComponent } from '@app/shared/base/base.component';
import { LoggerService } from '@app/shared/logger/logger.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-follower-admin-chat',
  templateUrl: './follower-admin-chat.component.html',
  styleUrls: ['./follower-admin-chat.component.scss']
})

export class FollowerAdminChatComponent extends BaseComponent implements OnInit {
  channelData: any;
  UserDetails: any;
  UserId: string;
  adminMessage = [];
  followerMessage: any;
  messageText: string;
  communityCreatedTime: boolean = false;
  textMessage: string
  createOneToOne: any = new CreateOneOnOneRequest()
  textMessagesArrayList = [];
  message = [];
  subscribedChannels = [];

  constructor(public loggerService: LoggerService, public toastr: ToastrService, public router: Router, public dialog: MatDialog, private dashboardService: DashboardService) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
    else if (connectionXmpp.connection == undefined && BaseComponent.onlineOffline) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          this.latestMessage();
          // this.chnlDetails();
          this.getOldChatMessages();
        },
        (complete) => {
        }
      );
    } else {
      this.latestMessage();
      // this.chnlDetails();
      this.getOldChatMessages();
    }

    this.textMessage = "";
    localStorage.setItem("ChatList", "OneOnOne")
    this.UserDetails = JSON.parse(localStorage.getItem('userDetails'));
    this.UserId = this.UserDetails['user']['userId'];
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let global = this;
    $(function () {
      $("#msgTextarea").keypress(function (e) {
        if (e.which == 13 && !e.shiftKey) {
          if (global.textMessage != '')
            global.initiateOneToOne();
          $(this).val("");
          e.preventDefault();
        }
      });
    })
  }

  ngOnChanges() { }

  latestMessage() {
    this.dashboardService.showLoader()
    localStorage.setItem("ChatList", "OneOnOne")
    connectionXmpp.connection.addHandler((msg) => {
      console.log('listner call in 1:1 follower-admin');
      console.log(msg);
      let latestMsg;
      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());
        });
      });
      if (latestMsg.jabberId == this.channelData.userCommunityJabberId) {
        if (this.channelData.isMember) {
          this.chnlDetails();
        }
      } else {
        console.log('not match');
      }
      this.dashboardService.hideLoader()
      return true;
    }, null, 'message')
  }

  getOldChatMessages() {
    this.dashboardService.showLoader();
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    this.dashboardService.oldMessages(this.channelData.communityKey).subscribe(response => this.handleresponseOfGetOldChatMessages(response),
      error => this.handleError(error));
  }

  handleresponseOfGetOldChatMessages(response) {
    this.dashboardService.hideLoader();
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }
    console.log(response);
    this.followerMessage = response.messagesList.slice().reverse();

    if (response.success && response.messagesList.length) {
      this.dashboardService.hideLoader();
      this.followerMessage = response.messagesList.slice().reverse();
      localStorage.setItem('oldMessages', JSON.stringify(this.followerMessage));

      for (let i = 0; i < this.followerMessage.length; i++) {
        this.followerMessage[i].createdDatetime = this.dashboardService.timeSince(this.followerMessage[i].createdDatetime)
      }
    } else {
      this.dashboardService.hideLoader();
      console.log('not send message yet');
    }
  }


  chnlDetails() {
    localStorage.setItem("ChatList", "OneOnOne")
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }

    new Observable(this.dashboardService.getMessages).subscribe(
      (res) => {
        this.followerMessage = res
        for (let i = 0; i < this.followerMessage.length; i++) {
          this.followerMessage[i].createdDatetime = this.dashboardService.timeSince(this.followerMessage[i].createdDatetime)
        }
        $(document).ready(function () {
          if ($("#mediaAudio").length || $("#videoMedia").length) {
            $('#mediaAudio, #videoMedia').mediaelementplayer({
              success: function (media) {
                var isNative = /html5|native/i.test(media.rendererName);
                //var isYoutube = ~media.rendererName.indexOf('youtube');
              }
            });
            $('#mediaAudio, #videoMedia').each(function () {
              $(this).remove();
            });
          }
        });

        // $(".messageScroll").animate({ scrollTop: $(document).height() }, "fast");
        // message always show bottom code jquery
        $("#style-1").animate({ scrollTop: $('#style-1').prop("scrollHeight") }, 1000);
        this.dashboardService.hideLoader()
      })
    this.dashboardService.hideLoader();
  }

  setChnlDashboardStyles() {
    let styles;
    styles = {
      'background-color': DefaultColor.color,
    }
    return styles;
  }

  openDialogDelete() {
    this.dialog.open(DeletePopupComponent);
  }

  openDialogFarward(messageText, mediaType) {
    let forward = this.dialog.open(FollowerOneOnOneForwardPopupComponent);
  }

  initiateOneToOne() {
    if (this.channelData.userCommunityJabberId && this.channelData.userCommunityJabberId != '') {
      this.sendOneToOneMsg(this.channelData.userCommunityJabberId, "", "plainMessage", "", "", "", "", this.textMessage);
    } else {
      this.createOneToOne.communityKey = this.channelData.communityKey;
      this.createOneToOne.OneOnOneKey = "temp";
      this.createOneToOne.memberId = this.channelData.ownerId;
      this.createOneToOne.userDetails.username = this.UserDetails.user.username;
      this.createOneToOne.userDetails.accountType = 0;
      this.createOneToOne.userDetails.city = this.UserDetails.user.userProfile.city;
      this.createOneToOne.userDetails.country = this.UserDetails.user.userProfile.country;
      this.createOneToOne.userDetails.imageBigthumbUrl = this.UserDetails.user.userProfile.imageBigthumbUrl;
      this.createOneToOne.userDetails.imageSmallthumbUrl = this.UserDetails.user.userProfile.imageSmallthumbUrl;
      this.createOneToOne.userDetails.imageUrl = this.UserDetails.user.userProfile.imageUrl;
      this.dashboardService.initiateOneToOne(this.createOneToOne).subscribe(response => this.handleresponseOfInitiateOneToOne(response),
        error => this.handleError(error));
    }
  }

  handleresponseOfInitiateOneToOne(res: CreateOneOnOneResponse) {
    let jabberId = res.myChat.communityJabberId;
    // userCommunityJabberId

    let tempArray = JSON.parse(localStorage.getItem('createCommunityData'));
    tempArray.userCommunityJabberId = res.myChat.communityKey;
    localStorage.setItem('createCommunityData', JSON.stringify(tempArray))

    if (res.success) {
      this.sendOneToOneMsg(res.myChat.communityJabberId, "", "plainMessage", "", "", "", "", this.textMessage);
    } else {
      this.toastr.info('Error to initiate one to one.', 'Info !!');
    }
  }

  sendOneToOneMsg(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText, storageBucketName, textMessage) {
    this.textMessage = "";
    if (connectionXmpp.connection != undefined && BaseComponent.onlineOffline) {
      this.dashboardService.sendOnetoOneMessage(nodeKey, messageKey, source, messageSmallThumbUrl, actualMessageUrl, messageText,
        storageBucketName, textMessage).subscribe(response => {
          console.log(response);
          localStorage.setItem('tempArr', JSON.stringify(response))

          if (source == 'plainMessage') {
            this.showMessages()
          }
        })

      // this.latestMessage();
      // if (source == 'plainMessage' || source == 'location') {
      //   setTimeout(() => {
      //     this.chnlDetails();
      //   }, 1500);
      // } else {
      //   setTimeout(() => {
      //     this.chnlDetails();
      //   }, 3000);
      // }
    } else {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
  }

  showMessages() {
    this.dashboardService.hideLoader();
    this.followerMessage.push(JSON.parse(localStorage.getItem('tempArr')))
    localStorage.setItem('oldMessages', JSON.stringify(this.followerMessage));
    localStorage.removeItem('tempArr');
  }

  deleteMessage(message) {
    localStorage.setItem("msgClicked", JSON.stringify(message))
    this.dialog.open(confirmDeleteMesageAdminOneOnOnePopupComponent);
  }

  userImagePopup(channelProfileImageUrl, srcType) {
    this.dialog.open(showImgComponent, {
      panelClass: 'my-full-screen-dialog',
      data: {
        imgSrc: channelProfileImageUrl,
        srcType: srcType
      }
    });
  }

  goToLocation(mapData) {
    this.showLocation(mapData);
  }
}


@Component({
  selector: 'app-delete-message-confirm-popup',
  template: `
  <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
<h2 mat-dialog-title>Are you sure you want to delete this message? </h2>
<mat-dialog-actions class="twoBtn">
  <button type="button" class="btnPopup btnBlack" (click)="onNoClick('no')" mat-dialog-close>No</button>
  <button type="submit" class="btnPopup btnRed" (click)="yesClick('yes')" mat-dialog-close>Yes</button>
</mat-dialog-actions>
</div>`
})
export class confirmDeleteMesageAdminOneOnOnePopupComponent implements OnInit {
  UserDetails: any;
  UserId: string;
  constructor(private dashboardService: DashboardService, public dialogRef: MatDialogRef<confirmDeleteMesageAdminOneOnOnePopupComponent>, private toastr: ToastrService,
    public dialog: MatDialog, private router: Router) { }
  ngOnInit() {
    this.UserDetails = JSON.parse(localStorage.getItem('userDetails'));
    this.UserId = this.UserDetails['user']['username'];
  }
  onNoClick(option: string): void {
    this.dialogRef.close(option);
  }
  debuggingMode: true;

  yesClick(option: string): void {
    this.dashboardService.showLoader()

    let message = JSON.parse(localStorage.getItem('msgClicked'))
    let channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    let nodeName: string;
    let node: string;
    nodeName = channelData.communityKey + '_' + this.UserId
    connectionXmpp.connection.pubsub.items(nodeName, function (status) {
      $(status).find("items").each(function () {
        node = $(this).attr("node")
        $(status).find("item").each(function () {
          connectionXmpp.connection.pubsub.deleteItem(
            node,
            message.messageGuid,
            (status) => {
            }
          );
        });
      });
      this.dashboardService.hideLoader()
    });
  }
}

@Component({
  selector: 'app-delete-message-popup',
  template: `
 <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Delete Message? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" mat-dialog-close> Cancel</button>
    <button type="submit" class="btnPopup btnRed" mat-dialog-close> Delete</button>
  </mat-dialog-actions>
  </div>
`
})
export class DeletePopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<DeletePopupComponent>, public dialog: MatDialog) { }
  ngOnInit() {
  }
}

@Component({
  selector: 'app-delete-message-popup',
  template: `
  <div class="forwardMsgPopup checkboxCss">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn"><i class="zmdi zmdi-close"></i></button><span> Forward Message to</span>
  </mat-dialog-actions>
  <mat-dialog-content>
      <div class="green-input-line">
              <mat-form-field class="full-wid searchOuter">
                  <span matPrefix><i class="zmdi zmdi-search"></i></span>
                      <input matInput placeholder="Search Followers" value="">
              </mat-form-field>
          </div>
      <div class="forwardMsgContent pad-all-md-lg">
          <mat-list class="mat-pad-none mrgn-none">
               <mat-list-item class="mrgn-b-sm">
                  <mat-checkbox matListAvatar>
                   <img matListAvatar src="assets/img/agri_business.jpg" />
                   <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
                  </mat-checkbox>
               </mat-list-item>
               <mat-list-item class="mrgn-b-sm">
               <mat-checkbox matListAvatar>
                <img matListAvatar src="assets/img/agri_business.jpg" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
               </mat-checkbox>
            </mat-list-item>
          </mat-list>
      </div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
        <div class="forwardBtn">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-mail-send"></i>
              </a>
          </div>
  </mat-dialog-actions>
</div><!-- end forward msg -->
`
})

export class FollowerOneOnOneForwardPopupComponent extends BaseComponent implements OnInit {

  constructor(public loggerService: LoggerService, public toastr: ToastrService, private dashboardService: DashboardService, public router: Router, public dialogRef: MatDialogRef<FollowerOneOnOneForwardPopupComponent>, public dialog: MatDialog) {
    super(loggerService, router, toastr)
  }

  ngOnInit() { }
}
