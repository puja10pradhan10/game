import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef, OnChanges, ChangeDetectorRef, NgZone } from '@angular/core';
import { connect, connection } from '@assets/js/chat.js';
import { DefaultColor, connectionXmpp } from '@app/shared/base.constants';
import { Observable } from 'rxjs/Observable';
import { BaseComponent } from '@app/shared/base/base.component';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { LoggerService } from '@app/shared/logger/logger.service';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { BaseService } from '@app/shared/base.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { CreateOneOnOneResponse, ForwardListResponse, GetOldMessageResponse } from '@app/dashboard/dashboard.messages';
import { showImgComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';

//jquery declare
declare var jQuery: any;
declare var $: any;
@Component({
  selector: 'app-admin-broadcasted-messages',
  templateUrl: './admin-broadcasted-messages.component.html',
  styleUrls: ['./admin-broadcasted-messages.component.scss']
})
export class AdminBroadcastedMessagesComponent extends BaseComponent implements OnInit {
  @Input() title: string;
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  channelColor: string;
  channelData: any;
  adminBroadcastMessages: any;
  firstMsg: boolean = false;
  timeInmillis: string;
  communityCreatedTime: boolean = false;
  channelTopHeadColor: string;
  @Input() clickedChnlDetails: any;
  @ViewChild('audioOption') audioPlayerRef: ElementRef;

  constructor(public router: Router, public loggerService: LoggerService, private dashboardService: DashboardService, public baseService: BaseService,
    public dialog: MatDialog, public toastr: ToastrService, private ref: ChangeDetectorRef, private zone: NgZone) {
    super(loggerService, router, toastr);

  }

  ngOnChanges(): void {
    this.adminBroadcastMessages = [];
    localStorage.removeItem('adminBroadcastMessages')
  }

  ngOnInit() {
    localStorage.removeItem('OneOnOne')
    localStorage.removeItem('ChatList')
    this.channelColor = DefaultColor.color;
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    this.channelColor = this.channelData.communityDominantColour;
    localStorage.removeItem('adminBroadcastMessages')
    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!');
    }
    else if (connectionXmpp.connection == undefined && BaseComponent.onlineOffline) {
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          if (this.channelData.isMember) {
            this.chnlDetails();
            this.latestMessage();
          } else {
            this.getOldMessages();
          }
        },
        (complete) => {
        }
      );
    } else {
      if (this.channelData.isMember) {
        this.chnlDetails();
        this.latestMessage();
      } else {
        this.getOldMessages();
      }
    }
  }

  chatWithAdmin() {
    localStorage.setItem('OneOnOne', 'Active')
    this.notify.emit('showFollowerAdminChat');
  }

  getOldMessages() {
    this.dashboardService.oldMessages(this.channelData.communityKey).subscribe(response => this.handleresponseOfOldMessages(response),
      error => this.handleError(error));
  }

  handleresponseOfOldMessages(response: GetOldMessageResponse) {
    let reverseoldMessageList = [];
    this.adminBroadcastMessages = [];
    this.adminBroadcastMessages = response.messagesList;

    if (response.success && response.messagesList.length) {
      this.firstMsg = false;
      // reverseoldMessageList = response.messagesList.slice().reverse()
      this.adminBroadcastMessages = response.messagesList.slice().reverse();
      // this.latestMessage();
      for (let i = 0; i < this.adminBroadcastMessages.length; i++) {
        this.adminBroadcastMessages[i].createdDatetime = this.dashboardService.timeSince(this.adminBroadcastMessages[i].createdDatetime)
      }
    } else {
      // this.latestMessage();
      console.log('no message broadcast yet!!')
    }

  }

  latestMessage() {
    connectionXmpp.connection.addHandler((msg) => {
      console.log('listner call in follower admin broadcasted msg');
      console.log(msg);
      let latestMsg;
      $(msg).each(function () {
        $(msg).find("title").each(function () {
          latestMsg = JSON.parse($(this).html());
        });
      });
      if (latestMsg.communityId == this.channelData.communityKey) {
        // this.adminBroadcastMessages.push(latestMsg)
        // for (let i = 0; i < this.adminBroadcastMessages.length; i++) {
        //   this.adminBroadcastMessages[i].createdDatetime = this.dashboar...dService.timeSince(this.adminBroadcastMessages[i].createdDatetime)
        // }
        // let myChatList:any = JSON.parse( localStorage.getItem('mychatList') );
        // let currentChannelData;
        // for (var i=0; i < myChatList.length; i++ ) {
        //   if( myChatList[i].communityKey == latestMsg.communityId )
        //     currentChannelData = myChatList[i];
        //     break;
        // }
        // if(currentChannelData && !currentChannelData.isMuted){
        //     this.audioPlayerRef.nativeElement.play(); 

        // }
        if (this.channelData.isMember) {
          this.chnlDetails();
        }
      } else {
        console.log('not match');

      }
      return true;
    }, null, 'message')
  }

  chnlDetails() {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.channelData.communityCreatedTimestamp != undefined) {
      this.communityCreatedTime = true;
    } else {
      this.communityCreatedTime = false;
    }

    new Observable(this.dashboardService.getMessages).subscribe(
      (res) => {
        console.log(res)
        // if(!this.channelData.isMuted)
        //   this.audioPlayerRef.nativeElement.play();
        this.adminBroadcastMessages = res;
        // this.ref.detectChanges();
        for (let i = 0; i < this.adminBroadcastMessages.length; i++) {
          this.adminBroadcastMessages[i].createdDatetime = this.dashboardService.timeSince(this.adminBroadcastMessages[i].createdDatetime)
        }
        $(document).ready(function () {
          if ($("#audioMsg").length || $("#videoMsg").length) {
            $('#videoMsg, #audioMsg').mediaelementplayer({
              // Configuration
              success: function (media) {
                var isNative = /html5|native/i.test(media.rendererName);
                // var isYoutube = ~media.rendererName.indexOf('youtube');
              }
            });

            $('#videoMsg, #audioMsg').each(function () {
              $(this).remove();
            });
          }
        });

        // message always show bottom code
        $("#style-1").animate({ scrollTop: $('#style-1').prop("scrollHeight") }, 1000);
        // $(".messageScrollWithoutTextarea").animate({ scrollTop: $(document).height() }, "fast");

      })
  }
  openDialogFarward(messageText, mediaType) {
    let forward = this.dialog.open(FollowerDashboardForwardPopupComponent);
  }

  userImagePopup(channelProfileImageUrl, srcType) {
    this.dialog.open(showImgComponent, {
      panelClass: 'my-full-screen-dialog',
      data: {
        imgSrc: channelProfileImageUrl,
        srcType: srcType
      }
    });
  }

  goToRSSfeed(link) {
    window.open(link, '_blank');

  }

  goToLocation(mapData) {
    this.showLocation(mapData);
  }
}



@Component({
  selector: 'app-delete-message-popup',
  template: `
  <div class="forwardMsgPopup checkboxCss">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn"><i class="zmdi zmdi-close"></i></button><span> Forward Message to</span>
  </mat-dialog-actions>
  <mat-dialog-content>
      <div class="green-input-line">
              <mat-form-field class="full-wid searchOuter">
                  <span matPrefix><i class="zmdi zmdi-search"></i></span>
                      <input matInput placeholder="Search Followers" value="">
              </mat-form-field>
          </div>
      <div class="forwardMsgContent pad-all-md-lg">
          <mat-list class="mat-pad-none mrgn-none">
               <mat-list-item class="mrgn-b-sm">
                  <mat-checkbox matListAvatars>
                   <img matListAvatar src="assets/img/agri_business.jpg" />
                   <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
                  </mat-checkbox>
               </mat-list-item>
               <mat-list-item class="mrgn-b-sm">
               <mat-checkbox matListAvatars>
                <img matListAvatar src="assets/img/agri_business.jpg" />
                <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">Amit Shah</h4>
               </mat-checkbox>
            </mat-list-item>
          </mat-list>
      </div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
        <div class="forwardBtn">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-mail-send"></i>
              </a>
          </div>
  </mat-dialog-actions>
</div><!-- end forward msg -->
`
})

export class FollowerDashboardForwardPopupComponent extends BaseComponent implements OnInit {

  constructor(public loggerService: LoggerService, public toastr: ToastrService, private dashboardService: DashboardService, public router: Router, public dialogRef: MatDialogRef<FollowerDashboardForwardPopupComponent>, public dialog: MatDialog) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
  }
}
