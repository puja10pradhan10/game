// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { AdminBroadcastedMessagesComponent } from './admin-broadcasted-messages.component';

// describe('AdminBroadcastedMessagesComponent', () => {
//   let component: AdminBroadcastedMessagesComponent;
//   let fixture: ComponentFixture<AdminBroadcastedMessagesComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ AdminBroadcastedMessagesComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AdminBroadcastedMessagesComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
