export class messagesList {
    contentField1: string;
    createdDatetime: string;
    id: string;
    jabberId: string;
    mediaType: string;
    messageType: string;
    senderBigThumbnailUrl: string;
    senderFirstName: string;
    senderId: string;
    senderImageUrl: string;
    senderLastActiveDatetime: string;
    senderLastName: string;
    senderProfilestatus: string;
    senderRole: string;
    senderSmallThumbnailUrl: string;
    senderUserName: 288629731637687;
    userRole: string;
}

export class commonChnlList {
    communityCategories: string;
    communityCreatedTimestamp: string;
    communityDesc: string;
    communityDominantColour: string;
    communityImageBigThumbUrl: string;
    communityImageSmallThumbUrl: string;
    communityImageUrl: string;
    communityJabberId: string;
    communityKey: string;
    communityName: string;
    communityScore: number;
    groupRole: string;
    isMember: string;
    ownerFirstName: string;
    ownerId: string;
    ownerImageUrl: string;
    ownerLastName: string;
    ownerName: string;
    privacy: string;
    totalMembers: number
    type: string;
}

export class oneToOneUserDetails {
    username: string;
    accountType: number;
    city: string;
    country: string;
    imageBigthumbUrl: string;
    imageSmallthumbUrl: string;
    imageUrl: string;
}
export class oneToOneMychat {
    communityCategories: string;
    communityDesc: string;
    communityDominantColour: string;
    communityImageBigThumbUrl: string;
    communityImageSmallThumbUrl: string;
    communityImageUrl: string;
    communityJabberId: string;
    communityKey: string;
    communityName: string;
    createddatetime: string;
    imageUrl: string;
    isMember: string;
    memberCount: number;
    messageAt: string;
    ownerId: string;
    ownerImageUrl: string;
    ownerName: string;
    privacy: string;
    unreadMessagesCount: number;
}

export class oneToOneUserMychat {
    communityImageBigThumbUrl: string;
    communityImageSmallThumbUrl: string;
    communityImageUrl: string;
    communityJabberId: string;
    communityKey: string;
    communityName: string;
    joinedTime: string;
    lastName: string;
    profileStatus: string;
    userId: string;
    userName: string;
    unreadMessagesCount: number;
}