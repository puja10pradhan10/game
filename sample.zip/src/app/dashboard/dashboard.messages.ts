import { BaseRequest, BaseResponse } from '@app/shared/base.messages';
import { messagesList, commonChnlList, oneToOneMychat, oneToOneUserDetails, oneToOneUserMychat } from '@app/dashboard/dashboard.entities'
// let oldMessagesList = new messagesList();

export class MyChatsListRequest extends BaseRequest {
    userName: string;
}

export class MyChatsListResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    myChats: any;

}

export class GetOldMessageResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    oldMessagesList = new messagesList();
    messagesList: any = [this.oldMessagesList];
}


export class CommonChannelResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    commonChnlList = new commonChnlList();
    communities: any = [this.commonChnlList];

}
export class OneOnOneUserListResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    oneToOneUserMychat = new oneToOneUserMychat();
    myChats: any = [this.oneToOneUserMychat];
}

export class ForwardListResponse extends BaseResponse {

}
export class CreateOneOnOneRequest extends BaseRequest {
    communityKey: string;
    oneToOneKey: string;
    memberId: string;
    // userData = new oneToOneUserDetails();
    userDetails: any = new oneToOneUserDetails();

}
export class CreateOneOnOneResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    myChatList = new oneToOneMychat();
    myChat: any = this.myChatList;
    oneToOneKey: string;
}

export class MessagePayload {
    id: string;
    mediaType: string;
    messageType: string;
    contentField1: string;
    contentField2: string;
    contentField3: string;
    contentField4: string;
    contentField5: string;
    contentField6: string;
    contentField7: string;
    contentField8: string;
    contentField9: string;
    contentField10: string;
    senderId: string;
    communityId: string;
    jabberId: string;
    createdDatetime: string;
    deletedDatetime: string;
    hiddenDatetime: string;
    hiddenbyUserId: string;
    deletedbyUserId: string;
    messageStatus: string = 'sent';
}

export class getMuteResponse extends BaseResponse {
    requestId: string;
    responseCode: number;
    success: boolean;
    timeInMills: number;
}

export class muteDetailsRequest extends BaseRequest {
    muteStatus: string;
    communityKey: string;

}