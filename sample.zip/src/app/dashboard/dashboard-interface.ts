export interface FollowerListInterface {
    id: any;
    personName: any;
    image_url: any;
}