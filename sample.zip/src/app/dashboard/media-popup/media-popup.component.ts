import { Component, OnInit, Output, EventEmitter, ViewChild, Inject, Optional, ElementRef, Pipe, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AdminFollowerChatComponent } from '@app/dashboard/channel-dashboard/admin-follower-chat/admin-follower-chat.component';
import { AdminBroadcastMessagesComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';
import { FollowerAdminChatComponent } from '@app/dashboard/welcome-dashboard/follower-admin-chat/follower-admin-chat.component';


declare let MediaRecorder: any;
import { CommunityService } from '@app/community/community.service';
import { BaseService } from '@app/shared/base.service';
import { Observable } from 'rxjs/Observable';
import { ToastrService } from 'ngx-toastr';
import ImageCompressor from 'image-compressor.js';
/// <reference types="googlemaps" />
declare var google: any;

import { google } from '@google/maps';
// import { } from '@types/googlemaps';
import { error } from 'util';
import { OneOnOneUserListResponse } from '@app/dashboard/dashboard.messages';
import { DashboardService } from '@app/dashboard/dashboard.service';
declare var jQuery: any;
declare var $: any;
import { BaseComponent } from '@app/shared/base/base.component';
import { Router } from '@angular/router';
import { LoggerService } from '@app/shared/logger/logger.service';
import { Jsonp } from '@angular/http';

@Component({
  selector: 'app-media-popup',
  templateUrl: './media-popup.component.html',
  styleUrls: ['./media-popup.component.scss']
})
export class MediaPopupComponent extends BaseComponent implements OnInit {


  // @ViewChild(AdminFollowerChatComponent) AdminFollowerChatComponent: AdminFollowerChatComponent;
  constructor(public router: Router, public loggerService: LoggerService, public toastr: ToastrService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
  }

}


@Component({
  selector: 'app-Image-overlay-option-popup',
  template: `
 <div class="whiteOuter overlayOptionPopup">
    <mat-dialog-actions class="pad-all-sm">
        <button mat-dialog-close class="closeBtn"><i class="zmdi zmdi-close"></i></button>
    </mat-dialog-actions>
    <mat-dialog-content>
       <mat-list>
       <ng-container *ngIf="optionFor=='videoImageCapture'">
          <mat-list-item (click)="captureCameraImage()"><i class="zmdi zmdi-camera"></i> Take a Picture</mat-list-item>
          <mat-list-item (click)="recordCameraVideo()" (click)="dialogRef.close()"><i class="zmdi zmdi-videocam"></i> Record a Video</mat-list-item>
          </ng-container>
       <ng-container *ngIf="optionFor=='audioCapture'">
          <mat-list-item (click)="recordUploadAudio('byMicrophone')" (click)="dialogRef.close()"><i class="zmdi zmdi-mic"></i> Record a Audio</mat-list-item>
          <mat-list-item (click)="audiofileInput.click()">
          <a><input #audiofileInput id="file-input" name="messageImage" accept="*" type="file" style="display:none;" 
          (change)="audioUpload($event)" (click)="audiofileInput.value = null" />
            <span><i class="zmdi zmdi-picture-in-picture"></i> Choose Audio from gallery</span> </a>
          </mat-list-item>
       </ng-container>
        </mat-list>
    </mat-dialog-content>
</div>
`
})
export class CameraShowTwoPopupComponent implements OnInit {
  channelData: any;
  optionFor: any;
  filename: string;
  file: any;
  onUploadSuccess = new EventEmitter();

  constructor(public dialogRef: MatDialogRef<CameraShowTwoPopupComponent>, public dialog: MatDialog, public toastr: ToastrService) { }
  ngOnInit() {
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    } else {
      this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    }
  }
  captureCameraImage() {
    let dialogRef = this.dialog.open(ImagePopupComponent);
    dialogRef.componentInstance.uploadState = "webcam";
    dialogRef.componentInstance.imageUrl = "";
    dialogRef.componentInstance.communityKey = this.channelData.communityKey;
    dialogRef.componentInstance.file = "";
    dialogRef.componentInstance.filename = "";
    const sub = dialogRef.componentInstance.onUpload.subscribe((data) => {
      console.log(data)
      if (data == 'sendImage') {
        this.onUploadSuccess.emit('imageUploaded')
      }
      dialogRef.close();
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  recordCameraVideo() {
    let dialogRef = this.dialog.open(VideoPopupComponent);
    dialogRef.componentInstance.uploadState = "webcam";
    dialogRef.componentInstance.videoUrl = "";
    dialogRef.componentInstance.chanlKey = this.channelData.communityKey;
    dialogRef.componentInstance.videoFileObj = "";
    dialogRef.componentInstance.filename = "";
  }

  recordUploadAudio(options) {
    if (options == 'byMicrophone') {
      this.dialog.open(RecordAudionPopupComponent);
    } else if (options == 'byGallery') {
      // let dialogRef = this.dialog.open(AudioOptionPopupComponent);
    }
  }


  audioUpload(event: any) {
    let audioExtension = event.target.files[0]['type']
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    }
    if (audioExtension == 'audio/mp3' || audioExtension == 'audio/ogg' || audioExtension == 'audio/wav' || audioExtension == 'audio/mpeg') {
      if (event.target.files[0]['size'] / 1000 / 1000 < 10) {
        this.filename = event.target.files[0]['name'];
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        this.file = event.target.files[0];
        let fileUrl;
        let dialogRef;
        reader.onload = (e: Event) => {
          this.dialog.closeAll();
          let fileUrl = e.target['result']
          if (fileUrl != '') {
            dialogRef = this.dialog.open(AudioOptionPopupComponent);
            dialogRef.componentInstance.uploadType = "gallery";
            dialogRef.componentInstance.audioUrl = fileUrl;
            dialogRef.componentInstance.communityKey = this.channelData.communityKey;

            dialogRef.componentInstance.file = this.file
            dialogRef.componentInstance.filename = this.filename
          }
          else {

          }
        }
      }
      else {
        this.toastr.info('Audio size should be less than or equal to 10 MB ', 'Info !!'); return false;
      }
    }
    else {
      this.toastr.info('Audio format should be mp3/ogg/wav/mpeg', 'Info !!'); return false;
    }
  }
}
/* record audio popup */
@Component({
  selector: 'app-record-audio-popup',
  template: `
 <div class="whiteOuter overlayOptionPopup audioPopup">
    <mat-dialog-actions class="pad-all-sm">
        <button mat-dialog-close class="closeBtn"><i class="zmdi zmdi-close"></i></button>
    </mat-dialog-actions>
    <h2 mat-dialog-title class="mrgn-t-lg mrgn-b-md">Tab to start recording</h2>
    <mat-dialog-content>
       <div class="audio-recording-outer mrgn-b-lg">
          <div class="audioStart" (click)="openDialogRecordAudioStop()" (click)="dialogRef.close()"><i class="zmdi zmdi-circle"></i></div>
       </div>
    </mat-dialog-content>
</div>
`
})
export class RecordAudionPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<RecordAudionPopupComponent>, public dialog: MatDialog) { }
  channelData: any;
  ngOnInit() {
  }
  openDialogRecordAudioStop() {
    this.dialog.open(RecordAudioStopPopupComponent);
  }
}

/* record audio stop popup */
@Component({
  selector: 'app-record-audio-stop-popup',
  template: `
 <div class="whiteOuter overlayOptionPopup audioStopPopup">
    <mat-dialog-actions class="pad-all-sm">
        <button mat-dialog-close class="closeBtn"><i class="zmdi zmdi-close"></i></button>
    </mat-dialog-actions>
    <mat-dialog-content>
       <div class="audio-recording-outer mrgn-b-lg">
          <div class="audioTime mrgn-t-sm mrgn-b-sm"></div>
          <div class="audioStart" (click)="openDialogRecordAudioDisplay()" (click)="dialogRef.close()"><i class="zmdi zmdi-stop"></i></div>
          <div class="stopRecordingTxt mrgn-t-sm">Talk now. Tap <i class="zmdi zmdi-stop"></i> to stop recording</div>
       </div>
    </mat-dialog-content>
</div>
`
})
export class RecordAudioStopPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<RecordAudioStopPopupComponent>, public dialog: MatDialog) { }
  channelData: any;
  mediaRecorder: any;
  file: any;
  ngOnInit() {
    if (localStorage.getItem('Selectedfollower') !== null) {
      this.channelData = JSON.parse(localStorage.getItem('Selectedfollower'))
    } else {
      this.channelData = JSON.parse(localStorage.getItem('createCommunityData'))
    }
    let audioChunks = [];
    let constraints = { audio: true };
    navigator.getUserMedia = (navigator.getUserMedia);
    if (navigator.getUserMedia) {
      navigator.getUserMedia(constraints, (stream) => {
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.start();
        // var audioPlay = document.getElementsByTagName('audio')[0];
        // audioPlay.ontimeupdate = function() {console.log(audioPlay.currentTime)};
      }, (err) => {
        console.log('The following error occured: ' + err);
      })
    }

  }
  openDialogRecordAudioDisplay() {
    let chunks = []
    this.mediaRecorder.stop();
    this.mediaRecorder.ondataavailable = (e) => {
      chunks.push(e.data)
      var blob = new Blob(chunks, { 'type': 'audio/ogg' });
      // this.audio1.src = window.URL.createObjectURL(blob);
      this.file = blob;
      var reader = new FileReader();
      reader.readAsDataURL(this.file);
      let dialogRef = this.dialog.open(AudioOptionPopupComponent);
      reader.onloadend = (e: Event) => {
        dialogRef.componentInstance.uploadType = "microphone";
        dialogRef.componentInstance.audioUrl = e.currentTarget['result'];
      }
      dialogRef.componentInstance.communityKey = this.channelData.communityKey;
      dialogRef.componentInstance.file = this.file;
      dialogRef.componentInstance.filename = "recordedAudio.ogg";
    }
    // this.dialog.open(RecordAudiodisplayPopupComponent);
  }
}

@Component({
  selector: 'app-media-popup',
  template: `
  <div class="galleryOverlayPopup cameraCapturePopup">
  <mat-dialog-actions class="topHead pad-all-md" id="topHeader">
      <div class="leftBtn"><button matDialogClose class="closeBtn" (click)="cancel()">
      <i class="zmdi zmdi-close"></i></button><span> {{videoPopupLeftHeader}}</span></div>
      <div class="rightBtn" *ngIf="videoPopupRightHeader !=''"><button class="retakeButton"><i class="zmdi zmdi-replay"></i></button>
      <span (click)="recordVideo()"> {{videoPopupRightHeader}}</span></div>
  </mat-dialog-actions>
  <mat-dialog-content>
  <div class="galleryContent pad-all-md-lg" *ngIf="uploadState == 'gallery'">
  <div class="popup-video-player">
    <video style="max-width:100%;" autoplay="" preload="none" controls playsinline webkit-playsinline id='video'>
      <source id='myImg' src="{{videoUrl}}" type="video/mp4">
    </video>
  </div>
</div>  

<div class="galleryContent pad-all-md-lg" *ngIf="uploadState == 'webcam'">
<div class="popup-video-player">
  <video #videoElement style="max-width:100%;" preload="none" controls playsinline webkit-playsinline id='video'>
  <source id='myImg'></video>
  
  <div class="cameraCaptureBtn" *ngIf="cancelTakePhoto==true">
              <a  (click)="recordVideo()" class="borderCircle text-center" mat-fab matTooltip="Record Video">
                  <i class="zmdi zmdi-circle"></i>
              </a>
               <a (click)="stop()" class="redStop borderCircle text-center" mat-fab matTooltip="Stop Video">
               <i class="zmdi zmdi-stop"></i>
              </a>
          </div>
      </div> 
    </div>
      <div class="green-input-line">
                <mat-form-field class="full-wid searchOuter mrgn-b-md">  
                <textarea maxlength="2000" #message matInput [placeholder]="'Add a Caption'" maxlength='2000' type="text" [(ngModel)]="captionMessage" (keyup.enter)="uploadVideoToBucket()"></textarea>
                <mat-hint align="end">{{message.value.length}} / 2000</mat-hint>
            </mat-form-field>
        </div>
        <canvas #layout style='display:none'></canvas>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
          <div class="forwardBtn" (click)="uploadVideoToBucket()">
                <a class="borderCircle text-center" mat-fab>
                    <i class="zmdi zmdi-mail-send"></i>
                </a>
            </div>
    </mat-dialog-actions>
</div>`,
  providers: [AdminFollowerChatComponent, FollowerAdminChatComponent]
})
export class VideoPopupComponent implements OnInit {
  data = this.dialogRef.componentInstance;
  @ViewChild('layout') canvasRef: any;
  videoUrl: any;
  chanlKey: any;
  videoFileObj: any;
  filename: string;
  captionMessage: any;
  rightTickTakePhoto: boolean = false;
  cancelTakePhoto: boolean = false;
  @ViewChild('hardwareVideo') hardwareVideo: any;
  base64String: any;
  uploadState: string;
  mediaRecorder: any;
  @ViewChild('videoElement') videoElement;
  video: any;
  videoPopupLeftHeader: string;
  videoPopupRightHeader: string;
  isrecordStarted: number = 0;

  constructor(public dialogRef: MatDialogRef<VideoPopupComponent>, public dialog: MatDialog,
    public communityService: CommunityService, public adminComponent: AdminBroadcastMessagesComponent,
    public adminFollowerChat: AdminFollowerChatComponent, public followerAdminChat: FollowerAdminChatComponent,
    public baseService: BaseService, public toastr: ToastrService, public dashboardService: DashboardService) {
  }

  ngOnInit() {
    $(document).ready(function () {
      $('#video').mediaelementplayer({
        // Configuration
        success: function (media) {
          var isNative = /html5|native/i.test(media.rendererName);

          // var isYoutube = ~media.rendererName.indexOf('youtube');

          // etc.
        }
      });
    });


    if (this.uploadState == "gallery") {
      this.videoPopupLeftHeader = "Preview";
      this.videoPopupRightHeader = "";
      this.isrecordStarted = 2;
    } else if (this.uploadState == "webcam") {
      this.videoPopupLeftHeader = "Capture Video";
      this.videoPopupRightHeader = "Retake";
      this.startwebcam();
    }
  }
  ngAfterViewInit() {
    if (this.uploadState == "webcam") {
      this.video = this.videoElement.nativeElement;
    }
  }
  startwebcam() {
    let constraints = { video: true, audio: true };
    let n = <any>navigator;
    navigator.getUserMedia = (navigator.getUserMedia);

    if (navigator.getUserMedia && navigator.mediaDevices.getUserMedia) {
      navigator.getUserMedia(constraints, (stream) => {
        //this.rightTickTakePhoto = true;
        this.cancelTakePhoto = true;
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.start();
        // this.video.src = window.URL.createObjectURL(stream);
        this.video.srcObject = stream;
        this.video.play();
      }, (err) => {
        this.toastr.error("Unknown error occurred. Please try again later", 'Error!');
        console.log('The following error occured: ' + err);
      })
    }
  }


  //capture a snapshot of video
  recordVideo(): void {
    this.isrecordStarted = 1;
    let n = <any>navigator;
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      this.rightTickTakePhoto = false;
      this.cancelTakePhoto = false;
      navigator.mediaDevices.getUserMedia({ audio: true, video: true })
        .then((stream) => {
          this.rightTickTakePhoto = true;
          this.cancelTakePhoto = true;
          // this.video.src = window.URL.createObjectURL(stream);
          this.video.srcObject = stream;
          this.video.play();
        }).catch((x) => { this.toastr.error("Please connect webcam or allow camera access", 'Error!'); });
    } else {
      this.toastr.error("No webcam found", 'Error!');
    }
  }

  cancel() {
    this.isrecordStarted = 0;
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    document.getElementsByTagName('video')[0].style.display = "none";
  }

  stop() {
    this.isrecordStarted = 2;
    let chunks = []
    this.mediaRecorder.stop();
    var video = document.getElementsByTagName('video')[0];
    this.mediaRecorder.ondataavailable = (e) => {
      chunks.push(e.data)
      var blob = new Blob(chunks, { 'type': 'video/ogg;' });
      this.video.src = window.URL.createObjectURL(blob);
      this.video.play();
      this.videoUrl = "";
      this.videoFileObj = blob;
      this.filename = "camVideo.webm";
      if (this.videoFileObj['size'] > 10000000) {
        this.toastr.info('Video size should be less than or equal to 10 MB ', 'Info !!');
        return false;
      }
    }
  }

  captureVideoThumbnail() {
    if (this.uploadState == "gallery") {
      var video = <HTMLImageElement>document.getElementById('video_html5');
    } else if (this.uploadState == "webcam") {
      var video = <HTMLImageElement>document.getElementById('video_from_mejs');
    }
    let source = new Image();
    let canvas = this.canvasRef.nativeElement;
    let context = canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    let thumbUrl = canvas.toDataURL("image/png");
    return canvas.toDataURL("image/png");
  }

  urltoFile(url, filename, mimeType) {
    mimeType = mimeType || (url.match(/^data:([^;]+);/) || '')[1];
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }

  uploadVideoToBucket() {
    if (this.videoFileObj['size'] > 10000000) {
      this.toastr.info('Video size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    } else {
      console.log(this.isrecordStarted);

      if (this.isrecordStarted == 2) {
        this.baseService.showLoader();
        let msgKey = this.communityService.generateMessageGuid();
        let thumbImg = this.videoUrl;
        let x = this.captureVideoThumbnail()
        this.urltoFile(x, 'videoThumbnail.png', '').then((file) => {
          if (this.uploadState == "webcam") {
            BaseService.fileObj = this.videoFileObj
            this.filename = "camVideo.webm";
          } else {
            BaseService.fileObj = this.videoFileObj
            this.filename = this.videoFileObj.name;
          }
          BaseService.thumbnailObj = file;
          BaseService.getSource = 'video';
          let sendMsgFileObject = {
            'file': this.filename,
            'chnlKey': this.chanlKey,
            'msgKey': msgKey,
            'source': 'video'
          }
          let sendMsgThumbnailObject = {
            'file': file.name,
            'chnlKey': this.chanlKey,
            'msgKey': msgKey,
            'source': 'thumbnail'
          }

          localStorage.setItem('sendMsgFileObject', JSON.stringify(sendMsgFileObject))
          localStorage.setItem('sendMsgThumbnailObject', JSON.stringify(sendMsgThumbnailObject))

          if (!BaseComponent.onlineOffline) {
            this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
          } else {
            new Observable(this.baseService.uploadFile).subscribe(
              (res) => {
                new Observable(this.baseService.getUplodedFileUrl).subscribe(
                  (actualMessageUrl) => {
                    new Observable(this.baseService.uploadFile).subscribe(
                      (res2) => {
                        new Observable(this.baseService.getUplodedFileUrl).subscribe(
                          (messageSmallThumbUrl) => {
                            let followerData;
                            if ((localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') &&
                              localStorage.getItem('currentPath') == '/welcome-dashboard') {

                              followerData = JSON.parse(localStorage.getItem('createCommunityData'));
                              this.followerAdminChat.sendOneToOneMsg(followerData.userCommunityJabberId,
                                msgKey,
                                'video',
                                messageSmallThumbUrl,
                                actualMessageUrl,
                                this.captionMessage,
                                this.filename,
                                "");
                            } else if ((localStorage.getItem('ChatList') && localStorage.getItem('ChatList') == 'OneOnOne') &&
                              localStorage.getItem('currentPath') == '/channel-dashboard') {

                              followerData = JSON.parse(localStorage.getItem('Selectedfollower'));
                              this.adminFollowerChat.sendOneToOneMsg(followerData.communityJabberId,
                                msgKey,
                                'video',
                                messageSmallThumbUrl,
                                actualMessageUrl,
                                this.captionMessage,
                                this.filename,
                                "");
                            }
                            else {
                              this.adminComponent.sendMessage(
                                this.chanlKey,
                                msgKey,
                                'video',
                                messageSmallThumbUrl,
                                actualMessageUrl,
                                this.captionMessage, this.filename);
                            }

                            this.dialog.closeAll();
                          },
                          (complete) => {
                            this.dialog.closeAll();
                            // console.log('Finished process');
                          });
                      },
                      (complete) => {
                        // console.log('Finished process');
                      });
                  },
                  (complete) => {
                    // console.log('Finished process');
                  });
              },
              (complete) => {
                // console.log('Finished process');
              });
          }
        })
      } else {
        this.isrecordStarted = 0;
        this.toastr.info('Please record video to send.', 'Info !!');
        return false;
      }
    }
  }
}


@Component({
  selector: 'app-location-step-one-popup',
  template: `<div class="locationPopup" style="max-width:400px">
<mat-dialog-actions class="topHead pad-all-md">
    <button matDialogClose class="closeBtn" >
        <i class="zmdi zmdi-close"></i>
    </button>
    <span> Select a Location</span>
</mat-dialog-actions>
<mat-dialog-content>
<div class="locationContent pad-all-md">
<h2>Current Location</h2>
<div class="ourLocationList">
  <mat-list >
  <mat-list-item (click)="locationStepTwoPopup(firstLocation)">
      <mat-icon mat-list-icon><i class="zmdi zmdi-pin"></i></mat-icon>
      <h4 mat-line *ngIf="firstLocation && firstLocation.formatted_address">{{firstLocation["address_components"][0]["short_name"]}}</h4>
      <p mat-line *ngIf="firstLocation && firstLocation.formatted_address">{{firstLocation.formatted_address}}</p>
    </mat-list-item>
  </mat-list>
</div>
<h2>Around You</h2>
<div class="ourLocationList">
<mat-list *ngFor='let x of nearestLocations'>
<mat-list-item (click)="locationStepTwoPopup(x)">
    <mat-icon mat-list-icon><i class="zmdi zmdi-pin"></i></mat-icon>
    <h4 mat-line>{{x.address_components.short_name}}</h4>
    <p mat-line>{{x.formatted_address}}</p>
  </mat-list-item>
</mat-list>
</div>
</div>
</mat-dialog-content>
</div>`
})
export class locationStepOnePopupComponent implements OnInit {
  lat: any;
  long: any;
  nearestLocations: any;
  @ViewChild('gmap') gmapElement: any;
  map: google.maps.Map;
  chanlKey: any;
  firstLocation: any;
  shortLocation: any;
  onList = new EventEmitter();

  constructor(public dialogRef: MatDialogRef<locationStepOnePopupComponent>, public dialog: MatDialog,
    public communityService: CommunityService, public adminComponent: AdminBroadcastMessagesComponent,
    public baseService: BaseService) { }
  ngOnInit() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude;
        this.long = position.coords.longitude;
        var latlng = { lat: this.lat, lng: this.long };

        let geocoder = new google.maps.Geocoder();
        geocoder.geocode({ 'location': latlng }, (results, status) => {
          if (status == google.maps.GeocoderStatus.OK) {
            this.nearestLocations = results;
            this.firstLocation = this.nearestLocations[0]
            // this.shortLocation = this.nearestLocations[0]['address_components'][0]['short_name']
            // console.log(this.nearestLocations[0]['address_components'][0]['short_name'])
            let result = results[0];
            let rsltAdrComponent = result.address_components;
            let resultLength = rsltAdrComponent.length;
            // var mapProp = {
            //   center: new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng()),
            //   zoom: 15,
            //   mapTypeId: google.maps.MapTypeId.ROADMAP
            // };
            // this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);
            if (result != null) {
              console.log(rsltAdrComponent[resultLength - 5].short_name)
            } else {
              window.alert('Geocoder failed due to: ' + status);
            }
          }
        });
      });
    };
  }

  locationStepTwoPopup(mapParms) {
    let dialogRef = this.dialog.open(locationStepTwoPopupComponent);
    dialogRef.componentInstance.mapParms = mapParms;
    dialogRef.componentInstance.chanlKey = this.chanlKey;

    const sub = dialogRef.componentInstance.onSelect.subscribe((data) => {
      if (data == 'stepTwoLocation') {
        this.onList.emit('stepOneLocation')
        // this.dialogRef.close()
      }
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });

  }
}

@Component({
  selector: 'app-location-step-two-popup',
  template: `<div class="locationPopup" style="max-width:400px">
<mat-dialog-actions class="topHead pad-all-md">
    <button matDialogClose class="closeBtn" >
        <i class="zmdi zmdi-close"></i>
    </button>
    <span> Select a Location</span>
</mat-dialog-actions>
<mat-dialog-content>
<div class="locationContent">
<div class="ourLocationList">
<div #gmap style="height:400px; width:100%"></div>
  <mat-list>
  <mat-list-item>
      <mat-icon mat-list-icon><i class="zmdi zmdi-pin"></i></mat-icon>
      <h4 mat-line *ngIf="mapParms && mapParms.formatted_address">{{mapParms["address_components"][0]["short_name"]}}</h4>
      <p mat-line *ngIf="mapParms && mapParms.formatted_address">{{mapParms.formatted_address}}</p>
    </mat-list-item>
  </mat-list>
</div>
</div>
</mat-dialog-content>
<mat-dialog-actions class="bottomHead pad-all-md-lg">
<div class="forwardBtn">
      <div class="borderCircle text-center linkTxt">
          <span>Send</span><a (click)="sendLocation()" (click)="dialogRef.close()"><i class="zmdi zmdi-mail-send"></i></a>
      </div>
  </div>
</mat-dialog-actions>
</div>
`,
  providers: [AdminFollowerChatComponent, FollowerAdminChatComponent]
})
export class locationStepTwoPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<locationStepTwoPopupComponent>, public dialog: MatDialog,
    public communityService: CommunityService, public adminComponent: AdminBroadcastMessagesComponent,
    public adminFollowerChat: AdminFollowerChatComponent, public followerAdminChat: FollowerAdminChatComponent,
    public baseService: BaseService, public dashboardService: DashboardService) { }
  mapParms: any;
  map: any;
  chanlKey: any;
  @ViewChild('gmap') gmapElement: any;
  //@Output() notify: EventEmitter<string> = new EventEmitter<string>();
  onSelect = new EventEmitter();

  ngOnInit() {
    let geocoder = new google.maps.Geocoder();
    var mapProp = {
      center: new google.maps.LatLng(this.mapParms.geometry.location.lat(), this.mapParms.geometry.location.lng()),
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);
  }

  sendLocation() {
    let msgKey = this.communityService.generateMessageGuid();
    let params = {
      "columnOne": 'Pune',
      "columnTwo": this.mapParms.formatted_address,
      "columnThree": '' + this.mapParms.geometry.location.lat() + '',
      "columnFour": '' + this.mapParms.geometry.location.lng() + ''
    }
    let followerData;
    if ((localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') &&
      localStorage.getItem('currentPath') == '/welcome-dashboard') {

      followerData = JSON.parse(localStorage.getItem('createCommunityData'));
      this.followerAdminChat.sendOneToOneMsg(followerData.userCommunityJabberId,
        msgKey,
        'location',
        '',
        '',
        '',
        params,
        '');
      this.onSelect.emit('stepTwoLocation');
    } else if ((localStorage.getItem('ChatList') && localStorage.getItem('ChatList') == 'OneOnOne') &&
      localStorage.getItem('currentPath') == '/channel-dashboard') {

      followerData = JSON.parse(localStorage.getItem('Selectedfollower'));

      this.adminFollowerChat.sendOneToOneMsg(followerData.communityJabberId,
        msgKey,
        'location',
        '',
        '',
        '',
        params,
        '');
      this.onSelect.emit('stepTwoLocation');
    }
    else {

      this.adminComponent.sendMessage(
        this.chanlKey,
        msgKey,
        'location',
        '',
        '',
        '', params);

      this.onSelect.emit('stepTwoLocation');

    }


  }


}


@Component({
  selector: 'app-image-message-popup',
  template: `
  <div class="galleryOverlayPopup cameraCapturePopup">
  <mat-dialog-actions class="topHead pad-all-md mrgn-b-md" id="topHeader">
      <div class="leftBtn"><button matDialogClose class="closeBtn" (click)="cancel()">
      <i class="zmdi zmdi-close"></i></button><span> {{imageLeftHeaderPopup}}</span></div>
      <div class="rightBtn" *ngIf="imageRightHeaderPopup !=''" (click)="startwebcam()"><button class="retakeButton"><i class="zmdi zmdi-replay"></i></button>
      <span > {{imageRightHeaderPopup}}</span></div>
  </mat-dialog-actions>

  <mat-dialog-content>
      <div class="galleryContent pad-all-md-lg">
      <img class="mrgn-auto text-center captureImg mrgn-t-md" id="uploadedImg" src="#" alt="ovarlay_upload_img" />
      <canvas id="myImg" height="400px" width="600px" #canvasRef></canvas>
      <video id="myImgVideo" #hardwareVideo height="360px" width="600px" class="mrgn-t-md"></video>
          <div class="cameraCaptureBtn" *ngIf="cancelTakePhoto==true" (click)="capture()">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-camera"></i>
              </a>
          </div>
      </div>

      <div class="green-input-line">
              <mat-form-field class="full-wid searchOuter mrgn-b-md">
              <textarea maxlength="2000" #message matInput [placeholder]="'Add a Caption'" type="text" [(ngModel)]="textMessage"  (keyup.enter)="uploadImageToBucket()" ></textarea>
              <mat-hint align="end">{{message.value.length}} / 2000</mat-hint>
              </mat-form-field>
      </div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg">
        <div class="forwardBtn" (click)="uploadImageToBucket()">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-mail-send"></i>
              </a>
          </div>
  </mat-dialog-actions>
</div>
`,
  providers: [AdminFollowerChatComponent, FollowerAdminChatComponent]
})
export class ImagePopupComponent implements OnInit {
  data = this.dialogRef.componentInstance;
  imageUrl: any
  communityKey: any;
  file: any;
  textMessage: string;
  filename: string;
  fileToCompress: any;
  compressedFile: any
  rightTickTakePhoto: boolean = false;
  cancelTakePhoto: boolean = false;
  @ViewChild('hardwareVideo') hardwareVideo: any;
  @ViewChild('canvasRef') canvasRef: any;
  base64String: any;
  uploadState: any;
  imageLeftHeaderPopup: string;
  imageRightHeaderPopup: string;
  onUpload = new EventEmitter();

  constructor(public dialogRef: MatDialogRef<ImagePopupComponent>, public dialog: MatDialog,
    public communityService: CommunityService, public adminComponent: AdminBroadcastMessagesComponent,
    public adminFollowerChat: AdminFollowerChatComponent, public followerAdminChat: FollowerAdminChatComponent,
    public baseService: BaseService, public toastr: ToastrService, public dashboardService: DashboardService) {
  }

  ngOnInit() {
    if (this.uploadState == "webcam") {
      this.imageLeftHeaderPopup = "Take Photo";
      this.imageRightHeaderPopup = "Retake";
      this.startwebcam();
    } else if (this.uploadState == "gallery") {
      document.getElementById("uploadedImg").setAttribute('src', this.imageUrl)
      this.imageLeftHeaderPopup = "Preview";
      this.imageRightHeaderPopup = "";
    }
  }
  ngAfterViewInit() {
    if (this.uploadState == 'webcam') {
      // this.audio1 = this.canvasRef.nativeElement;
    }
  }

  startwebcam() {
    //$('.mejs__container mejs__container-keyboard-inactive mejs__video').hide()
    document.getElementById("uploadedImg").setAttribute('src', '')
    document.getElementById("uploadedImg").style.display = 'none';
    document.getElementById('myImg').style.display = "none";
    this.canvasRef.nativeElement.display = "none";
    let video = this.hardwareVideo.nativeElement;
    document.getElementById('myImgVideo').style.display = "block";
    let n = <any>navigator;
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      this.rightTickTakePhoto = false;
      this.cancelTakePhoto = false;
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then((stream) => {
          this.rightTickTakePhoto = true;
          this.cancelTakePhoto = true;
          video.src = window.URL.createObjectURL(stream);
          video.play();
        }).catch((x) => { this.toastr.error("Please connect webcam or allow camera access", 'Error!'); });
    } else {
      this.toastr.error("No webcam found", 'Error!');
    }
  }

  capture(): void {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;

    var video = <HTMLImageElement>document.getElementById('myImgVideo');
    let source = new Image();
    let canvas = this.canvasRef.nativeElement;
    let context = canvas.getContext('2d').drawImage(video, 0, 0, video.width, video.height);
    let dataUrl = canvas.toDataURL("image/png");
    this.base64String = dataUrl.split(',').pop();
    document.getElementById("uploadedImg").setAttribute('src', dataUrl);
    document.getElementById("uploadedImg").style.display = 'block';
    video.style.display = "none";
    document.getElementById('myImg').style.display = "none";
    //$('.mejs__container mejs__container-keyboard-inactive mejs__video').hide()
    this.urltoFile(dataUrl, 'imageThumbnail.png', '')
      .then((file) => {
        this.imageUrl = this.base64String;
        this.file = file;
        this.filename = file['name'];
        BaseService.fileToCompress = file;
        new Observable(this.communityService.compressFile).subscribe(result => {
          this.fileToCompress = result
        })
      })
  }

  cancel() {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    document.getElementsByTagName('video')[0].style.display = "none";
  }

  urltoFile(url, filename, mimeType) {
    mimeType = mimeType || (url.match(/^data:([^;]+);/) || '')[1];
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }

  uploadImageToBucket() {
    if (this.file['size'] > 10000000) {
      this.toastr.info('Image size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    }
    else if (this.file && this.file.name) {
      this.baseService.showLoader();
      let messagKey = this.communityService.generateMessageGuid();
      let thumbImg = this.imageUrl;

      // this.urltoFile(thumbImg, 'imageThumbnail.png', '')
      //   .then((file) => {
      BaseService.fileObj = this.fileToCompress
      BaseService.thumbnailObj = this.file;
      BaseService.getSource = 'image';

      let sendMsgFileObject = {
        'file': this.fileToCompress.name,
        'chnlKey': this.communityKey,
        'msgKey': messagKey,
        'source': 'image'
      }
      let sendMsgThumbnailObject = {
        'file': this.file.name,
        'chnlKey': this.communityKey,
        'msgKey': messagKey,
        'source': 'thumbnailImage'
      }

      localStorage.setItem('sendMsgFileObject', JSON.stringify(sendMsgFileObject))
      localStorage.setItem('sendMsgThumbnailObject', JSON.stringify(sendMsgThumbnailObject))
      if (!BaseComponent.onlineOffline) {
        this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
      } else {
        new Observable(this.baseService.uploadFile).subscribe(
          (res) => {
            new Observable(this.baseService.getUplodedFileUrl).subscribe(
              (actualMessageUrl) => {
                new Observable(this.baseService.uploadFile).subscribe(
                  (res2) => {
                    new Observable(this.baseService.getUplodedFileUrl).subscribe(
                      (messageSmallThumbUrl) => {
                        let followerData;
                        if ((localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') &&
                          localStorage.getItem('currentPath') == '/welcome-dashboard') {

                          followerData = JSON.parse(localStorage.getItem('createCommunityData'));

                          this.followerAdminChat.sendOneToOneMsg(followerData.userCommunityJabberId,
                            messagKey,
                            'image',
                            messageSmallThumbUrl,
                            actualMessageUrl,
                            this.textMessage,
                            this.filename,
                            "");
                          this.onUpload.emit('sendImage');

                        } else if ((localStorage.getItem('ChatList') && localStorage.getItem('ChatList') == 'OneOnOne') &&
                          localStorage.getItem('currentPath') == '/channel-dashboard') {

                          followerData = JSON.parse(localStorage.getItem('Selectedfollower'));
                          this.adminFollowerChat.sendOneToOneMsg(followerData.communityJabberId,
                            messagKey,
                            'image',
                            messageSmallThumbUrl,
                            actualMessageUrl,
                            this.textMessage,
                            this.filename,
                            "");
                          this.onUpload.emit('sendImage');
                        }
                        else {

                          this.adminComponent.sendMessage(
                            this.communityKey,
                            messagKey,
                            'image',
                            messageSmallThumbUrl,
                            actualMessageUrl,
                            this.textMessage, this.filename);
                          this.onUpload.emit('sendImage');
                        }
                        //this.dialog.closeAll();
                      },
                      (complete) => {
                      });
                  },
                  (complete) => {
                  });
              },
              (complete) => {
              });
          },
          (complete) => {
          });
      }
      // })
    }
    else {
      this.toastr.info("Please upload file", 'Info!')
    }
  }
}

@Component({
  selector: 'app-audio-overlay-option-popup',
  template: `<div class="whiteOuter overlayOptionPopup audioDisplayPopup">
  <mat-dialog-actions class="pad-all-sm">
  <button mat-dialog-close class="closeBtn"><i class="zmdi zmdi-close"></i></button>
  </mat-dialog-actions>
  <mat-dialog-content>
  <div class="audio-recording-outer">
    <div id="tracktime" class="audioTime mrgn-t-sm mrgn-b-sm">0:0</div>
    <div class="audioStart"><i class="zmdi zmdi-play"></i></div>
  <div class="popupAudio">
  <div class="popup-audio-player">
    <audio id="audio-player2" src="{{audioUrl}}" type="audio/mp3;audio/ogg" controls="controls" ontimeupdate="document.getElementById('tracktime').innerHTML = Math.floor((this.currentTime/60)%60) +':'+ Math.floor(this.currentTime%60)"></audio>
  </div>
  <div class="sendBtn" (click)="uploadAudioToBucket()"><i class="zmdi zmdi-mail-send"></i></div>
  </div>
  </div>
  </mat-dialog-content>
  </div>`,
  providers: [AdminBroadcastMessagesComponent, AdminFollowerChatComponent, FollowerAdminChatComponent]
})
@Pipe({ name: 'safeHtml' })
export class AudioOptionPopupComponent implements OnInit {
  data = this.dialogRef.componentInstance;
  audioUrl: any;
  communityKey: any;
  textMessage: string;
  filename: string
  file: any
  uploadType: string;
  audio1: any;
  mediaRecorder: any;
  uploadedFileName: any;

  constructor(public adminComponent: AdminBroadcastMessagesComponent, public baseService: BaseService,
    private communityService: CommunityService, private AdminBroadcastMessagesComponent: AdminBroadcastMessagesComponent,
    public dialogRef: MatDialogRef<AudioOptionPopupComponent>, public dialog: MatDialog,
    public adminFollowerChat: AdminFollowerChatComponent, public followerAdminChat: FollowerAdminChatComponent,
    public toastr: ToastrService, private sanitizer: DomSanitizer, public dashboardService: DashboardService) {

  }

  transform(html) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(html);
  }
  ngOnInit() {
    $(document).ready(function () {
      $('#audio-player2').mediaelementplayer({
        // Configuration
        success: function (media) {
          var isNative = /html5|native/i.test(media.rendererName);
          // var isYoutube = ~media.rendererName.indexOf('youtube');
        }
      });
    });
  }
  ngAfterViewInit() {
  }


  uploadAudioToBucket() {
    if (this.file['size'] > 10000000) {
      this.toastr.info('Audio size should be less than or equal to 10 MB ', 'Info !!');
      return false;
    } else {
      this.baseService.showLoader();
      let messagKey = this.communityService.generateMessageGuid();
      if (this.uploadType == 'microphone') {
        this.uploadedFileName = "recordedAudio.ogg";
      } else if (this.uploadType == "gallery") {
        this.uploadedFileName = this.file.name
      }
      BaseService.fileObj = this.file
      BaseService.getSource = 'audio';
      let sendMsgFileObject = {
        'file': this.uploadedFileName,
        'chnlKey': this.communityKey,
        'msgKey': messagKey,
        'source': 'audio'
      }
      localStorage.setItem('sendMsgFileObject', JSON.stringify(sendMsgFileObject))
      if (!BaseComponent.onlineOffline) {
        this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
      } else {
        new Observable(this.baseService.uploadFile).subscribe(
          (res) => {
            new Observable(this.baseService.getUplodedFileUrl).subscribe(
              (actualMessageUrl) => {
                let followerData;
                if ((localStorage.getItem('OneOnOne') && localStorage.getItem('OneOnOne') == 'Active') &&
                  localStorage.getItem('currentPath') == '/welcome-dashboard') {

                  followerData = JSON.parse(localStorage.getItem('createCommunityData'));
                  this.followerAdminChat.sendOneToOneMsg(followerData.userCommunityJabberId,
                    messagKey,
                    'audio',
                    this.file['size'],
                    actualMessageUrl,
                    this.textMessage,
                    this.filename,
                    "");
                } else if ((localStorage.getItem('ChatList') && localStorage.getItem('ChatList') == 'OneOnOne') &&
                  localStorage.getItem('currentPath') == '/channel-dashboard') {

                  followerData = JSON.parse(localStorage.getItem('Selectedfollower'));
                  this.adminFollowerChat.sendOneToOneMsg(followerData.communityJabberId,
                    messagKey,
                    'audio',
                    this.file['size'],
                    actualMessageUrl,
                    this.textMessage,
                    this.filename,
                    "");
                }
                else {
                  this.adminComponent.sendMessage(
                    this.communityKey,
                    messagKey,
                    'audio',
                    this.file['size'],
                    actualMessageUrl,
                    this.textMessage, this.filename);
                }
                this.dialog.closeAll();
              },
              (complete) => {
              });
          },
          (complete) => {
          });
      }
    }
  }
}