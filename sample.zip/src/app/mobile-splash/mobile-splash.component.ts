import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-mobile-splash',
  templateUrl: './mobile-splash.component.html'
})
export class MobileSplashComponent implements OnInit {

  constructor(private router: Router,) { }

  ngOnInit() {
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");
  }

}
