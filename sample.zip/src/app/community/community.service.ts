import { Injectable } from '@angular/core';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import { environment } from '@env/environment';
import { Observable } from 'rxjs/Observable';
import { Http, Response, RequestOptionsArgs, Headers } from '@angular/http';

import 'rxjs/add/observable/of';
import { FileUpload } from '@app/community/community.entities';
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import 'rxjs/add/operator/map';


@Injectable()
export class CommunityService extends BaseService {
  constructor(public loggerService: LoggerService, public _http: Http,
    public baseService: BaseService) {
    super(loggerService, _http)
  }

  private getS3Bucket(): any {
    const bucket = new S3(
      {
        accessKeyId: environment.awsConfig.BUCKET_ACCESS_KEY_ID,
        secretAccessKey: environment.awsConfig.BUCKET_SECRET_ACCESS_KEY,
        region: environment.awsConfig.BUCKET_REGION
      });

    return bucket;
  }

  uploadfile(file, communityKey, msgKey, source) {
    alert('in upload file community service')
    let pathToSave;
    if (source == 'video') {
      pathToSave = 'ChannelMedia/' + communityKey + '/videos/' + msgKey + '/' + file.name;
    }
    else if (source == 'thumbnail') {
      pathToSave = 'ChannelMedia/' + communityKey + '/videos/' + msgKey + '/Thumbnail/' + file.name;
    }
   else if (source == 'audio') {
      pathToSave = 'ChannelMedia/' + communityKey + '/audios/' + msgKey + '/' + file.name;
}
    else if (source == 'chnlProfileImage') {
      pathToSave = 'ChannelProfileImages/' + communityKey + '/' + "original.png";
    } else if (source == 'image') {
      pathToSave = 'ChannelMedia/' + communityKey + '/images/' + msgKey + '/' + file.name;
    } else { }
    const params = {
      Bucket: environment.awsConfig.BUCKET_NAME,
      Key: pathToSave,
      Body: file,
      ACL: 'public-read'
    };

    this.getS3Bucket().upload(params, (err, data) => {
      if (err) {
        return false;
      }
      this.getFiles(communityKey, msgKey, source);
      return true;
    });

  }

  getFiles(communityKey, msgKey, source): Observable<Array<FileUpload>> {
    const fileUploads = new Array<FileUpload>();
    let prefix;
    if (source == 'video') {
      prefix = 'ChannelMedia/' + communityKey + '/videos/' + msgKey + '/';
    } else if (source == 'thumbnail') {
      prefix = 'ChannelMedia/' + communityKey + '/videos/' + msgKey + '/Thumbnail/';
    } else if (source == 'chnlProfileImage') {
      this.baseService.hideLoader()
      prefix = 'ChannelProfileImages/' + localStorage.getItem('communityKey') + '/'
    } else if (source == 'image') {
      prefix = 'ChannelMedia/' + communityKey + '/' + 'images' + '/' + msgKey + '/'
    } else if (source == 'audio') {
      prefix = 'ChannelMedia/' + communityKey + '/' + 'audios' + '/' + msgKey + '/'
    }
    else { }
    const params = {
      Bucket: environment.awsConfig.BUCKET_NAME,
      Prefix: prefix
    };

    this.getS3Bucket().listObjects(params, function (err, data) {
      if (err) {
        return false;
      }
      const fileDatas = data.Contents;

      fileDatas.forEach(function (file) {
        fileUploads.push(new FileUpload(file.Key, environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key));
        if (source == 'video') {
          localStorage.setItem('fileUploads', environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key)
        } if (source == 'thumbnail') {
          localStorage.setItem('thumbnailUploadUrl', environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key)
        } else if (source == 'chnlProfileImage') {
          localStorage.setItem('chnlProfileImage', environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key)

        } else {
          localStorage.setItem('fileUploads', environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key)
        }
      });
    });
    return Observable.of(fileUploads);
  }

  generateMessagetime() {
    let date = new Date();
    return this.timeInmillis = date.getTime().toString();

  }
}
