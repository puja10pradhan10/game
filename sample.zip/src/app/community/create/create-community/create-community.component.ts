import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router } from "@angular/router";
import { Observable } from 'rxjs/Observable';
import { FileUpload } from '@app/community/community.entities';
//Components
import { BaseComponent, cropImageComponent } from '@app/shared/base/base.component'
//Services
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';
import { CommunityService } from '@app/community/community.service';
import { LoaderStrings, DefaultColor } from '@app/shared/base.constants';

import { BaseService } from '@app/shared/base.service';

declare var $: any;

@Component({
  selector: 'app-create-community',
  templateUrl: './create-community.component.html'
})
export class CreateCommunityComponent extends BaseComponent implements OnInit {
  channelColor: string;
  channelName: string;
  selectedFiles: FileList;
  fileUploads: Observable<Array<FileUpload>>;
  communityJabberId: string;
  chnlImageToUpload: any;
  channelData: any;
  communityImageUrl: any;
  isChnlImage: string;

  constructor(public router: Router, public loggerService: LoggerService, public toastr: ToastrService,
    private communityService: CommunityService, public baseService: BaseService, public dialog: MatDialog) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
    this.channelColor = DefaultColor.color;
    localStorage.setItem('isChnlImage', 'old');
    this.isChnlImage = localStorage.getItem('isChnlImage')
    if (localStorage.getItem('createCommunityData')) {
      this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
      this.channelName = this.channelData.channelName;
      this.color = this.channelData.channelColor;
      this.communityImageUrl = this.channelData.communityImageUrl;
      document.getElementsByTagName("img")[0].setAttribute("src", this.channelData.communityImageUrl);
      if(this.channelData.communityImageUrl  !=''){
        document.getElementById('myImg').setAttribute("src", this.channelData.communityImageUrl);
      }else{
        document.getElementById('plusIcon').setAttribute("src", "assets/img/Plus Sign-02.png");
      }
    }
  }

  fileChangeEvent(fileInput: any) {
    // this.chnlImageToUpload = fileInput.target.files[0];
    var reader = new FileReader();
    reader.readAsDataURL(fileInput.target.files[0]);
    reader.onload = (e: Event) => {
      localStorage.setItem('isChnlImage', 'new');
      let fileUrl = e.target['result'];
      let base64String = e.target['result'].split(',').pop();
      let filename = fileInput.target.files[0]['name'];
      let index = filename.lastIndexOf(".");
      var strsubstring = filename.substring(index, filename.length);

      // if ((strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') && fileInput.target.files[0].size < 2097152) {
      //   document.getElementsByTagName("img")[0].setAttribute("src", fileUrl);
      //   document.getElementById('myImg').setAttribute("src", fileUrl);
      // }
      if ((strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') && fileInput.target.files[0].size > 2097152) {
        this.toastr.error('File size should be less than 2 MB.', 'Error!');
      }
      else if ((strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') && fileInput.target.files[0].size < 2097152) {
        // $.LoadingOverlay(LoaderStrings.SHOW_LOADER, {
        //   image: "/assets/img/loader.gif",
        // });
        // this.communityService.uploadfile(fileInput.target.files[0], this.communityJabberId, '', 'chnlProfileImage');

        this.loggerService.info(fileInput)

        let dialogRef = this.dialog.open(cropImageComponent, {
          data: {
            uploadedFile: fileInput
          }
        });
        // const sub = dialogRef.afterClosed().subscribe(() => {
        //   sub.unsubscribe();
        // })

        const sub = dialogRef.componentInstance.onAdd.subscribe((data) => {
          document.getElementsByTagName("img")[0].setAttribute("src", data.base64);
          document.getElementById('myImg').setAttribute("src", data.base64);
          this.chnlImageToUpload = data.fileObj;
          BaseService.fileToCompress = data.fileObj;
          new Observable(this.communityService.compressFile).subscribe(result => {
            this.chnlImageToUpload = result;
          })
          sub.unsubscribe();
          //this.notify.emit(data);
        });

      }
      else if (strsubstring == '.zip' || strsubstring == '.gif' || strsubstring == '.mp4' || strsubstring == '.mp3') {
        this.toastr.error('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Error!');
      }
      else if (fileInput.target.files[0].size > 2097152) {
        this.toastr.error('File size should be less than 2 MB.', 'Error!');
        return false;
      }
      else {
        this.toastr.error('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Error!');
        return false;
      }
    }
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }


  uploadChannelprofileImage() {
    let communityJabberId
    if (localStorage.getItem('createCommunityData') && this.channelData.communityJabberId) {
      communityJabberId = this.channelData.communityJabberId;
      this.communityImageUrl = this.channelData.communityImageUrl;
    } else {
      communityJabberId = this.communityService.generateMessageGuid();
      this.communityImageUrl = "";
    }
    localStorage.setItem('communityJabberId', communityJabberId)

    if ((this.channelName != undefined && this.channelName == '') && this.isChnlImage == "new") {
      this.toastr.info('Channel name should not be empty', 'Info');
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER)
    }
    else if (this.chnlImageToUpload && this.chnlImageToUpload != "") {

      BaseService.fileObj = this.chnlImageToUpload;
      BaseService.getSource = 'chnlProfileImage';
      let sendMsgFileObject = {
        'chnlKey': communityJabberId,
        'source': 'chnlProfileImage',
        'filename': this.chnlImageToUpload['name']
      }
      localStorage.setItem('sendMsgFileObject', JSON.stringify(sendMsgFileObject))

      new Observable(this.baseService.uploadFile).subscribe(
        (res) => {
          new Observable(this.baseService.getUplodedFileUrl).subscribe(
            (actualMessageUrl) => {
              if (actualMessageUrl != "") {
                this.communityImageUrl = actualMessageUrl;
                localStorage.setItem('communityImageUrl', '"' + actualMessageUrl + '"')
                $.LoadingOverlay(LoaderStrings.SHOW_LOADER, {
                  image: "/assets/img/loader.gif",
                });
                this.goToInfoPage();
              } else {
                this.communityImageUrl = "";
              }
            })
        }, (complete) => {
        })
    } else {
      this.goToInfoPage();
    }
  }

  cropUploadedImage() {
    this.dialog.open(cropImageComponent);
  }

  goToInfoPage() {
    if (this.channelName != undefined && this.channelName != '') {
      this.loggerService.info('channelName : ', this.channelName)
      if (this.channelName.charCodeAt(0) != 32) {
        if (this.clickcolorpick) {
          this.colorPicker(this.ColorPick);
          this.clickcolorpick = false;
        }
        let data = {
          'channelName': this.channelName.trim(),
          'channelColor': this.color,
          'communityJabberId': localStorage.getItem('communityJabberId'),
          'communityImageUrl': this.communityImageUrl
        }
        localStorage.setItem('createCommunityData', JSON.stringify(data))
        $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
        this.router.navigate(["community-info"]);
      } else {
        this.toastr.info('Space is not allowed!!', 'Info')
      }
    }
    else {
      this.toastr.info('Channel name should not be empty', 'Info');
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
  }

  color = DefaultColor.color;
  ColorPick: any;
  clickcolorpick: boolean = false;

  colorPicker(event) {
    this.clickcolorpick = true;
    this.ColorPick = event;
    this.channelColor = this.color;
  }


}
