import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Strings } from '@app/shared/base.constants';

@Component({
  selector: 'app-community-info',
  templateUrl: './community-info.component.html'
})
export class CommunityInfoComponent implements OnInit {

  constructor(private router: Router) { }
  aboutChannel: any;
  channelType: any = 'public';
  channelData: any;
  channelColor: any;
  ngOnInit() {
    if (localStorage.getItem('createCommunityData')) {
      this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
      document.getElementsByTagName("body")[0].setAttribute("id", "bgcolorWhite");
      this.channelColor = this.channelData.channelColor;
      if (this.channelData.aboutChannel) {
        this.aboutChannel = this.channelData.aboutChannel;
        this.channelType = this.channelData.channelType;
      }
    }
  }
  goToCategory() {
    let data = {
      'channelName': this.channelData.channelName,
      'channelColor': this.channelData.channelColor,
      'aboutChannel': this.aboutChannel,
      'channelType': this.channelType,
      'communityImageUrl': this.channelData.communityImageUrl,
      'communityJabberId': this.channelData.communityJabberId
    }
    localStorage.setItem('createCommunityData', JSON.stringify(data))
    localStorage.setItem(Strings.NAVIGATE_FROM, 'create-channel')

    this.router.navigate(["categories"]);
  }


}
