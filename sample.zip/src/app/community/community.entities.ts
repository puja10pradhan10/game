export class FileUpload {
    name: string;
    url: string;

    constructor(name: string, url: string) {
        this.name = name;
        this.url = url;
    }
}

export class communityDetails {
    communityKey: string;
    communityCategories: string;
    communityDominantColour: string;
    communityImageBigThumbUrl: string;
    communityImageSmallThumbUrl: string;
    communityImageUrl: string;
    communityJabberId: string;
    communityJoinedTimestamp: any;
    communityName: string;
    communityScore: number;
    description: string;
    isCommunityWithRssFeed: boolean;
    isDefault: boolean;
    ownerId: string;
    ownerName: string;
    privacy: string;
    totalMembers: number;
    type: string;
    finalScore: number;

}
