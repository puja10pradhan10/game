import { BaseRequest, BaseResponse } from '@app/shared/base.messages';
import { extend } from 'webdriver-js-extender';
import { communityDetails } from '@app/profile/profile.entities';


export class CreateChannelRequest extends BaseRequest {
    communityDetails = new communityDetails();
    password: string;
    resource: string;
}

export class CreateChannelResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    communityKey: string;
}

export class SearchChannelResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    communityKey: string;
    communityDetailsList : any;
}

export class DiscoverChannelsListRequest extends BaseRequest {
    userName: string;
    password: string;
}

export class DiscoverChannelsListResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    communityDetailsList: any[];
}

export class FollowChannelRequest extends BaseRequest {
    user_role: string = "member";
    i_jabber_id: string;
}

export class FollowChannelResponse extends BaseResponse {

}