import { Injectable } from '@angular/core';
import { Http, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { DiscoverInterface } from '@app/community/discover/discover-channels/discover-interface';
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { DiscoverChannelsListRequest, DiscoverChannelsListResponse, FollowChannelResponse, FollowChannelRequest } from '@app/community/community.messages'
import { environment } from '@env/environment';
import { FacebookLoginStrings } from '@app/shared/base.constants'
import { HeaderString, ApiUrl } from '@app/shared/base.constants';
import { CreateChannelRequest, CreateChannelResponse , SearchChannelResponse} from '@app/community/community.messages'
import { headersToString } from 'selenium-webdriver/http';
import { Strings } from '@app/shared/base.constants';

@Injectable()
export class DiscoverChannelsService extends BaseService {


  constructor(private http: Http, public loggerService: LoggerService) {
    super(loggerService, http)
  }



  getDiscoverChannelsList(request: DiscoverChannelsListRequest): Observable<DiscoverChannelsListResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL)
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    let currentTime = this.generateMessagetime();
    let registerUserUrl = environment.oAuthConfig.API_BASE_URL + 'communities' + ApiUrl.DISCOVER_LIST_URL_PARAMS + currentTime;

    return this._http.get(registerUserUrl, options)
      .map((response: Response) => <DiscoverChannelsListResponse>response.json())
      // .do(data => this.loggerService.info('Discover channel list Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  followChannel(request: FollowChannelRequest, channelKey): Observable<FollowChannelResponse> {
    //let userdetails = JSON.parse(localStorage.getItem('userDetails'))
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));

    let followChannelUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + channelKey + "/members/";

    return this._http.post(followChannelUrl, request, options)
      .map((response: Response) => <FollowChannelResponse>response.json())
      .do(data => this.loggerService.info('Follow channel Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  generateMessagetime() {
    let date = new Date();
    return this.timeInmillis = date.getTime().toString();

  }

  searchChannel( search: any ): Observable<SearchChannelResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, Strings.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    let currentTime = this.generateMessagetime();

    let createChannelUrl = environment.oAuthConfig.API_BASE_URL + 'communities?page_number=1&page_size=1000&search_text='+search+'&user_field_value=&user_field_name=&filter_category_ids=&CURRENT_TIMESTAMP='+ currentTime;
    // return;
    return this._http.get(createChannelUrl, options)
      .map((response: Response) => <SearchChannelResponse>response.json())
      .do(data => this.loggerService.info('searchChannel ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  

}
