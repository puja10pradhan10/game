import { TestBed, inject } from '@angular/core/testing';

import { DiscoverChannelsService } from './discover-channels.service';
import { Http } from '@angular/http';

// describe('DiscoverChannelsService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [DiscoverChannelsService,{provide: Http,}],
      
//     });
//   });

// //   it('should be created', inject([DiscoverChannelsService], (service: DiscoverChannelsService) => {
// //     expect(service).toBeTruthy();
// //   }));
// it('retrieves all the cars', inject( [DiscoverChannelsService], ( _DiscoverService ) => {
//     return _DiscoverService.getChannels().toPromise().then( (result) => {         
//        expect(result.length).toBeGreaterThan(0);
//     } );       
//   }) );
// });
describe('Observable tests', () => {
  
beforeEach(() => {
        TestBed.configureTestingModule({
          providers: [DiscoverChannelsService,{provide: Http,}],
          
        });
      });
  it('retrieves the people list', inject( [DiscoverChannelsService], (service) => {
    //added some delay to make the test reproduceable on each request
     return service.getChannels().delay(5000).toPromise()
        .then( ( users ) => { expect(users.length).toBeGreaterThan(0) } );
  } ) ); 
   
//   it('tests a dummy Observable', injectAsync( [], () => { 
//      return Observable.of(5).delay(2000).toPromise()
//         .then( ( val ) => { expect(val).toEqual(5) } );
//   } ) );
  
}) 

