export interface DiscoverInterface {
   
    communityname: any;
   
}
export interface discover_list {
    
    communityname: any;
   
}