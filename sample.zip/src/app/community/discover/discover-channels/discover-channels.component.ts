import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
//Component
import { BaseComponent } from '@app/shared/base/base.component';
import { CategoriesComponent } from '@app/shared/categories/categories.component';

//Service
import { DiscoverChannelsService } from '@app/community/discover/discover-channels/discover-channels.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { ToastrService } from 'ngx-toastr';
import { connectionXmpp, UserStrings, Strings } from '@app/shared/base.constants';

import { DiscoverInterface } from '@app/community/discover/discover-channels/discover-interface';
import { RequestOptions, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { DiscoverChannelsListRequest, DiscoverChannelsListResponse, FollowChannelResponse, FollowChannelRequest } from '@app/community/community.messages'

import { FollowerListInterface } from '@app/dashboard/dashboard-interface';
import { ShowChannelProfileComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { ShowFollowerProfileComponent } from '@app/profile/user/show-follower-profile/show-follower-profile.component';
import { CategoriesService } from '@app/shared/categories/categories.service';
//jquery declare
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-discover-channels',
  templateUrl: './discover-channels.component.html',
  providers: [DiscoverChannelsService, DashboardService, BaseComponent]
})

export class DiscoverChannelsComponent extends BaseComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  editChannelProfileSideNav: boolean;
  showChannelProfileSideNav: boolean;
  discoverChannelsList: any[];
  followClicked: string;
  discoverChannelListRequest: DiscoverChannelsListRequest = new DiscoverChannelsListRequest();
  discoverChannelListResponse: DiscoverChannelsListResponse = new DiscoverChannelsListResponse();
  clickedChnlDetails: any;
  followChannelRequest = new FollowChannelRequest()
  userId: string;
  @ViewChild(ShowChannelProfileComponent) showChnlProfile: ShowChannelProfileComponent;
  showChnlProfileDetails: any;
  @ViewChild(ShowFollowerProfileComponent)
  private memberProfile: ShowFollowerProfileComponent;
  currentTime: any;
  searchFilterInput: any;

  constructor(public dialog: MatDialog, private discoverService: DiscoverChannelsService,
    private http: Http, public loggerService: LoggerService,
    public toastr: ToastrService, public router: Router, private categoriesService: CategoriesService
  ) {
    super(loggerService, router, toastr);
    if (BaseComponent.onlineOffline) {
      this.discoverService.showLoader();

    } else {
      this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
    }

    jQuery(document).ready(function () {
      // slide out search
      var sliBtn = '.search-btn',
        sliCont = '.search-slide',
        sliTxt = '.search-slide input[type=search]',
        sliDis = '.search-close-bar',
        sliSpd = 300;

      $(sliBtn).click(function () {
        $(sliCont).animate(
          { 'width': '16.5625em' }, sliSpd
        );
        $(sliTxt).focus();
      });
      $(sliDis).click(function () {
        $(sliCont).animate(
          { 'width': 0 }, sliSpd
        );
      });
    });
  }

  ngOnInit() {
    /* bg color change code */
    UserStrings.LOGGEDIN_USER_DETAILS = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS));
    this.userId = UserStrings.LOGGEDIN_USER_DETAILS.user.userId;
    document.getElementsByTagName("body")[0].setAttribute("id", "lightergrayColorBody");
    localStorage.removeItem('createCommunityData');
    this.getDiscoverChannelsList();
  }

  resetDiscover(){
    this.getDiscoverChannelsList();
    this.searchFilterInput = '';
  }

  getDiscoverChannelsList() {

    this.discoverService.getDiscoverChannelsList(this.discoverChannelListRequest).subscribe(response => this.handleResponseOfDiscoverChannelList(response),
      error => this.handleError(error));
  }

  handleResponseOfDiscoverChannelList(response: DiscoverChannelsListResponse) {
    this.currentTime = this.discoverService.generateMessagetime();
    //this.loggerService.info(response)
    if (response.success) {
      this.discoverService.hideLoader();
      this.discoverChannelsList = response.communityDetailsList;
    } else {
      this.toastr.error('Error getting channels list ', 'Error !!')
      this.discoverService.hideLoader();
    }
  }

  channelDetails(channelDetails) {
    localStorage.setItem('createCommunityData', JSON.stringify(channelDetails))
    this.clickedChnlDetails = JSON.parse(localStorage.getItem('createCommunityData'));
    if (this.showChnlProfile) {
      this.showChnlProfile.ngOnInit();
    }
  }


  followChannel(channel) {

    // $("#" + channel.communityKey).text("Following").removeClass('follow').addClass('following').unbind("click").css("pointer-events", "none");
    this.discoverService.showLoader();
    this.followChannelRequest.i_jabber_id = channel.communityJabberId;
    this.discoverService.followChannel(this.followChannelRequest, channel.communityKey).subscribe(response => this.handleresponseOfFollowChannel(response),
      error => this.handleError(error));
  }

  handleresponseOfFollowChannel(response: FollowChannelResponse) {
    this.loggerService.info('response of follow channel   : ', response)

    if (response.success == true) {
      this.discoverService.hideLoader()
      this.getDiscoverChannelsList();
      this.toastr.success('Channel Followed successfully.', 'Success !!');
    } else {
      this.discoverService.hideLoader();
      this.toastr.error('Channel Follow Error.', 'Error !!');
    }
  }

  openDrawer(name: string): void {
    if (name == 'followChannel') {
      this.followChannel(JSON.parse(localStorage.getItem('createCommunityData')));
      // this.showDrawer(name);
    }
    else if (name == 'successleave') {
      this.getDiscoverChannelsList();
      this.showDrawer('closeRightDrawer');
      // $("#" + channel.communityKey).text("Follow").removeClass('following').addClass('follow').unbind("click").css("pointer-events", "none");
    } else {
      this.showDrawer(name);
      if (this.memberProfile) {
        this.memberProfile.ngOnInit()
      }
    }
    localStorage.setItem('closeDrawer', 'closeRight');

  }

  openFilterDialog(value) {
    localStorage.setItem(Strings.NAVIGATE_FROM, Strings.FILTER_POPUP)
    let dialogRef = this.dialog.open(CategoriesComponent, {
      panelClass: 'my-full-screen-dialog',
      data: { id: value }
    });

    // dialogRef.afterClosed().subscribe(result => {
    //   console.log(`Dialog result  :}`); // Pizza!
    //   let discoverList = JSON.parse(localStorage.getItem('discoverFilterList'));
    //   if(discoverList && discoverList.communityDetailsList){
    //     this.discoverChannelsList = discoverList.communityDetailsList;
    //     localStorage.removeItem('discoverFilterList')
    //   }
        
    // });
    
    dialogRef.componentInstance.onAdd.subscribe((data) => {
      if(data && data.communityDetailsList)
        this.discoverChannelsList = data.communityDetailsList;
   
    });

  }

  // dialogRef.componentInstance.onAdd.subscribe((data) => {
   
  // });

  removeCommunityData() {
    localStorage.removeItem('createCommunityData')
    this.router.navigate(["welcome-dashboard"])
  }
  searchComunityOnClick() {
    let textEntered = this.searchFilterInput;
    if (textEntered) {

      this.discoverService.searchChannel(textEntered).subscribe(
        res => {
          this.discoverChannelsList = res.communityDetailsList;
          console.log("searchComunityOnClick :: ", res.communityDetailsList);
        },
        err => {
          console.log("searchComunityOnClick :: Err ", err);
        }
      )
    }

  }

}