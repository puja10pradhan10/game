import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { DiscoverChannelsComponent } from '@app/community/discover/discover-channels/discover-channels.component';
import { DiscoverChannelsService } from '@app/community/discover/discover-channels/discover-channels.service';


// describe('DiscoverGroupsComponent', () => {
//   let component: DiscoverChannelsComponent;
//   let fixture: ComponentFixture<DiscoverChannelsComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ DiscoverChannelsComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DiscoverChannelsComponent);
//     component = fixture.componentInstance;
//     // fixture.detectChanges();
//   });

//   it('should create', () => {
    
//     expect(component.getChannels()).toHaveBeenCalled();
//   });
// it('retrieves all the cars', async(inject( [DiscoverChannelsService], ( DiscoverChannelsService ) => {
//     DiscoverChannelsService.getChannels().subscribe(result => expect(result.length).toBeGreaterThan(0)); 
// })));

// });
