import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscoverGroupsComponent } from './discover-groups.component';

describe('DiscoverGroupsComponent', () => {
  let component: DiscoverGroupsComponent;
  let fixture: ComponentFixture<DiscoverGroupsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiscoverGroupsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscoverGroupsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
