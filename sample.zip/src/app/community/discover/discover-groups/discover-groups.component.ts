import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discover-groups',
  templateUrl: './discover-groups.component.html',
  styleUrls: ['./discover-groups.component.css']
})
export class DiscoverGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
