import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiscoverChannelsComponent } from '@app/community/discover/discover-channels/discover-channels.component';
import { DiscoverGroupsComponent } from '@app/community/discover/discover-groups/discover-groups.component';
import { CreateCommunityComponent } from '@app/community/create/create-community/create-community.component';
import { CommunityInfoComponent } from '@app/community/create/community-info/community-info.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '@app/shared/shared.module';
import { ColorPickerModule } from 'ngx-color-picker';
import { DiscoverChannelsService } from '@app/community/discover/discover-channels/discover-channels.service';
import { CommunityService } from '@app/community/community.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SharedModule,
    ColorPickerModule
  ],
  declarations: [DiscoverChannelsComponent, DiscoverGroupsComponent, CreateCommunityComponent,
    CommunityInfoComponent],
  providers: [DiscoverChannelsService, CommunityService]
})
export class CommunityModule { }
