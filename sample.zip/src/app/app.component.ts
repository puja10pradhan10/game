import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { TranslateStrings, Strings } from '@app/shared/base.constants';
import { TranslateService } from 'ng2-translate/ng2-translate';
import { connect, connection } from '@assets/js/chat.js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  host: {
    '(window:resize)': 'onResize($event)'
  }
})
export class AppComponent implements OnInit {
  title = 'app';
  currentPath: any;

  constructor(private translateService: TranslateService, private router: Router) {

  }

  ngOnInit() {
    let lang = localStorage.getItem(TranslateStrings.TRANSLATE);
    if (lang != Strings.NULL) {
      this.translateService.use(lang)
    } else {
      this.translateService.use(this.translateService.getBrowserLang());
    }

    if (localStorage.getItem('disableBack') && localStorage.getItem('disableBack') == 'disable') {
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
    }

    if (window.innerWidth == 600 || window.innerWidth > 767) {
      if (localStorage.getItem('currentPath') && localStorage.getItem('currentPath') != '') {
        this.currentPath = localStorage.getItem('currentPath');
        this.router.navigate([this.currentPath]);
      }
    }
    else if (window.innerWidth <= 767) {
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
      this.router.navigate(["mobile-splash"]);
    } else {
    }
  }

  onResize(event) {
    if (event.target.innerWidth == 600 || event.target.innerWidth > 767) {
      if (localStorage.getItem('currentPath') && localStorage.getItem('currentPath') != '') {
        this.currentPath = localStorage.getItem('currentPath');
        this.router.navigate([this.currentPath]);
      }
    }
    else if (event.target.innerWidth <= 767) {
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
      this.router.navigate(["mobile-splash"]);
    } else {

    }
  }
}
