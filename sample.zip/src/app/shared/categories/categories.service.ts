import { Injectable } from '@angular/core';
import { CategoryInterface } from '@app/shared/categories/category-interface';
import { Http } from '@angular/http';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { environment } from '@env/environment';
import { CreateChannelRequest, CreateChannelResponse } from '@app/community/community.messages'
import { Strings, HeaderString } from '@app/shared/base.constants';

@Injectable()
export class CategoriesService extends BaseService {

  result: any;
  constructor(public loggerService: LoggerService, public http: Http,
    public baseService: BaseService) {
    super(loggerService, http)
  }
  getCategories(): Observable<CategoryInterface[]> {
    return this.http.get('../assets/json/categories.json')
      .map(response => response.json());
  }

  createChannel(createChannelRequest: CreateChannelRequest): Observable<CreateChannelResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, Strings.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));

    let createChannelUrl = environment.oAuthConfig.API_BASE_URL + "communities";
    // return;
    return this._http.post(createChannelUrl, createChannelRequest, options)
      .map((response: Response) => <CreateChannelResponse>response.json())
      .do(data => this.loggerService.info('create channel Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  applyCatagoryFilter(filterList: any): Observable<CreateChannelResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, Strings.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    let currentTime = this.baseService.generateMessagetime();

    let createChannelUrl = environment.oAuthConfig.API_BASE_URL + 'communities?page_number=1&page_size=1000&search_text=&user_field_value=&user_field_name=&filter_category_ids='+filterList+'&CURRENT_TIMESTAMP='+ currentTime;
    // return;
    return this._http.get(createChannelUrl, options)
      .map((response: Response) => <CreateChannelResponse>response.json())
      .do(data => this.loggerService.info('create channel Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }
  

}
