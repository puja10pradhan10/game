import { Component, OnInit, EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { MatDialog } from '@angular/material';

//Components
import { BaseComponent } from '@app/shared/base/base.component'
//Services
import { CategoriesService } from '@app/shared/categories/categories.service';
import { MembershipService } from '@app/membership/membership.service';
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';

import { CategoryInterface } from '@app/shared/categories/category-interface';
import { Strings, FacebookLoginStrings, UserStrings, DefaultColor } from '@app/shared/base.constants';
import { connectionXmpp } from '@app/shared/base.constants';
import { UpdateUserRequest, UpdateUserResponse } from '@app/membership/membership.messages';
import { CreateChannelRequest, CreateChannelResponse } from '@app/community/community.messages';
import { Observable } from 'rxjs/Observable';
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  providers: [CategoriesService]
})
export class CategoriesComponent extends BaseComponent implements OnInit {
  catServiceData: CategoryInterface[];
  updateUserRequest: UpdateUserRequest = new UpdateUserRequest();

  selectedCategoryForChannel: any;
  channelData: any;
  channelColor = DefaultColor.color;
  setHeader: string = '';
  showBackArrow: boolean = false;
  token: string;
  userDetails: any
  categoryIdForChannel = []
  categoryIdForRegister = [];
  catName = [];
  categoriesData: CategoryInterface[];
  createChannelRequest = new CreateChannelRequest();
  onAdd = new EventEmitter();


  constructor(public router: Router, private categoriesService: CategoriesService, public dialog: MatDialog,
    public loggerService: LoggerService, public toastr: ToastrService,
    public membershipService: MembershipService, public baseService: BaseService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
    document.getElementsByTagName("body")[0].setAttribute("id", "lightgrayColorBody");

    if (connectionXmpp.connection == Strings.UNDEFINED && localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.REGISTRATION) {
    }

    this.userDetails = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS));
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));

    this.setBackgroundColor();
    this.getCategories();
    this.setHeaderTitle();
  }

  setHeaderTitle(): void {
    if (localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.REGISTRATION ||
      localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.ADD_MORE_USER_PROFILE) {
      this.setHeader = Strings.REGISTRATION_CATEGORY_HEADER;
      this.showBackArrow = false;
    } else if (localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.CREATE_CHANNEL) {
      this.setHeader = Strings.CHANNEL_CATEGORY_HEADER;
      this.showBackArrow = true;
      this.channelColor = this.channelData.channelColor;
    }
    else if (localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.FILTER_POPUP) {
      this.setHeader = Strings.FILTER_POPUP_HEADER;
      this.showBackArrow = true;
    } else {
      localStorage.setItem('disableBack', 'disable');
      this.setHeader = Strings.CHANNEL_CATEGORY_HEADER
      this.showBackArrow = false;
    }

  }

  getCategories() {
    if (localStorage.getItem('userDetails') && localStorage.getItem('navigateFrom') == 'addMoreUserProfile') {
      let categoriesData;
      // let areaOfInterest = this.userDetails['user']['userProfile']['interests'];
      // this.categoryIdForRegister = areaOfInterest;

      var areaOfInterest = [];

      let temp = localStorage.getItem('chnlIntrestCat');
      areaOfInterest = temp.split(",");
      this.categoryIdForRegister = temp.split(",");

      this.selectedCategoryForChannel = this.categoryIdForRegister.join();

      this.categoriesService.getCategories().subscribe(categoriesData => {
        if (categoriesData.length) {
          $.LoadingOverlay("hide");
          for (let catList = 0; catList < categoriesData.length; catList++) {
            for (let i = 0; i < areaOfInterest.length; i++) {
              if (categoriesData[catList]['id'] == areaOfInterest[i]) {
                categoriesData[catList]['checked'] = true;
              }
            }
          }
          this.categoriesData = categoriesData;
        } else {
          console.log('error to get categories');
        }
      });
    }
    else if (localStorage.getItem('userDetails') && localStorage.getItem('navigateFrom') == 'addMoreChannelProfile') {
      this.channelColor = this.channelData.communityDominantColour;
      var areaOfInterest = [];

      let temp = localStorage.getItem('chnlIntrestCat');
      areaOfInterest = temp.split(",");
      this.categoryIdForChannel = temp.split(",");

      this.selectedCategoryForChannel = this.categoryIdForChannel.join();

      this.categoriesService.getCategories().subscribe(categoriesData => {
        if (categoriesData.length) {
          $.LoadingOverlay("hide");
          for (let catList = 0; catList < categoriesData.length; catList++) {
            for (let i = 0; i < areaOfInterest.length; i++) {
              if (categoriesData[catList]['id'] == areaOfInterest[i]) {
                categoriesData[catList]['checked'] = true;
              }
            }
          }
          this.categoriesData = categoriesData;
        } else {
          console.log('error to get categories');
        }
      });
    }
    else {
      this.categoriesService.getCategories().subscribe(response => {
        this.categoriesData = response
      });
    }
  }

  setBackgroundColor(): void {
    if (localStorage.getItem('createCommunityData')) {
      // this.channelColor = this.channelData.communityDominantColour;
      this.channelColor = this.channelData.channelColor;
    } else {
      this.channelColor = DefaultColor.color;
    }
  }


  onClickCheckbox(id, name) {
    if (localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.REGISTRATION || localStorage.getItem('navigateFrom') == 'profile') {

      let a = this.catName.indexOf(name);
      let b = this.categoryIdForRegister.indexOf(id);
      if ((a >= 0) && (b >= 0)) {
        this.catName.splice(a, 1);
        this.categoryIdForRegister.splice(b, 1);
      } else {
        this.catName.push(name);
        this.categoryIdForRegister.push(id);
      }
      this.selectedCategoryForChannel = this.categoryIdForRegister.join(',');
    }
    else if (localStorage.getItem(Strings.NAVIGATE_FROM) == 'addMoreUserProfile') {

      let b = this.categoryIdForRegister.indexOf(id);
      if (b >= 0) {
        this.categoryIdForRegister.splice(b, 1);
      } else {
        this.categoryIdForRegister.push(id);
      }

    }
    else if (localStorage.getItem(Strings.NAVIGATE_FROM) == 'addMoreChannelProfile') {

      let a = this.categoryIdForChannel.indexOf(id);
      if (a >= 0) {
        this.categoryIdForChannel.splice(a, 1);
      } else {
        if (this.categoryIdForChannel.length >= 3) {
          this.toastr.info('Maximum 3 categories are allowed.', 'Info !!');
          return false;
        } else {
          this.categoryIdForChannel.push(id);
        }
      }
      this.selectedCategoryForChannel = this.categoryIdForChannel.join();
      this.loggerService.info(this.selectedCategoryForChannel)
    }
    else {
      let a = this.categoryIdForChannel.indexOf(id);
      if (a >= 0) {
        this.categoryIdForChannel.splice(a, 1);
      } else {
        if (this.categoryIdForChannel.length >= 3) {
          this.toastr.info('Maximum 3 categories are allowed.', 'Info !!');
          return false;
        } else {
          this.categoryIdForChannel.push(id);
        }
      }
      this.selectedCategoryForChannel = this.categoryIdForChannel.join();
      this.loggerService.info(this.selectedCategoryForChannel)
    }
  }


  goToDashboard() {
    if (localStorage.getItem(Strings.CURRENT_PATH) == '/categories' && localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.REGISTRATION) {
      this.loggerService.info('catid', this.categoryIdForRegister)

      if (!this.categoryIdForRegister.length) {
        this.toastr.info('Please select atleast one interest.', 'Info !!')
        return false;
      } else {
        this.categoriesService.showLoader();
        if (!BaseComponent.onlineOffline) {
          this.toastr.info('No internet connection, Please connect your internet ', 'Info !!');
          this.categoriesService.hideLoader()
        } else {

          this.updateUserRequest.categories = this.selectedCategoryForChannel;
          this.updateUserRequest.firstName = this.userDetails.user.firstName;
          this.updateUserRequest.lastName = this.userDetails.user.lastName;
          this.updateUserRequest.about = this.userDetails.user.userProfile.about;

          if (this.userDetails.user.userProfile.mobile1 == "") {
            this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile2;
          } else {
            this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile1;
          }
          this.updateUserRequest.accountType = this.userDetails.user.userProfile.accountType;
          this.updateUserRequest.image_url = this.userDetails.user.userProfile.imageUrl;
          this.updateUserRequest.city = this.userDetails.user.userProfile.city;
          this.updateUserRequest.country = this.userDetails.user.userProfile.country;
          this.updateUserRequest.email = this.userDetails.user.email;
          this.updateUserRequest.small_thumb_url = this.userDetails.user.userProfile.imageSmallthumbUrl;
          this.updateUserRequest.oAuthToken = this.userDetails.oAuthToken;
          this.updateUserRequest.password = this.userDetails.user.userId;
          this.updateUserRequest.state = this.userDetails.user.userProfile.state;


          this.membershipService.updateUserAreaOfInterest(this.selectedCategoryForChannel, this.updateUserRequest)
            .subscribe(response => this.handleResponseOfUpdateUserAreaOfInterest(response),
              error => this.handleError(error)
            )
        }
      }

    } else if (localStorage.getItem(Strings.CURRENT_PATH) == '/categories' && localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.CREATE_CHANNEL) {
      if (this.selectedCategoryForChannel) {
        if (this.selectedCategoryForChannel.length) {

          this.createChannelRequest.communityDetails.communityName = this.channelData.channelName;
          this.createChannelRequest.communityDetails.communityDominantColour = this.channelData.channelColor;
          this.createChannelRequest.communityDetails.communityCategories = this.selectedCategoryForChannel;
          this.createChannelRequest.communityDetails.communityJabberId = this.channelData.communityJabberId;
          this.createChannelRequest.communityDetails.communityImageBigThumbUrl = this.channelData.communityImageUrl;
          this.createChannelRequest.communityDetails.communityImageSmallThumbUrl = this.channelData.communityImageUrl;
          this.createChannelRequest.communityDetails.communityImageUrl = this.channelData.communityImageUrl;
          this.createChannelRequest.communityDetails.communityDesc = this.channelData.aboutChannel || "";
          this.createChannelRequest.communityDetails.privacy = this.channelData.channelType;
          this.createChannelRequest.communityDetails.ownerId = this.userDetails.user.userId;
          this.createChannelRequest.communityDetails.ownerImageUrl = this.userDetails.user.imageBigthumbUrl;
          this.createChannelRequest.communityDetails.ownerName = this.userDetails.user.firstName + " " + this.userDetails.user.lastName;

          this.createChannelRequest.communityDetails.communityJoinedTimestamp = this.baseService.generateMessagetime();
          this.createChannelRequest.resource = "web";

          this.createChannelRequest.password = localStorage.getItem('password');
          this.loggerService.info(JSON.stringify(this.createChannelRequest));
          localStorage.setItem('createCommunityData', JSON.stringify(this.createChannelRequest));

          this.categoriesService.showLoader();
          this.categoriesService.createChannel(this.createChannelRequest)
            .subscribe(response => this.handleResponseOfCreateChannel(response),
              error => this.handleError(error)
            )
        }
        else {
          this.toastr.info('Please select atleast one category.', 'Info !!')
          return false;
        }
      }
      else {
        this.toastr.info('Please select atleast one category.', 'Info !!')
        return false;
      }
    }
    else if (localStorage.getItem(Strings.NAVIGATE_FROM) == 'addMoreUserProfile') {
      this.onAdd.emit(this.categoryIdForRegister);
      this.dialog.closeAll()
      return false;
    }
    else if (localStorage.getItem('currentPath') == '/channel-dashboard' && localStorage.getItem(Strings.NAVIGATE_FROM) == 'addMoreChannelProfile') {
      this.onAdd.emit(this.selectedCategoryForChannel);
      this.dialog.closeAll()
      return false;
    }
    else if (localStorage.getItem('currentPath') == '/channel-list' && localStorage.getItem(Strings.NAVIGATE_FROM) == 'addMoreChannelProfile') {
      localStorage.removeItem(Strings.NAVIGATE_FROM)
      this.onAdd.emit(this.selectedCategoryForChannel);
      this.dialog.closeAll()
      return false;
    }
    else if (localStorage.getItem('currentPath') == '/channel-list' && localStorage.getItem(Strings.NAVIGATE_FROM) == 'filterPopup') {
      this.applyFilterService();
      
      return false;
    }
    else {

    }
  }

  applyFilterService(){
    let selectListOfIds = this.categoryIdForChannel;
    let filterString : string = '';
    for(let item of selectListOfIds ){
      filterString += item+','
    }
    filterString = filterString.slice(0, -1);
    console.log("Filter query " +filterString);
    this.categoriesService.applyCatagoryFilter(filterString).subscribe(
      response => {
        this.categoriesService.hideLoader();
        this.toastr.success('Filter applied successfully.', 'Success !!')
        //localStorage.setItem("discoverFilterList", JSON.stringify(response));
        this.onAdd.emit(response);
      this.dialog.closeAll();

    },
    err =>{
      this.categoriesService.hideLoader();
      console.log("Filter Error");
      this.toastr.success('Filter applied Failed.', 'Success !!')
      this.dialog.closeAll();
    }
  );
  this.categoriesService.showLoader();

  }

  goBack() {
    if (localStorage.getItem('currentPath') == '/categories' && localStorage.getItem(Strings.NAVIGATE_FROM) == "create-channel") {
      this.router.navigate(['community-info'])

    } else if (localStorage.getItem('currentPath') == '/categories' && localStorage.getItem(Strings.NAVIGATE_FROM) == Strings.REGISTRATION) {
      this.loggerService.info(' Dont go back ')
    } else if (localStorage.getItem('currentPath') == '/welcome-dashboard' || localStorage.getItem('currentPath') == '/channel-dashboard'
      || localStorage.getItem('currentPath') == '/channel-list') {
      this.dialog.closeAll()
    } else {
      return false;
    }
  }

  handleResponseOfUpdateUserAreaOfInterest(response: UpdateUserResponse) {
    this.loggerService.info(JSON.stringify(response))

    if (response.success) {
      this.toastr.success('Interest updated successfuly', 'Success !! ')
      this.userDetails['user']['userProfile']['interests'] = this.categoryIdForRegister;
      localStorage.setItem(UserStrings.USER_DETAILS, JSON.stringify(this.userDetails))
      // let xmppResponse = new Observable(this.connectToServer);
      // xmppResponse.subscribe(
      //   (res) => {
      //   },
      //   (complete) => {
      //   }
      // );
      this.categoriesService.hideLoader();
      this.router.navigate(['welcome-dashboard']);
    } else {
      this.categoriesService.hideLoader()

      this.toastr.error('Error occured while updating interest', 'Error !!')

    }
  }



  handleResponseOfCreateChannel(response: CreateChannelResponse) {
    if (response.success) {
      localStorage.removeItem('chnlProfileImage')
      this.categoriesService.hideLoader();
      let channelCreatedData = JSON.parse(localStorage.getItem('createCommunityData'));

      let storeChnlData = {
        "communityKey": response['communityKey'],
        "requestId": response['requestId'],
        "communityCategories": channelCreatedData.communityDetails.communityCategories,
        "description": channelCreatedData.communityDetails.description,
        "communityDominantColour": channelCreatedData.communityDetails.communityDominantColour,
        "communityImageBigThumbUrl": channelCreatedData.communityDetails.communityImageBigThumbUrl,
        "communityImageSmallThumbUrl": channelCreatedData.communityDetails.communityImageSmallThumbUrl,
        "communityImageUrl": channelCreatedData.communityDetails.communityImageUrl,
        "communityJoinedTimestamp": channelCreatedData.communityDetails.communityJoinedTimestamp,
        "communityJabberId": channelCreatedData.communityDetails.communityJabberId,
        "communityName": channelCreatedData.communityDetails.communityName,
        "communityDesc": channelCreatedData.communityDetails.communityDesc,
        "communityScore": channelCreatedData.communityDetails.communityScore,
        "finalScore": channelCreatedData.communityDetails.finalScore,
        "ownerName": channelCreatedData.communityDetails.ownerName,
        "ownerId": channelCreatedData.communityDetails.ownerId,
        "privacy": channelCreatedData.communityDetails.privacy,
        "totalMembers": channelCreatedData.communityDetails.totalMembers,
        "type": channelCreatedData.communityDetails.type,
        "isCommunityWithRssFeed": channelCreatedData.communityDetails.isCommunityWithRssFeed,
        "isDefault": channelCreatedData.communityDetails.isDefault,
        "isMember": true
      }

      localStorage.setItem('createCommunityData', JSON.stringify(storeChnlData));
      setTimeout(() => this.toastr.success('Channel created successfully', 'Success !!'));
      this.router.navigate(["channel-dashboard"]);
    }
    else {
      this.categoriesService.hideLoader();
      this.toastr.error('Error while creating channel', 'Error !!')
    }
  }




}
