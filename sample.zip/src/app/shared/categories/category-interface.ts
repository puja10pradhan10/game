export interface CategoryInterface {
    id: any;
    name: any;
    image_url: any;
    is_occupation: boolean;
    checked: any;
}
