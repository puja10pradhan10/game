export class BaseRequest {
    token: string;
    appKey: string;
    appSecret: string;
    client_id:string;
    client_secret:string;
    resource : string = "web";
    // appKey:"X-API-KEY";
    // appSecret:"X-API-SECRET";
    // Authorization:string;
    // request_id:any;
}
export class BaseResponse {
    success: boolean;
    message: string;
    timeInMillis: string;
    responseCode: number;
}