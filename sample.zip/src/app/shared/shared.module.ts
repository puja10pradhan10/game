import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateLoader, TranslateStaticLoader, MissingTranslationHandler } from 'ng2-translate';


import { FlexLayoutModule } from '@angular/flex-layout';
import { PerfectScrollbarModule, PerfectScrollbarConfigInterface } from "ngx-perfect-scrollbar";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ImageCropperModule } from 'ngx-image-cropper';

import {
	MatNativeDateModule,
	MatDialogModule,
	MatDialogRef,
	MAT_DIALOG_DATA,
	MatButtonModule,
	MatButtonToggleModule,
	MatCardModule,
	MatCheckboxModule,
	MatGridListModule,
	MatIconModule,
	MatInputModule,
	MatListModule,
	MatMenuModule,
	MatRadioModule,
	MatRippleModule,
	MatSelectModule,
	MatSidenavModule,
	MatTabsModule,
	MatToolbarModule,
	MatTooltipModule,
	MatFormFieldModule,
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { BaseComponent, cropImageComponent,webcamPopupComponent } from '@app/shared/base/base.component';
import { CategoriesComponent } from '@app/shared/categories/categories.component';
import { MissingTranslationsComponent } from '@app/missingTranslations.component';

import { LoggerService } from '@app/shared/logger/logger.service';
import { BaseService } from '@app/shared/base.service';
import { ConsoleLoggerService } from '@app/shared/logger/console-logger.service';
import { CsvComponent, GettingContactsPopupComponent, ContactsImportedPopupComponent } from './invite/csv/csv.component';
import { InviteMemberListComponent, MemberConfirmComponent } from './invite/invite-member-list/invite-member-list.component';
import { ManualInviteComponent } from './invite/manual-invite/manual-invite.component';

import { RouterModule } from "@angular/router";

import { NavigationDrawerComponent } from '@app/profile/navigation-drawer/navigation-drawer.component';
import { ShowUserProfileComponent } from '@app/profile/user/show-user-profile/show-user-profile.component';
import { ShowFollowerProfileComponent } from '@app/profile/user/show-follower-profile/show-follower-profile.component';
import { EditUserProfileComponent } from '@app/profile/user/edit-user-profile/edit-user-profile.component';
import { EditChannelProfileComponent } from '@app/profile/channel/edit-channel-profile/edit-channel-profile.component';
import { ShowChannelProfileComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { ColorPickerModule } from 'ngx-color-picker';

export function createTranslateLoader(http: Http) {
	return new TranslateStaticLoader(http, './assets/i18n', '.json');
}

@NgModule({
	imports: [
		CommonModule,
		MatNativeDateModule,
		MatDialogModule,
		MatButtonModule,
		MatButtonToggleModule,
		MatCardModule,
		MatCheckboxModule,
		MatGridListModule,
		MatIconModule,
		MatInputModule,
		MatListModule,
		MatMenuModule,
		MatRadioModule,
		MatRippleModule,
		MatSelectModule,
		MatSidenavModule,
		MatTabsModule,
		MatToolbarModule,
		MatTooltipModule,
		MatFormFieldModule,
		FormsModule,
		HttpModule,
		FlexLayoutModule,
		BrowserAnimationsModule,
		PerfectScrollbarModule,
		TranslateModule.forRoot({
			provide: TranslateLoader,
			useFactory: (createTranslateLoader),
			deps: [Http]
		}),
		RouterModule,
		ColorPickerModule,
		ImageCropperModule
	],
	exports: [
		MatNativeDateModule,
		MatDialogModule,
		MatButtonModule,
		MatButtonToggleModule,
		MatCardModule,
		MatCheckboxModule,
		MatGridListModule,
		MatIconModule,
		MatInputModule,
		MatListModule,
		MatMenuModule,
		MatRadioModule,
		MatRippleModule,
		MatSelectModule,
		MatSidenavModule,
		MatTabsModule,
		MatToolbarModule,
		MatTooltipModule,
		MatFormFieldModule,
		FormsModule, HttpModule,
		FlexLayoutModule,
		BrowserAnimationsModule,
		PerfectScrollbarModule,
		TranslateModule,
		NavigationDrawerComponent,
		ShowUserProfileComponent,
		ShowFollowerProfileComponent,
		EditUserProfileComponent,
		EditChannelProfileComponent,
		ShowChannelProfileComponent
	],
	declarations: [
		BaseComponent, cropImageComponent, CategoriesComponent, CsvComponent, InviteMemberListComponent,
		ManualInviteComponent, NavigationDrawerComponent, ShowUserProfileComponent, ShowFollowerProfileComponent,
		EditUserProfileComponent, EditChannelProfileComponent, ShowChannelProfileComponent,
		GettingContactsPopupComponent, ContactsImportedPopupComponent, MemberConfirmComponent,webcamPopupComponent
	],
	providers: [{ provide: LoggerService, useClass: ConsoleLoggerService },
	{ provide: MissingTranslationHandler, useClass: MissingTranslationsComponent }, BaseService
	],
	entryComponents: [
		GettingContactsPopupComponent,
		MemberConfirmComponent,
		ContactsImportedPopupComponent,
		cropImageComponent,
		webcamPopupComponent
	],
})
export class SharedModule { }
