import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-manual-invite',
  templateUrl: './manual-invite.component.html',
  styleUrls: ['./manual-invite.component.scss']
})
export class ManualInviteComponent implements OnInit {
  color: any;
  
  constructor(private router: Router,private toastr: ToastrService) { }

  ngOnInit() {
    this.color ='#00B35A';
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "bgcolorWhite");
  }

  sendInvite(){
    this.toastr.success('Invitation sent successfuly ', 'Success !!')

  }
}
