// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ManualInviteComponent } from './manual-invite.component';

// describe('ManualInviteComponent', () => {
//   let component: ManualInviteComponent;
//   let fixture: ComponentFixture<ManualInviteComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ManualInviteComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ManualInviteComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
