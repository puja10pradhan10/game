import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { MatDialog, MatDialogRef } from '@angular/material';

import { GettingContactsPopupComponent } from '@app/shared/invite/csv/csv.component'

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-invite-member-list',
  templateUrl: './invite-member-list.component.html',
  styleUrls: ['./invite-member-list.component.scss']
})
export class InviteMemberListComponent implements OnInit {

  constructor(private router: Router, public dialog: MatDialog) { }

  ngOnInit() {
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "bgcolorWhite");

    


    
  }
  openDialogmemberConfirm() {
    this.dialog.open(MemberConfirmComponent)
  }
}

@Component({
  selector: 'app-file-popup',
  template: `
  <div class="whiteOuter memberConfirmPopup">
  <h2 mat-dialog-title>Send Invitation</h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" mat-dialog-close="cancel"> Cancel</button>
    <button type="submit" class="btnPopup btnGreen" mat-dialog-close="ok" (click)="navigate()" (click)="dialogRef.close()"> Confirm</button>
  </mat-dialog-actions>
  </div>
`
})
export class MemberConfirmComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<MemberConfirmComponent>, public dialog: MatDialog,
  private router : Router, private toastr : ToastrService) { }
  ngOnInit() {
  }
  navigate() {
    this.router.navigate(['welcome-dashboard']);

    this.toastr.success('Invitation sent successfuly ','Success !!')
  }
}



