// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { InviteMemberListComponent } from './invite-member-list.component';

// describe('InviteMemberListComponent', () => {
//   let component: InviteMemberListComponent;
//   let fixture: ComponentFixture<InviteMemberListComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ InviteMemberListComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(InviteMemberListComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
