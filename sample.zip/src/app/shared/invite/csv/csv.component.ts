import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { MatDialog, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-csv',
  templateUrl: './csv.component.html',
  styleUrls: ['./csv.component.scss']
})
export class CsvComponent implements OnInit {
  color: any;
  constructor(private router: Router, public dialog: MatDialog) { }
  
  goToManualInvite(){
    this.router.navigate(["manual-invite"]);
  }

  ngOnInit() {
    this.color ='#00B35A';

    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "bgcolorWhite");
  }

  

  fileChangeEvent(fileInput: any) {
    this.dialog.open(GettingContactsPopupComponent);
  }
}


@Component({
  selector: 'app-getting-contacts-popup',
  template: `
  <div class="csvPopup">
    <div class="loaderIcon">
        <div class="lds-css ng-scope" (click)= "contactsImported()">
            <div style="width:100%;height:100%" class="lds-rolling">
            <img src="assets/img/access_contacts.png" alt="access_contacts" />
              <div></div>
            </div>
        </div>
  </div>
    <h2 matDialogTitle >Getting Contacts...</h2>
  </div>
`
})
export class GettingContactsPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<GettingContactsPopupComponent>, public dialog: MatDialog,
  public router : Router) { }
  ngOnInit() {

  this.router.navigate(['invite-member-list'])
      

  }

  contactsImported(){

    this.dialog.closeAll()

    this.dialog.open(ContactsImportedPopupComponent)

  }

  

}

@Component({
  selector: 'app-contacts-imported-popup',
  template: `
  <div class="csvPopup">
    <div class="loaderIcon black"><i class="zmdi zmdi-check"></i></div>
    <h2 mat-dialog-title>145 Contacts Imported</h2>
  </div>
`
})
export class ContactsImportedPopupComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<ContactsImportedPopupComponent>, public dialog: MatDialog,
   ) { }
    ngOnInit() {
   
  }
}

