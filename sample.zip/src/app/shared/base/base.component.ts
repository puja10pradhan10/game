import { Component, OnInit, ViewChild, Input, Inject, Output, EventEmitter, ElementRef } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
//import { Observable } from 'rxjs/Observable';
import { Observable } from 'rxjs/Rx';

import { MatDialog, MatSidenav, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PassParamsToDrawer } from '@app/shared/base.constants';

//Service
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';

import { Router } from '@angular/router';
import { FacebookLoginStrings } from '@app/shared/base.constants'
import { connectionXmpp, LoaderStrings, googleMapStrings } from '@app/shared/base.constants';

import { userDetails } from '@app/profile/profile-interface';
declare var Strophe: any;
declare var $pres: any;
declare var $iq: any;
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent implements OnInit {
  menuListSideNav: boolean;
  showUserProfileSideNav: boolean;
  editUserProfileSideNav: boolean;
  showChannelProfileSideNav: boolean;
  editChannelProfileSideNav: boolean;
  showOtherUserProfile: boolean;
  showFollowerProfileSideNav: boolean;
  static onlineOffline: boolean = navigator.onLine;
  online$: Observable<boolean>;

  @ViewChild('sidenavLeft') sidenavLeft: MatSidenav;
  @ViewChild('sidenavRight') sidenavRight: MatSidenav;

  constructor(public loggerService: LoggerService, public router: Router, public toastr: ToastrService) {
    window.addEventListener('online', () => { BaseComponent.onlineOffline = true; });
    window.addEventListener('offline', () => {
      BaseComponent.onlineOffline = false;
      this.toastr.info('No internet connection, Please connect your internet', 'Info !!')
    });

    this.online$ = Observable.merge(
      Observable.of(navigator.onLine),
      Observable.fromEvent(window, 'online').map(() => true),
      Observable.fromEvent(window, 'offline').map(() => false))

  }

  ngOnInit() {

  }


  showDrawer(name: string): void {
    if (name == PassParamsToDrawer.MENULIST) {
      this.menuListSideNav = true;
      this.showUserProfileSideNav = false;
      this.editUserProfileSideNav = false;
      this.showChannelProfileSideNav = false;
      this.editChannelProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.SHOWUSERPROFILE) {
      this.sidenavLeft.open();
      localStorage.setItem('closeDrawer', 'closeLeft');
      this.showUserProfileSideNav = true;
      this.editUserProfileSideNav = false;
      this.menuListSideNav = false;
      //this.showChannelProfileSideNav = false;
      this.editChannelProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.SHOWOTHERUSERPROFILE) {
      localStorage.setItem('closeDrawer', 'closeRight');
      this.showUserProfileSideNav = true;
      this.editUserProfileSideNav = false;
      this.menuListSideNav = false;
      this.showChannelProfileSideNav = false;
      this.editChannelProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.SHOWFOLLOWERPROFILEONCHNL) {
      localStorage.setItem('closeDrawer', 'closeRight');
      this.sidenavRight.open();
      this.showFollowerProfileSideNav = true;
    }
    else if (name == PassParamsToDrawer.SHOWFOLLOWERPROFILEONDISCOVER) {
      localStorage.setItem('closeDrawer', 'closeRight');
      this.showChannelProfileSideNav = false;
      this.showOtherUserProfile = true;
    }
    else if (name == PassParamsToDrawer.SHOWFOLLOWERPROFILEONWELCOME) {
      this.sidenavLeft.close();
      localStorage.setItem('closeDrawer', 'closeRight');
      this.showFollowerProfileSideNav = true;
      this.showChannelProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.EDITUSERPROFILE) {
      this.showUserProfileSideNav = false;
      this.editUserProfileSideNav = true;
      this.menuListSideNav = false;
      this.showChannelProfileSideNav = false;
      this.editChannelProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.SHOWCHANNELPROFILE) {
      this.showChannelProfileSideNav = true;
      this.editChannelProfileSideNav = false;
      this.menuListSideNav = false;
      this.showUserProfileSideNav = false;
      this.editUserProfileSideNav = false;
      this.showFollowerProfileSideNav = false;
      this.showOtherUserProfile = false;
    }
    else if (name == PassParamsToDrawer.EDITCHANNELPROFILE) {
      this.showChannelProfileSideNav = false;
      this.editChannelProfileSideNav = true;
      this.showUserProfileSideNav = false;
      this.editUserProfileSideNav = false;
    }
    else if (name == PassParamsToDrawer.CLOSEDRAWER) {
      this.sidenavLeft.close();
      localStorage.setItem('closeDrawer', 'closeRight');
    }
    else if (name == PassParamsToDrawer.CLOSERIGHTDRAWER) {
      this.sidenavRight.close();
      localStorage.setItem('closeDrawer', 'closeLeft');
    }
    else {
      this.loggerService.info('else in drawer');
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }

  }

  handleError(error: Response) {
    if (error['status'] == 0) {
      this.toastr.info('No internet connection, Please connect your internet ', 'Info !!');
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    if (error['status'] == 500) {
      this.toastr.info('Server Error, Please try again later', 'Info !!');
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    this.loggerService.error(error)
    if (error instanceof HttpErrorResponse) {
      this.loggerService.error('There was an HTTP error.', error.message, 'Status code:', (<HttpErrorResponse>error).status);
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    else if (error instanceof TypeError) {
      this.loggerService.error('There is a Type error.', error.message);
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    else if (error instanceof Error) {
      this.loggerService.error('There is a general error.', error.message);
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    else if (error instanceof ReferenceError) {
      this.loggerService.error('There is a Reference error.', error.message);
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    else {
      this.loggerService.error('Nobody threw an error but something happened!', error);
      $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }
    return Observable.throw(error);
  }



  connectToServer(observer) {
    let username = localStorage.getItem(FacebookLoginStrings.USERID);
    let password = localStorage.getItem(FacebookLoginStrings.MIDDLEWARE_TOKEN)
    var connection = new Strophe.Connection(connectionXmpp.boshUrl);

    connection.connect(username + '/web', password, (status) => {
      if (status === Strophe.Status.CONNECTING) {
      }
      else if (status === Strophe.Status.CONNFAIL) {
      }
      else if (status === Strophe.Status.DISCONNECTING) {
      }
      else if (status === Strophe.Status.DISCONNECTED) {
        this.connectToServer;
      }
      else if (status === Strophe.Status.CONNECTED) {
        connection.send($pres());
        localStorage.setItem('isConnected', 'true')
        connectionXmpp.connection = connection;
        observer.next(status);
        observer.complete();
      }
    });
    return { unsubscribe() { } };
  }

  disableBack(): void {
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      history.go(1);
    };
  }

  showLocation(mapData) {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        let lat = position.coords.latitude;
        let long = position.coords.longitude;
        var latlng = { lat: lat, lng: long };

        var url = googleMapStrings.MAP_URL + lat + "," + long + googleMapStrings.DESTINATION + mapData.contentField2 + "," + mapData.contentField3;
        window.open(url, '_blank')
      }, err => { this.toastr.info("Please allow to get your current location", 'Info!'); });
    } else {
      this.toastr.info("Location is not supported by this browser", 'Info!');
    }
  }

}

@Component({
  selector: 'app-webcam-image',
  template: `<div class="galleryOverlayPopup cameraCapturePopup">
  <mat-dialog-actions class="topHead pad-all-md" id="topHeader">
      <div class="leftBtn"><button matDialogClose class="closeBtn" (click)="cancel()">
      <i class="zmdi zmdi-close"></i></button><span> {{imageLeftHeaderPopup}}</span></div>
      <div class="rightBtn" *ngIf="showSubmitBtn" (click)="capture()">
      <button class="retakeButton"><i class="zmdi zmdi-check"></i></button>
      <span > {{imageRightHeaderPopup}}</span></div>
  </mat-dialog-actions>

  <mat-dialog-content>
      <div class="galleryContent pad-all-md-lg">
      <img class="mrgn-auto text-center captureImg" id="uploadedImg" src="#" alt="ovarlay_upload_img" />
      <canvas id="myImg" height="400px" width="600px" #canvasRef></canvas>
      <video id="myImgVideo" #hardwareVideo height="360px" width="600px"></video>
          <div class="cameraCaptureBtn" *ngIf="cancelTakePhoto==true" (click)="capture()">
              <a class="borderCircle text-center" mat-fab>
                  <i class="zmdi zmdi-camera"></i>
              </a>
          </div>
</div>
  </mat-dialog-content>

  <mat-dialog-actions class="bottomHead pad-all-md-lg"></mat-dialog-actions>
</div>`
})
export class webcamPopupComponent extends BaseComponent implements OnInit {

  data = this.dialogRef.componentInstance;
  imageUrl: any
  communityKey: any;
  file: any;
  textMessage: string;
  filename: string;
  fileToCompress: any;
  compressedFile: any
  rightTickTakePhoto: boolean = false;
  cancelTakePhoto: boolean = false;
  showSubmitBtn: boolean = false;
  // @ViewChild('hardwareVideo') hardwareVideo: any;
  // @ViewChild('canvasRef') canvasRef: any;
  base64String: any;
  uploadState: any;
  imageLeftHeaderPopup: string;
  imageRightHeaderPopup: string;


  @ViewChild("hardwareVideo")
  public video: ElementRef;

  @ViewChild("canvasRef")
  public canvas: ElementRef;

  public captures: Array<any>;
  @Output() onAdd = new EventEmitter<any>(true);

  constructor(public dialogRef: MatDialogRef<webcamPopupComponent>, public dialog: MatDialog,
    public router: Router, public loggerService: LoggerService,
    public toastr: ToastrService, @Inject(MAT_DIALOG_DATA) public cropData: any) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
    this.startwebcam();
  }

  startwebcam() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      this.cancelTakePhoto = false;
      navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
        this.video.nativeElement.src = window.URL.createObjectURL(stream);
        this.video.nativeElement.play();
        this.cancelTakePhoto = true;
      }, (err) => {
        console.log(err)
        this.toastr.error(err, 'Error!');
        console.log('The following error occured: ' + err);
        this.dialog.closeAll()
      });
    }
  }

  capture(): void {
    this.cancelTakePhoto = false;
    this.showSubmitBtn =true;
    var context = this.canvas.nativeElement.getContext("2d").drawImage(this.video.nativeElement, 0, 0, 640, 480);
    let canvas = this.canvas.nativeElement;
    let dataUrl = canvas.toDataURL('image/jpeg', 0.5);

    this.base64String = dataUrl.split(',').pop();
    document.getElementsByTagName('video')[0].style.display = "none";
    document.getElementById('myImgVideo').style.display = "none";
    document.getElementById("uploadedImg").setAttribute('src', dataUrl);
    document.getElementById("uploadedImg").style.display = 'block';
    this.video.nativeElement.style.display = "none";
    this.canvas.nativeElement.style.display = "none";

    let dialogRef = this.dialog.open(cropImageComponent, {
      data: {
        uploadedFile: dataUrl,
        case: 'register',
        using: 'webcam'
      }
    });

    const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {
      this.onAdd.emit(result);
    })

  }

  cancel() {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    // document.getElementsByTagName('video')[0].style.display = "none";
    this.video.nativeElement.style.display = "none";
  }
}

@Component({
  selector: 'app-crop-image-popup',
  template: `<div class="imageCropPopup">
<mat-dialog-actions class="topHead pad-all-md">
    <button matDialogClose class="closeBtn" >
        <i class="zmdi zmdi-close"></i>
    </button>
    <span> Crop Image</span>

    <button class="btn yellowTxtBtn" (click)="cropImage()" > <i class="zmdi zmdi-crop"></i> Crop </button>
</mat-dialog-actions>
<mat-dialog-content>
  <div class="imageCropContent pad-all-md">
  <ng-container *ngIf='showForWebcam'>
      <image-cropper
      [imageBase64]="imageBase64"
      [maintainAspectRatio]="true"
      [aspectRatio]="1 / 1"
      [resizeToWidth]="800"
      format="*"
      (imageCropped)="imageCropped($event)"
      (imageLoaded)="imageLoaded()"
      (loadImageFailed)="loadImageFailed()"></image-cropper>  
  </ng-container>
  <ng-container *ngIf='showForGallery'>
    <image-cropper
    [imageChangedEvent]="imageChangedEvent"
    [maintainAspectRatio]="true"
    [aspectRatio]="1 / 1"
    [resizeToWidth]="800"
    format="png"
    (imageCropped)="imageCropped($event)"
    (imageLoaded)="imageLoaded()"
    (loadImageFailed)="loadImageFailed()"></image-cropper>
  </ng-container>
  </div>
  <div class="cropBtn"></div>
</mat-dialog-content>
</div>`
})
export class cropImageComponent extends BaseComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  showForWebcam: boolean = false;
  showForGallery: boolean = false;
  imageBase64: any = '';

  @Output() onAdd = new EventEmitter<any>(true);

  constructor(public dialogRef: MatDialogRef<cropImageComponent>, public dialog: MatDialog,
    public router: Router, public loggerService: LoggerService,
    public toastr: ToastrService, @Inject(MAT_DIALOG_DATA) public cropData: any) {
    super(loggerService, router, toastr)
  }

  ngOnInit() {
    if (this.cropData.case == "register" && this.cropData.using == "webcam") {
      this.showForWebcam = true;
      this.imageBase64 = this.cropData.uploadedFile;
      this.showForGallery = false;
    }
    else if (this.cropData.case == "register" && this.cropData.using == "gallery") {
      this.showForGallery = true;
      this.showForWebcam = false;
      this.imageChangedEvent = this.cropData.uploadedFile;
    }
    else if (localStorage.getItem('currentPath') == '/create-community' || this.cropData.case == "editChannel") {
      this.showForGallery = true;
      this.showForWebcam = false;
      this.imageChangedEvent = this.cropData.uploadedFile;
    }
    else {
      console.log('else crop image');
    }
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }
  imageCropped(image: string) {
    this.croppedImage = image;

  }

  cropImage() {
    if (this.cropData.case == "register") {
      this.onAdd.emit(this.croppedImage);
      this.dialog.closeAll();
    }
    else if (localStorage.getItem('currentPath') == '/create-community' || this.cropData.case == "editChannel") {
      this.urltoFile(this.croppedImage, 'cropedImage.png', '').then((file) => {
        let cropData = {
          base64: this.croppedImage,
          fileObj: file
        }
        this.onAdd.emit(cropData);
        this.dialog.closeAll();
      })
    }
    else { }
  }

  urltoFile(url, filename, mimeType) {
    mimeType = mimeType || (url.match(/^data:([^;]+);/) || '')[1];
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }
  imageLoaded() {
    // show cropper
  }
  loadImageFailed() {
    // show message
  }



}
