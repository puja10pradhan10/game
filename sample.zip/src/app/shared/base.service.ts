import { Injectable } from '@angular/core';
import { Http, Response, RequestOptionsArgs, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { HttpErrorResponse } from '@angular/common/http';
import { LoaderStrings } from '@app/shared/base.constants';
import { LoggerService } from '@app/shared/logger/logger.service';
declare var $: any;
import { userDetails } from '@app/profile/profile-interface';


import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import ImageCompressor from 'image-compressor.js';

import { environment } from '@env/environment';
import 'rxjs/add/observable/of';
import { FileUpload } from '@app/community/community.entities';
import { fileUploadToS3 } from '@app/shared/base.constants';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class BaseService {
    timeInmillis: string;
    static fileObj: any;
    static thumbnailObj: any;
    static getSource: any;
    static fileToCompress: any;
    constructor(public loggerService: LoggerService, public _http: Http) {

    }

    public handleError(error: Response) {
        // this.loggerService.error(error);
        if (error['status'] == 0) {
            console.log('Please check your internet connectivity.')
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
        }
        if (error instanceof HttpErrorResponse) {
            console.log('There was an HTTP error.', (<HttpErrorResponse>error).status);
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
            // this.loggerService.error('There was an HTTP error.', error.message, 'Status code:', (<HttpErrorResponse>error).status);
        } else if (error instanceof TypeError) {
            console.log('There is a Type error.', error.message);
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
            // this.loggerService.error('There is a Type error.', error.message);
        } else if (error instanceof Error) {
            console.log('There is a general error.', error.message);
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
            // this.loggerService.error('There is a general error.', error.message);
        } else if (error instanceof ReferenceError) {
            console.log('There is a Reference error.', error.message);
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
            // this.loggerService.error('There is a Reference error.', error.message);
        } else {
            console.log('Nobody threw an error but something happened!', error);
            $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
            // this.loggerService.error('Nobody threw an error but something happened!', error);
        }
        return Observable.throw(error);

    }

    public getHeaderForAPICall(): RequestOptionsArgs {

        let options: RequestOptionsArgs = {};
        options.headers = new Headers();
        return options;
    }

    public showLoader(): void {
        $.LoadingOverlay(LoaderStrings.SHOW_LOADER, {
            image: "/assets/img/loader.gif",
        });
    }

    public hideLoader(): void {
        $.LoadingOverlay(LoaderStrings.HIDE_LOADER);
    }



    /**
  * Generate unique Id for messages
  */
    public generateMessageGuid() {
        let date = new Date();
        this.timeInmillis = date.getTime().toString();
        // return this.timeInmillis + '-' +
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            let r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);

            return v.toString(16);
        });
    }

    validateNotEmptyAndNull(name: string): any {
        if (name == "" || name == null || name.length == 0 || name == undefined) {
            return "";
        }
        return name;

    }


    uploadFile(observer) {
        let msgObj;
        let pathToSave;
        let body;
        if (BaseService.getSource == 'video') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))
            pathToSave = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.VIDEOS + '/' + msgObj.msgKey + '/' + msgObj.file;
            body = BaseService.fileObj;
        }
        else if (BaseService.getSource == 'thumbnail') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgThumbnailObject'))
            pathToSave = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.VIDEOS + '/' + msgObj.msgKey + '/' + fileUploadToS3.THUMBNAIL + '/' + msgObj.file;
            body = BaseService.thumbnailObj;
        } else if (BaseService.getSource == 'thumbnailImage') {

            msgObj = JSON.parse(localStorage.getItem('sendMsgThumbnailObject'))
            pathToSave = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.IMAGES + '/' + msgObj.msgKey + '/' + fileUploadToS3.THUMBNAIL + '/' + msgObj.file;
            body = BaseService.thumbnailObj;


        }
        else if (BaseService.getSource == 'audio') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))

            pathToSave = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.AUDIOS + '/' + msgObj.msgKey + '/' + msgObj.file;
            body = BaseService.fileObj;

        }
        else if (BaseService.getSource == 'chnlProfileImage') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))
            pathToSave = 'ChannelProfileImages/' + msgObj.chnlKey + '/' + msgObj.filename;
            body = BaseService.fileObj;
        }
        else if (BaseService.getSource == 'image') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))
            pathToSave = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.IMAGES + '/' + msgObj.msgKey + '/' + msgObj.file;
            body = BaseService.fileObj;

        } else { }
        const params = {
            Bucket: environment.awsConfig.BUCKET_NAME,
            Key: pathToSave,
            Body: body,
            ACL: 'public-read'
        };

        console.log(params)
        const bucket = new S3(
            {
                accessKeyId: environment.awsConfig.BUCKET_ACCESS_KEY_ID,
                secretAccessKey: environment.awsConfig.BUCKET_SECRET_ACCESS_KEY,
                region: environment.awsConfig.BUCKET_REGION
            });

        bucket.upload(params, function (err, data) {
            if (err) {
                return false;
            } else {
                observer.next(data);
                observer.complete();
            }
            return true;
        });
        return { unsubscribe(): any { } };
    }

    uploadedFileUrl: any
    getUplodedFileUrl(Observer) {
        let prefix;
        let msgObj;
        if (BaseService.getSource == 'video') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))
            prefix = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.VIDEOS + '/' + msgObj.msgKey + '/';
            BaseService.getSource = 'thumbnail';
        }
        else if (BaseService.getSource == 'thumbnail') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgThumbnailObject'))
            prefix = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.VIDEOS + '/' + msgObj.msgKey + '/' + fileUploadToS3.THUMBNAIL + '/';
        }
        else if (BaseService.getSource == 'chnlProfileImage') {
            prefix = 'ChannelProfileImages/' + localStorage.getItem('communityJabberId') + '/'
        }
        else if (BaseService.getSource == 'image') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))

            prefix = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.IMAGES + '/' + msgObj.msgKey + '/'
        }
        else if (BaseService.getSource == 'audio') {
            msgObj = JSON.parse(localStorage.getItem('sendMsgFileObject'))

            prefix = fileUploadToS3.CHANNEL_MEDIA + '/' + msgObj.chnlKey + '/' + fileUploadToS3.AUDIOS + '/' + msgObj.msgKey + '/'
        }
        else { }
        const params = {
            Bucket: environment.awsConfig.BUCKET_NAME,
            Prefix: prefix
        };
        const bucket = new S3(
            {
                accessKeyId: environment.awsConfig.BUCKET_ACCESS_KEY_ID,
                secretAccessKey: environment.awsConfig.BUCKET_SECRET_ACCESS_KEY,
                region: environment.awsConfig.BUCKET_REGION
            });

        bucket.listObjects(params, function (err, data) {
            if (err) {
                return false;
            }
            const fileDatas = data.Contents;
            fileDatas.forEach((file) => {
                this.uploadedFileUrl = environment.awsConfig.BUCKET_BASEURL + params.Bucket + '/' + file.Key;

            });
            Observer.next(this.uploadedFileUrl);
            Observer.complete();
        });
        return { unsubscribe(): any { } };
    }



    compressFile(Observer) {
        new ImageCompressor(BaseService.fileToCompress, {
            quality: .6,
            success(result) {
                Observer.next(result);
                Observer.complete();

            },
            error(e) {
                console.log(e)
            },

        });
    }


    generateMessagetime() {
        let date = new Date();
        return this.timeInmillis = date.getTime().toString();

    }

}