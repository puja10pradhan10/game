export class FacebookLoginStrings {
    static PHONE: string = 'PHONE'
    static GRANT_TYPE: string = 'grant_type';
    static CODE: string = 'code';
    static ACCESS_TOKEN: string = 'access_token';
    static PARTIALLY_AUTHENTICATED: string = 'PARTIALLY_AUTHENTICATED';
    static NOT_AUTHENTICATED: string = 'NOT_AUTHENTICATED';
    static BAD_PARAMS: string = 'BAD_PARAMS';
    static AUTHORIZATION_CODE: string = 'authorization_code';
    static AUTHENTICATION_TOKEN: string = 'AuthenticationToken';
    static USERNAME: string = 'username';
    static PASSWORD: string = 'password';
    static MIDDLEWARE_TOKEN: string = 'middleware_token';
    static USERID: string = 'userId';
}

export class VerifyUserStrings {
    static AUTH: string = 'auth';
    static VERIFY_USER: string = 'api-token-facebook-auth';
    static SOCIAL_AUTH: string = 'social-auth';
    static FACEBOOK: string = 'facebook'
}

export class Strings {
    static EMPTY = '';
    static NULL = null;
    static UNDEFINED = undefined;
    static CONTENT_TYPE = 'Content-Type';
    static APPLICATION_JSON = 'application/json';
    static CURRENT_PATH = 'currentPath';
    static NAVIGATE_FROM = 'navigateFrom';
    static REGISTRATION = 'registration';
    static REGISTRATION_CATEGORY_HEADER = "Interests - Select the areas of your interest";
    static CHANNEL_CATEGORY_HEADER = 'Select category - Maximum 3';
    static FILTER_POPUP = 'filterPopup';
    static FILTER_POPUP_HEADER = 'Filter Categories';
    static ADD_MORE_USER_PROFILE = 'addMoreUserProfile';
    static ADD_MORE_CHANNEL_PROFILE = 'addMoreChannelProfile';
    static Otp: string = "otp";
    static DISABLE_BACK: string = "disableBack";
    static DISABLE: String = "disable";
    static CREATE_CHANNEL = "create-channel";

}

export class HeaderString {
    static X_API_KEY = "X-API-KEY";
    static X_API_SECRET = "X-API-SECRET";
    static X_REQUEST_ID = "X-REQUEST-ID";
    static X_REQUEST_ID_VAL = "7985468765487";
    static AUTHORIZATION = "Authorization";
    static BEARER = "bearer ";
    static CONTENT_TYPE = 'Content-Type';
    static APPLICATION_JSON = 'application/json';
}

export class TranslateStrings {
    static TRANSLATE = 'Translate'
}

export class PassParamsToDrawer {
    static MENULIST = 'menuList';
    static SHOWUSERPROFILE = 'showUserProfile';
    static EDITUSERPROFILE = 'editUserProfile';
    static SHOWCHANNELPROFILE = 'showChannelProfile';
    static EDITCHANNELPROFILE = 'editChannelProfile';
    static CLOSEDRAWER = 'closeDrawer';
    static CLOSERIGHTDRAWER = 'closeRightDrawer';
    static SHOWFOLLOWERADMINCHAT = 'showFollowerAdminChat';
    static SHOWOTHERUSERPROFILE = 'showOtherUserProfile';
    static SHOWFOLLOWERPROFILEONWELCOME = 'showFollowerProfileOnWelcome';
    static SHOWFOLLOWERPROFILEONDISCOVER = 'showFollowerProfileOnDiscover';
    static SHOWFOLLOWERPROFILEONCHNL = 'showFollowerProfileOnChnl';
}
export class PopUpString {
    static GOT_IT = 'Got_It';
    static POP_UP = 'pop-up';
}

export class LoaderStrings {
    static SHOW_LOADER = 'show';
    static HIDE_LOADER = 'hide';
}

export class NavMenu {
    static MY_CHATS = 'My Chats';
    static MY_CONTACTS = 'My Contacts';
    static START_CHANNEL = 'Start Your Channel';
    static LANGUAGE = 'Language';
    static SETTINGS = 'Settings';
    static SUPPORT = 'Support';
    static LOGOUT = 'Logout';
}
export class connectionXmpp {
    static connection: any;
    // static boshUrl: string = "http://13.127.218.0:7070/http-bind/";
    static boshUrl: string = "https://kisan-test.m.in-app.io/http-bind/";
    static HOST: string = "@kisan-test.m.in-app.io";
}

export class UserStrings {
    static USER_DETAILS: string = 'userDetails';
    static LOGGEDIN_USER_DETAILS: any;
}

export class RegistrationStrings {
    static REGISTRATION_ID: string = "RegistrationId";
}
export class DefaultColor {
    static color: string = "#26B35A";
}

export class fileUploadToS3 {
    static CHANNEL_MEDIA: string = "ChannelMedia";
    static VIDEOS: string = 'videos';
    static THUMBNAIL: string = 'Thumbnail';
    static AUDIOS: string = 'audios';
    static IMAGES: string = 'images';
}


export class ApiUrl {
    static GET_MYCHAT_LIST: string = "users/current/mychats";
    static COMMUNITIES: string = "communities";
    static MESSAGES: string = "messages";
    static MEMBERS: string = "members";
    static URL_PARAMS: string = "?page_number=1&page_size=5&search_text=";
    static FOLLOWER_LIST_URL_PARAMS: string = "?page_size=100&page_number=1&search_text= &show-blocked= &show-all= &country= &state= &city= &userid= &show-removed=&CURRENT_TIMESTAMP="
    static DISCOVER_LIST_URL_PARAMS: string = '?page_number=1&page_size=1000&search_text=&user_field_value=&user_field_name=&filter_category_ids=&CURRENT_TIMESTAMP='
    static GET_BLOCKED_FOLLOWER_URL_PARAMS: string = "?page_size=100&page_number=1&search_text=s&show-blocked=true&show-all=&country=&state=&city=&userid=&show-removed=&CURRENT_TIMESTAMP="
    static GET_OLD_MESSAGES_URL_PARAMS: string = "?page_size=1000&page_number=1&userId=";
}

export class googleMapStrings {
    static MAP_URL: string = "https://www.google.com/maps/dir/?api=1&origin=";
    static DESTINATION: string = "&destination=";
}