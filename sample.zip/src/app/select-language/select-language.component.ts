import { Component } from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { LoggerService } from '@app/shared/logger/logger.service';

import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { OnInit, OnDestroy } from '@angular/core';

import { TranslateStrings, Strings } from '@app/shared/base.constants';

import { BaseComponent } from '@app/shared/base/base.component';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-select-language',
  templateUrl: './select-language.component.html'
})
export class SelectLanguageComponent extends BaseComponent implements OnInit {

  private subscription: Subscription;

  constructor(private translate: TranslateService, private activatedRoute: ActivatedRoute,
    public router: Router, public loggerService: LoggerService, public toastr : ToastrService) {
    super(loggerService, router, toastr)
    let browserLang;

    if (localStorage.getItem(TranslateStrings.TRANSLATE)) {
      browserLang = localStorage.getItem(TranslateStrings.TRANSLATE);
    } else {
      browserLang = translate.getBrowserLang();
      localStorage.setItem(TranslateStrings.TRANSLATE, browserLang)
    }
    translate.use(browserLang.match(/en|mr|hi/) ? browserLang : 'en');


  }

  changeLanguage(lang) {
    this.translate.use(lang);
    localStorage.setItem(TranslateStrings.TRANSLATE, lang)

    let state = localStorage.getItem(Strings.CURRENT_PATH);
    this.loggerService.info(state)

    if (state == Strings.NULL) {
      this.router.navigate(['login'])
    } else {
      this.router.navigate([state])
    }
  }

  ngOnInit() {

    this.disableBack()
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");
    // subscribe to router event
    this.subscription = this.activatedRoute.queryParams.subscribe(
      (param: any) => {
        let locale = param['locale'];
        if (locale !== undefined) {
          this.translate.use(locale);
        }
      });
  }

  ngOnDestroy() {
    // prevent memory leak by unsubscribing
    this.subscription.unsubscribe();
  }
}
