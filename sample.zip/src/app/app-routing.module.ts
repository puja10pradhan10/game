import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from "@app/auth-guard.service";

import { LoginComponent } from '@app/membership/login/login.component';
import { RegistrationComponent } from '@app/membership/registration/registration.component';
import { StateFiledComponent } from '@app/membership/registration/state-city/state-filed.component';
import { PageNotFoundComponent } from '@app/page-not-found/page-not-found.component';
import { SelectLanguageComponent } from '@app/select-language/select-language.component';
import { CreateCommunityComponent } from '@app/community/create/create-community/create-community.component';
import { SplashScreenComponent } from '@app/splash-screen.component';
import { CategoriesComponent } from '@app/shared/categories/categories.component';
import { WelcomeDashboardComponent } from '@app/dashboard/welcome-dashboard/welcome-dashboard.component';
import { CommunityInfoComponent } from '@app/community/create/community-info/community-info.component';
import { DiscoverChannelsComponent } from '@app/community/discover/discover-channels/discover-channels.component';
import { CsvComponent } from '@app/shared/invite/csv/csv.component';
import { InviteMemberListComponent } from '@app/shared/invite/invite-member-list/invite-member-list.component';
import { ManualInviteComponent } from '@app/shared/invite/manual-invite/manual-invite.component';
import { NavigationDrawerComponent } from '@app/profile/navigation-drawer/navigation-drawer.component';
import { ShowUserProfileComponent } from '@app/profile/user/show-user-profile/show-user-profile.component';
import { ShowFollowerProfileComponent } from '@app/profile/user/show-follower-profile/show-follower-profile.component';
import { EditUserProfileComponent } from '@app/profile/user/edit-user-profile/edit-user-profile.component';
import { EditChannelProfileComponent } from '@app/profile/channel/edit-channel-profile/edit-channel-profile.component';
import { ShowChannelProfileComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
import { MobileSplashComponent } from '@app/mobile-splash/mobile-splash.component';
import { AdminBroadcastMessagesComponent } from '@app/dashboard/channel-dashboard/admin-broadcast-messages/admin-broadcast-messages.component';
import { AdminFollowerChatComponent } from '@app/dashboard/channel-dashboard/admin-follower-chat/admin-follower-chat.component';
import { AdminBroadcastedMessagesComponent } from '@app/dashboard/welcome-dashboard/admin-broadcasted-messages/admin-broadcasted-messages.component';
import { FollowerAdminChatComponent } from '@app/dashboard/welcome-dashboard/follower-admin-chat/follower-admin-chat.component';
import { ChannelDashboardComponent } from '@app/dashboard/channel-dashboard/channel-dashboard.component';

const appRoutes: Routes = [
	{ path: '', component: SplashScreenComponent },
	{ path: 'login', component: LoginComponent },
	{ path: 'register', component: RegistrationComponent, canActivate: [AuthGuard] },
	{ path: 'statefiled', component: StateFiledComponent, canActivate: [AuthGuard] },
	{ path: 'select-language', component: SelectLanguageComponent },
	{ path: 'categories', component: CategoriesComponent, canActivate: [AuthGuard] },
	{ path: 'create-community', component: CreateCommunityComponent, canActivate: [AuthGuard] },
	{ path: 'channel-list', component: DiscoverChannelsComponent, canActivate: [AuthGuard] },
	{ path: 'community-info', component: CommunityInfoComponent, canActivate: [AuthGuard] },
	{
		path: 'welcome-dashboard', component: WelcomeDashboardComponent, canActivate: [AuthGuard],
		children: [
			{ path: 'main-navigation', component: NavigationDrawerComponent },
			{ path: 'showUser-profile', component: ShowUserProfileComponent },
			{ path: 'showFollower-profile', component: ShowFollowerProfileComponent },
			{ path: 'editUser-profile', component: EditUserProfileComponent },
			{ path: 'editChannel-profile', component: EditUserProfileComponent },
			{ path: 'showChannel-profile', component: ShowChannelProfileComponent },
			{ path: 'follower-admin-chat', component: FollowerAdminChatComponent, canActivate: [AuthGuard] },
			{ path: 'admin-broadcast', component: AdminBroadcastedMessagesComponent }
		]
	},
	{ path: 'follower-admin-chat', component: FollowerAdminChatComponent, canActivate: [AuthGuard] },
	{
		path: 'channel-dashboard', component: ChannelDashboardComponent, canActivate: [AuthGuard],
		children: [
			{ path: 'channel-admin-broadcast', component: AdminBroadcastMessagesComponent },
			{ path: 'admin-follower-chat', component: AdminFollowerChatComponent }
		]
	},
	{ path: 'invite', component: CsvComponent, canActivate: [AuthGuard] },
	{ path: 'invite-member-list', component: InviteMemberListComponent, canActivate: [AuthGuard] },
	{ path: 'manual-invite', component: ManualInviteComponent, canActivate: [AuthGuard] },
	{ path: 'mobile-splash', component: MobileSplashComponent, canActivate: [AuthGuard] },
	{ path: '**', component: PageNotFoundComponent, canActivate: [AuthGuard] }
];

@NgModule({
	imports: [RouterModule.forRoot(appRoutes)],
	exports: [RouterModule],

})
export class RoutingModule { }


