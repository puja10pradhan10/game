import { AfterViewInit, Inject, Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { UserStrings } from '@app/shared//base.constants'

@Component({
  selector: 'app-splash-screen',
  templateUrl: './splash-screen.component.html',
})
export class SplashScreenComponent implements OnInit {
  constructor(private router: Router) { }

 

  ngOnInit() {
    /* bg color change code */
     document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");

     if(localStorage.getItem(UserStrings.USER_DETAILS)){
       this.router.navigate(['welcome-dashboard'])
     }else{
     let timeoutId = setTimeout(() => {
      this.router.navigate(["select-language"]);
    }, 3000);
  }
  }

}