import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

import { BehaviorSubject, Observable } from "rxjs";
import { Strings, FacebookLoginStrings } from '@app/shared/base.constants'

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, public cookieService: CookieService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    localStorage.setItem(Strings.CURRENT_PATH, state.url)
    if (this.hasToken()) {
      return true;
    } else {
      this.router.navigate(['login'])
    }
  }

  isLoginSubject = new BehaviorSubject<boolean>(this.hasToken());


  private hasToken(): boolean {
    console.log('has token call')

    let cookieValue = this.cookieService.get(FacebookLoginStrings.AUTHENTICATION_TOKEN);

    if (localStorage.getItem('currentPath') == '/register' && cookieValue) {
      return true;
    } else {
      return !!cookieValue && !!localStorage.getItem('userDetails');
    }
  }


  isLoggedIn(): Observable<boolean> {

    return this.isLoginSubject.asObservable();
  }




}