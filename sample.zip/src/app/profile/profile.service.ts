import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { environment } from '@env/environment';

//Service
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { HeaderString, ApiUrl } from '@app/shared/base.constants';

import {
  ChannelsRemoveFollowerRequest, ChannelsRemoveFollowerResponse, DeleteCommunityRequest,
  DeleteCommunityResponse, LeaveCommunityRequest, LeaveCommunityResponse,
  GetFollowerListRequest, GetFollowerListResponse, UpdateChannelRequest, UpdateChannelResponse,
  GetFollowerDetailsResponse, BlockUnblockFollowerRequest, BlockUnblockFollowerResponse, GetChannelDetailsResponse
} from '@app/profile/profile.messages';

@Injectable()
export class ProfileService extends BaseService {
  userDetails: any = JSON.parse(localStorage.getItem('userDetails'));
  constructor(public http: Http,
    public loggerService: LoggerService) {
    super(loggerService, http)

  }

  getCommunityDetails(channelId): Observable<GetChannelDetailsResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    let currentTime = this.generateMessagetime();

    let getCommunityDetailsUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + channelId + '?CURRENT_TIMESTAMP=' + currentTime;

    return this._http.get(getCommunityDetailsUrl, options)
      .map((response: Response) => <GetChannelDetailsResponse>response.json())
      .do(data => this.loggerService.info('channel details Response: ' + data))
      .catch(this.handleError);
  }

  removeChannelFollower(request: ChannelsRemoveFollowerRequest): Observable<ChannelsRemoveFollowerResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append('Content-Type', 'application/json');
    let removeUserUrl = environment.jerseyConfig.API_BASE_URL + "xmpp_community/remove/";
    request.nodeJID = localStorage.getItem("channelKey")
    request.removeUserName = localStorage.getItem("FolowerName")
    request.nodeOwnerUserName = this.userDetails['username']
    request.appKey = environment.jerseyConfig.APP_KEY;;
    request.appSecret = environment.jerseyConfig.APP_SECRET;
    request.token = "hhh";
    request.resource = request.resource;

    this.loggerService.info('Remove follower from channel response :   ', JSON.stringify(request))

    return this._http.post(removeUserUrl, request, options)
      .map((response: Response) => <ChannelsRemoveFollowerResponse>response.json())
      .do(data => this.loggerService.info('Remove follower from channel response : ' + JSON.stringify(data)))
      .catch(this.handleError);
  }


  deleteCommunity(request: DeleteCommunityRequest): Observable<DeleteCommunityResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append('Content-Type', 'application/json');

    let deleteCommunityUrl = environment.jerseyConfig.API_BASE_URL + "communities/" + request.communityKey + '/';

    request.appKey = environment.jerseyConfig.APP_KEY;;
    request.appSecret = environment.jerseyConfig.APP_SECRET;
    request.token = "asd";
    request.resource = request.resource;
    request.userId = this.userDetails['user']['username'];
    request.communityKey = request.communityKey

    this.loggerService.info('delete channel request :   ', JSON.stringify(request))

    return this._http.post(deleteCommunityUrl, request, options)
      .map((response: Response) => <DeleteCommunityResponse>response.json())
      .do(data => this.loggerService.info('delete channel Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }


  leaveCommunity(request: LeaveCommunityRequest, chnlKey): Observable<LeaveCommunityResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    options.body = request;

    let leaveCommunityUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + chnlKey + '/members/' + this.userDetails.user.userId

    return this._http.delete(leaveCommunityUrl, options)
      .map((response: Response) => <LeaveCommunityResponse>response.json())
      .do(data => this.loggerService.info('leave channel Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  generateMessagetime() {
    let date = new Date();
    return this.timeInmillis = date.getTime().toString();

  }

  getChannelFollower(request: GetFollowerListRequest): Observable<GetFollowerListResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));

    let currentTime = this.generateMessagetime();

    let leaveCommunityUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + request.chnlKey + '/members' + ApiUrl.FOLLOWER_LIST_URL_PARAMS + currentTime

    return this._http.get(leaveCommunityUrl, options)
      .map((response: Response) => <GetFollowerListResponse>response.json())
      .do(data => this.loggerService.info('followers list Response: ' + data))
      .catch(this.handleError);
  }

  getBlockedFollowerList(request: GetFollowerListRequest): Observable<GetFollowerListResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));

    let currentTime = this.generateMessagetime();

    let leaveCommunityUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + request.chnlKey + '/members' + ApiUrl.GET_BLOCKED_FOLLOWER_URL_PARAMS + currentTime

    return this._http.get(leaveCommunityUrl, options)
      .map((response: Response) => <GetFollowerListResponse>response.json())
      .do(data => this.loggerService.info('blocked followers list Response: ' + data))
      .catch(this.handleError);
  }

  updateChannelProfile(request: UpdateChannelRequest): Observable<UpdateChannelResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));


    let updateCommunityUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + request.communityDetails.communityKey


    return this._http.put(updateCommunityUrl, request, options)
      .map((response: Response) => <UpdateChannelResponse>response.json())
      .do(data => this.loggerService.info('followers list Response: ' + data))
      .catch(this.handleError);
  }

  getFollowerDetails(followerId): Observable<GetFollowerDetailsResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    let currentTime = this.generateMessagetime();

    let getFollowerDetailsUrl = environment.oAuthConfig.API_BASE_URL + "users/12?field_value=" + followerId + "&field_name&accnt_type";
    //  + '?CURRENT_TIMESTAMP=' + currentTime

    return this._http.get(getFollowerDetailsUrl, options)
      .map((response: Response) => <GetFollowerDetailsResponse>response.json())
      .do(data => this.loggerService.info('followers list Response: ' + data))
      .catch(this.handleError);
  }


  blockUnblockFollower(request: BlockUnblockFollowerRequest, params): Observable<BlockUnblockFollowerResponse> {
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));
    options.body = request;

    let currentTime = this.generateMessagetime();

    let blockUnblockFollowerUrl = environment.oAuthConfig.API_BASE_URL + "communities/" + params.chnlKey + "/members/" + params.memberId;
    //  + '?CURRENT_TIMESTAMP=' + currentTime
   
    return this._http.delete(blockUnblockFollowerUrl, options)
      .map((response: Response) => <BlockUnblockFollowerResponse>response.json())
      .do(data => this.loggerService.info('block member Response: ' + data))
      .catch(this.handleError);
  }
}
