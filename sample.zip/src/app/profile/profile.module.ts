import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from "@angular/router";
import { SharedModule } from '@app/shared/shared.module';
import { BaseService } from '@app/shared/base.service';
import { ProfileService } from '@app/profile/profile.service';
import { LogoutPopUpComponent } from '@app/profile/navigation-drawer/navigation-drawer.component';
import { showChannelsYouFollowComponent } from '@app/profile/user/show-user-profile/show-user-profile.component';
import { CategoriesService } from '@app/shared/categories//categories.service'

import {
  BlockFollowerComponent, confirmDeletePopupComponent, confirmLeavePopupComponent, ViewAllFollowersComponent,
  confirmRemoveFolowerPopupComponent, showImgComponent, confirmOptionPopupComponent
} from '@app/profile/channel/show-channel-profile/show-channel-profile.component';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule

  ],
  declarations: [LogoutPopUpComponent, BlockFollowerComponent, confirmDeletePopupComponent, confirmLeavePopupComponent, confirmRemoveFolowerPopupComponent, showChannelsYouFollowComponent, ViewAllFollowersComponent, showImgComponent,confirmOptionPopupComponent],
  entryComponents: [LogoutPopUpComponent, BlockFollowerComponent, confirmDeletePopupComponent, confirmLeavePopupComponent, confirmRemoveFolowerPopupComponent, showChannelsYouFollowComponent, ViewAllFollowersComponent, showImgComponent, confirmOptionPopupComponent],
  providers: [BaseService, ProfileService, CategoriesService]
})
export class ProfileModule { }
