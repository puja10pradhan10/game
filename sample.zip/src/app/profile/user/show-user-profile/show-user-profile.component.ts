import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';

//Components
import { BaseComponent } from '@app/shared/base/base.component';
import{showImgComponent} from '@app/profile/channel/show-channel-profile/show-channel-profile.component';

//Service
import { CategoriesService } from '@app/shared/categories//categories.service'
import { LoggerService } from '@app/shared/logger/logger.service';
import { DashboardService } from '@app/dashboard/dashboard.service';

import { DiscoverInterface } from '@app/community/discover/discover-channels/discover-interface';
import { PassParamsToDrawer, DefaultColor } from '@app/shared/base.constants';
import { UserStrings } from '@app/shared/base.constants';
import { MyChatsListRequest, MyChatsListResponse } from '@app/dashboard/dashboard.messages'
import { ToastrService } from 'ngx-toastr';

declare var jQuery: any;
declare var $: any;

@Component({
    selector: 'app-show-user-profile',
    templateUrl: './show-user-profile.component.html'

})

export class ShowUserProfileComponent extends BaseComponent implements OnInit {
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    userDetails: any
    // @Input() followedChnlList: DiscoverInterface[];
    followedChnlList = [];
    mychatList = [];
    showBackBtn: boolean = false;
    userAreaOfInterest = [];
    getMychatListRequest = new MyChatsListRequest();
    showMyChatList: boolean;

    constructor(public loggerService: LoggerService,
        public dialog: MatDialog,
        public toastr: ToastrService,
        public router: Router, public categoriesService: CategoriesService, public dashboardService: DashboardService) {
        super(loggerService, router, toastr);

    }

    ngOnInit() {
        this.userDetails = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS))
        $(".tabOuter .mat-tab-header .mat-tab-label-active").css("color", "#26b35a !important");
        $(".tabOuter .mat-tab-header .mat-ink-bar").css("background-color", DefaultColor.color);

        this.getChannelsYouFollow()
        this.convertCategoriesIdToName();


        if (localStorage.getItem('closeDrawer') && localStorage.getItem('closeDrawer') == 'closeLeft') {
            this.showBackBtn = true;
        } else if (localStorage.getItem('closeDrawer') && localStorage.getItem('closeDrawer') == 'closeRight') {
            this.showBackBtn = false;
        }

    }

    length: number;
    getChannelsYouFollow() {
        this.dashboardService.getMyChatsList().subscribe(response => this.handleresponseOfGetMychatList(response),
            error => this.handleError(error));
    }

    handleresponseOfGetMychatList(response: MyChatsListResponse) {
        this.dashboardService.hideLoader()
        if (response.success == true) {
            if (response.myChats.length) {
                for (let ch = 0; ch < response.myChats.length; ch++) {
                    if (response.myChats[ch]['communitySubType'] != 'c_OneToOne') {
                        this.followedChnlList.push(response.myChats[ch])
                    }
                }
                this.length = this.followedChnlList.length;
                this.followedChnlList.sort(function (a, b) {
                    return b.createddatetime - a.createddatetime;
                });
                this.showMyChatList = true;
            } else {
                this.showMyChatList = false;
            }
        } else {
            this.dashboardService.hideLoader();
        }
    }

    convertCategoriesIdToName() {
        let areaOfInterest = this.userDetails.user.userProfile['interests'];
        this.categoriesService.getCategories().subscribe(categoriesList => {
            let data = [];
            for (let k = 0; k < categoriesList.length; k++) {
                if (!categoriesList[k]['is_occupation']) {
                    data.push(categoriesList[k])
                }
            }
            data.filter(response => {
                for (let i = 0; i < areaOfInterest.length; i++) {
                    if (response.id == areaOfInterest[i]) {
                        this.userAreaOfInterest.push({ 'name': response.name, 'image_url': response.imageUrl, 'id': response.id });
                    } else {
                        //this.loggerService.info('categories dont match')

                    }
                }
            });
            localStorage.setItem('userAreaOfIntrest', JSON.stringify(this.userAreaOfInterest))

        })

    }

    openDrawer(name: string): void {
        if (name == PassParamsToDrawer.MENULIST) {
            this.notify.emit(PassParamsToDrawer.MENULIST);
        } else if (name == PassParamsToDrawer.EDITUSERPROFILE) {
            this.notify.emit('closeRightDrawer');
            this.notify.emit(PassParamsToDrawer.EDITUSERPROFILE);
        }
    }

    closeDrawer() {
        if (localStorage.getItem('closeDrawer') == 'closeRight') {
            this.notify.emit('closeRightDrawer');
        } else {
            this.notify.emit('closeDrawer');
        }
    }

    showChannelsYouFollowPopup() {
        this.dialog.open(showChannelsYouFollowComponent);
    }

    userImagePopup(channelProfileImageUrl) {
        this.dialog.open(showImgComponent, {
            panelClass: 'my-full-screen-dialog',
            data: {
                imgSrc: channelProfileImageUrl
            }
        });
    }

}

@Component({
    selector: 'app-channels-follow-popup',
    template: `<div class="blockedFollower channelYouFollow maxWidthPopup">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn" >
          <i class="zmdi zmdi-close"></i>
      </button>
      <span> Channels You Follow</span>
  </mat-dialog-actions>
  <mat-dialog-content>
  <div class="forwardMsgContent pad-all-md">
  <ng-container *ngFor="let channel of followedChnlList">
    <mat-list *ngIf="channel.communitySubType != 'c_OneToOne'">
        <mat-list-item class="pad-tb-sm" >
            
            <img mat-list-avatar *ngIf="channel.communityImageUrl!=''" src="{{channel.communityImageUrl}}" onerror="this.style.display='none'" />
            <img  mat-list-avatar *ngIf="(!channel.communityImageUrl)" src="./assets/img/default_channel.png" />
            <h3 matLine class="font-bold-five">{{channel.communityName}}
            <span *ngIf="channel.ownerId == userDetails.user.userId"><mark class="yellowBck font-bold-three text-uppercase">Admin</mark></span>
            </h3>
            
        </mat-list-item>
            
    </mat-list>
  </ng-container>
  </div>
</mat-dialog-content>
</div>`
})
export class showChannelsYouFollowComponent extends BaseComponent implements OnInit {
    // @Input() followedChnlList: DiscoverInterface[];
    followedChnlList = [];
    getMychatListRequest = new MyChatsListRequest();
    showMyChatList: boolean;
    userDetails: any;

    constructor(public dialogRef: MatDialogRef<showChannelsYouFollowComponent>, public dialog: MatDialog,
        public dashboardService: DashboardService, public router: Router, public loggerService: LoggerService,
        public toastr: ToastrService) {
        super(loggerService, router, toastr)
    }
    ngOnInit() {
        this.userDetails = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS))
        
        this.dashboardService.getMyChatsList().subscribe(response => this.handleresponseOfGetMychatList(response),
            error => this.handleError(error));

    }
    handleresponseOfGetMychatList(response: MyChatsListResponse) {
        this.loggerService.info('response : ', response)
        if (response.success == true) {
            this.dashboardService.hideLoader()
            this.loggerService.info('response : ', response['myChats'])
            this.followedChnlList = response['myChats'];
            this.loggerService.info('mychat list array  : ', this.followedChnlList)
            if (!this.followedChnlList.length) {
                this.showMyChatList = true;
            } else {
                this.showMyChatList = false;
                this.followedChnlList.sort(function (a, b) {
                    return b.createddatetime - a.createddatetime;
                });
            }

        } else {
            this.dashboardService.hideLoader();
        }
    }
}
