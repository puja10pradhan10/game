import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { CategoriesComponent } from '@app/shared/categories/categories.component';
import { CategoriesService } from '@app/shared/categories//categories.service';
import { Strings } from '@app/shared/base.constants';
import { BaseComponent, cropImageComponent, webcamPopupComponent } from '@app/shared/base/base.component'
import { LoggerService } from '@app/shared/logger/logger.service';
import { userDetails } from '@app/profile/profile-interface';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { UpdateUserRequest, UpdateUserResponse } from '@app/membership/membership.messages';
import { MembershipService } from '@app/membership/membership.service';
import { ProfileService } from '@app/profile/profile.service';

@Component({
  selector: 'app-edit-user-profile',
  templateUrl: './edit-user-profile.component.html'
})
export class EditUserProfileComponent extends BaseComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  userDetails: any;
  firstName: string;
  lastName: string;
  about: any;
  userAreaOfInterest = [];
  @Input() categoriesData: any;
  updateUserRequest: UpdateUserRequest = new UpdateUserRequest();
  base64String: any;
  @ViewChild('hardwareVideo') hardwareVideo: any;
  rightTickTakePhoto: boolean = false;
  cancelTakePhoto: boolean = false;

  constructor(public dialog: MatDialog, public loggerService: LoggerService, public membershipService: MembershipService,
    public toastr: ToastrService, public router: Router, public categoriesService: CategoriesService, public profileService: ProfileService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'));
    this.firstName = this.userDetails['user']['firstName'];
    this.lastName = this.userDetails['user']['lastName'];
    this.about = this.userDetails['user']['userProfile']['about'];
    localStorage.setItem('chnlIntrestCat', this.userDetails.user.userProfile['interests']);
    this.convertCategoriesIdToName();
  }

  fileChangeEvent(fileInput: any) {

    let filename = fileInput.target.files[0]['name'];
    var reader = new FileReader();
    reader.readAsDataURL(fileInput.target.files[0]);
    reader.onload = (e: Event) => {
      let fileUrl = e.target['result'];
      //this.base64String = e.target['result'].split(',').pop();
      let index = filename.lastIndexOf(".");
      var strsubstring = filename.substring(index, filename.length);

      if (strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') {
        let dialogRef = this.dialog.open(cropImageComponent, {
          data: {
            uploadedFile: fileInput,
            case: 'register',
            using: 'gallery'
          }
        });
        const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {

          this.base64String = result.split(',').pop();
          document.getElementById("myImg").setAttribute('src', result);
          document.getElementsByTagName('canvas')[0].style.display = "none";
        })

      } else {
        this.toastr.error('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Error!');
        return false;
      }
    }
  }

  urltoFile(url, filename, mimeType) {
    mimeType = mimeType || (url.match(/^data:([^;]+);/) || '')[1];
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }

  startwebcam() {
    let dialogRef = this.dialog.open(webcamPopupComponent)
    const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {

      this.base64String = result.split(',').pop();
      document.getElementById("myImg").setAttribute('src', result);
      document.getElementsByTagName('canvas')[0].style.display = "none";
    })
  }

  cancel() {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    document.getElementsByTagName('video')[0].style.display = "none";
  }

  convertCategoriesIdToName() {
    let areaOfInterest;
    this.userAreaOfInterest = [];
    let temp = localStorage.getItem('chnlIntrestCat');
    areaOfInterest = temp.split(",");

    // localStorage.setItem('chnlIntrestCat', areaOfInterest)
    this.categoriesService.getCategories().subscribe(categoriesList => {

      let data = [];
      for (let k = 0; k < categoriesList.length; k++) {
        if (!categoriesList[k]['is_occupation']) {
          data.push(categoriesList[k])
        }
      }
      data.filter(response => {
        for (let i = 0; i < areaOfInterest.length; i++) {
          if (response.id == areaOfInterest[i]) {
            this.userAreaOfInterest.push({ 'name': response.name, 'image_url': response.image_url, 'id': response.id });
          } else {
            this.loggerService.info('categories dont match')

          }
        }
      });
      localStorage.setItem('userAreaOfIntrest', JSON.stringify(this.userAreaOfInterest))

    })
  }


  removeIntrest(id) {
    for (let s = 0; s < this.userAreaOfInterest.length; s++) {
      if (this.userAreaOfInterest[s]['id'] == id) {
        this.userAreaOfInterest.splice(s, 1);
        document.getElementById(id).style.display = 'none';
        return true;
      }
    }
  }

  closeDrawer() {
    this.notify.emit('closeDrawer');
    localStorage.removeItem('chnlIntrestCat')
  }
  openFilterDialog(value) {
    this.getUpdatedUserIntrest();
    localStorage.setItem(Strings.NAVIGATE_FROM, Strings.ADD_MORE_USER_PROFILE)
    let dialogRef = this.dialog.open(CategoriesComponent, {
      panelClass: 'my-full-screen-dialog',
      data: { id: value }
    });
    const sub = dialogRef.componentInstance.onAdd.subscribe((data) => {
      localStorage.setItem('chnlIntrestCat', data);
      this.convertCategoriesIdToName();
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  getUpdatedUserIntrest() {
    let arr = [];
    for (let k = 0; k < this.userAreaOfInterest.length; k++) {
      arr.push(this.userAreaOfInterest[k]['id'])
    }
    localStorage.setItem('chnlIntrestCat', arr.join())
  }

  updateUserProfile() {
    this.membershipService.showLoader();
    if (this.userAreaOfInterest.length) {
      this.getUpdatedUserIntrest();
    } else {
      this.membershipService.hideLoader();
      this.toastr.info('Please select atleast one intrest', 'Info !!')
      return false;
    }
    if (this.firstName == "" || this.firstName == undefined) {
      this.membershipService.hideLoader();
      this.toastr.info('Please enter first name', 'Info !!')
      return false;
    }
    if (this.lastName == "" || this.lastName == undefined) {
      this.membershipService.hideLoader();
      this.toastr.info('Please enter last name', 'Info !!')
      return false;
    }
    this.updateUserRequest.categories = localStorage.getItem('chnlIntrestCat');
    this.updateUserRequest.firstName = this.firstName;
    this.updateUserRequest.lastName = this.lastName;
    this.updateUserRequest.about = this.about;

    if (this.userDetails.user.userProfile.mobile1 == "") {
      this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile2;
    } else {
      this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile1;
    }

    if (this.base64String == "" || this.base64String == undefined) {
      this.updateUserRequest.image_url = this.userDetails.user.userProfile.imageUrl;
      this.updateUserRequest.small_thumb_url = this.userDetails.user.userProfile.imageSmallthumbUrl;
      this.updateUserRequest.big_thumb_url = this.userDetails.user.userProfile.imageBigthumbUrl;
    } else {
      this.updateUserRequest.imageBlob = this.base64String;
    }

    this.updateUserRequest.city = this.userDetails.user.userProfile.city;
    this.updateUserRequest.accountType = this.userDetails.user.userProfile.accountType;
    this.updateUserRequest.country = this.userDetails.user.userProfile.country;
    this.updateUserRequest.email = this.userDetails.user.email;
    this.updateUserRequest.oAuthToken = this.userDetails.oAuthToken;
    this.updateUserRequest.password = this.userDetails.user.userId;
    this.updateUserRequest.state = this.userDetails.user.userProfile.state;

    this.membershipService.updateUserAreaOfInterest('', this.updateUserRequest)
      .subscribe(response => this.handleResponseOfUpdateUserProfile(response),
        error => this.handleError(error)
      )
  }

  handleResponseOfUpdateUserProfile(response: UpdateUserResponse) {
    let currentTime = this.profileService.generateMessagetime();
    this.membershipService.hideLoader();
    this.toastr.success("User Profile Updated Successfully", 'Success !!')
    let setUserDetails = {
      "httpStatusCode": this.userDetails.httpStatusCode,
      "message": this.userDetails.message,
      "requestId": this.userDetails.requestId,
      "responseCode": this.userDetails.responseCode,
      "success": this.userDetails.success,
      "timeInMillis": this.userDetails.timeInMillis,
      "recordsAffected": this.userDetails.recordsAffected,
      "country": this.userDetails.country,
      "middlewareToken": this.userDetails.middlewareToken,
      "oAuthToken": this.userDetails.oAuthToken,
      "registrationToken": this.userDetails.registrationToken,
      "responseCodeFromOAuth": this.userDetails.responseCodeFromOAuth,
      "user": {
        "email": response.data.email,
        "firstName": response.data.firstName,
        "lastName": response.data.lastName,
        "sessionId": this.userDetails.user.sessionId,
        "userId": this.userDetails.user.userId,
        "userProfile": {
          "about": response.data.userProfile.about,
          "accountType": response.data.userProfile.accountType,
          "city": response.data.userProfile.city,
          "country": response.data.userProfile.country,
          "imageBigthumbUrl": response.data.userProfile.imageBigthumbUrl + '?timestamp=' + currentTime,
          "imageSmallthumbUrl": response.data.userProfile.imageSmallthumbUrl + '?timestamp=' + currentTime,
          "imageUrl": response.data.userProfile.imageUrl + '?timestamp=' + currentTime,
          "interestOther": response.data.userProfile.interestOther,
          "interests": response.data.userProfile.interests,
          "isEmailVerified": response.data.userProfile.isEmailVerified,
          "isMobileVerified": response.data.userProfile.isMobileVerified,
          "mobile1": response.data.userProfile.mobile1,
          "mobile2": response.data.userProfile.mobile2,
          "pin": response.data.userProfile.pin,
          "state": response.data.userProfile.state,
          "visitedKisan": response.data.userProfile.visitedKisan
        },
        "username": response.data.username
      }
    }
    localStorage.setItem('userDetails', JSON.stringify(setUserDetails));
    this.notify.emit('closeDrawer');
  }
}
