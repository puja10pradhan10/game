import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material';

//Components
import { BaseComponent } from '@app/shared/base/base.component';
import { showImgComponent } from '@app/profile/channel/show-channel-profile/show-channel-profile.component';

//Service
import { CategoriesService } from '@app/shared/categories/categories.service'
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';
import { DashboardService } from '@app/dashboard/dashboard.service';
import { CommonChannelResponse } from '@app/dashboard/dashboard.messages';
import { GetChannelDetailsResponse } from '@app/profile/profile.messages';
import { ProfileService } from '@app/profile/profile.service';

declare var jQuery: any;
declare var $: any;
import { GetFollowerDetailsResponse } from '@app/profile/profile.messages';

@Component({
    selector: 'app-show-follower-profile',
    templateUrl: './show-follower-profile.component.html'

})

export class ShowFollowerProfileComponent extends BaseComponent implements OnInit {

    followerDetails: any;
    followerAreaOfInterest = [];
    commonChnlList: any;
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    showfollowerProfile: boolean;

    constructor(public loggerService: LoggerService,
        public categoriesService: CategoriesService,
        public toastr: ToastrService, public dashboardService: DashboardService,
        public router: Router, public dialog: MatDialog, public profileService: ProfileService) {
        super(loggerService, router, toastr);

    }

    ngOnInit() {


        if (localStorage.getItem('ChatList') && localStorage.getItem('ChatList') == 'OneOnOne' &&
            localStorage.getItem('currentPath') == '/channel-dashboard' && localStorage.getItem('Selectedfollower')) {
            let tempData = JSON.parse(localStorage.getItem('Selectedfollower'));

            this.profileService.getFollowerDetails(tempData.userId).subscribe(res => this.handleresponseOfGetFollowerDetails(res),
                error => this.handleError(error));
            //     let tempArr = JSON.parse(localStorage.getItem('Selectedfollower'));
            //     this.followerDetails = JSON.parse(localStorage.getItem('followerDetails'))
            //     this.followerDetails.bigThumbUrl = tempArr.communityImageBigThumbUrl;
            //     this.followerDetails.smallThumbUrl = tempArr.communityImageSmallThumbUrl;
            //     this.followerDetails.imageUrl = tempArr.communityImageUrl;
            //     this.followerDetails.jabber_id = tempArr.communityJabberId;
            //     this.followerDetails.firstName = tempArr.communityName;
            //     this.followerDetails.lastName = tempArr.lastName;
        } else {

            this.followerDetails = JSON.parse(localStorage.getItem('followerDetails'));
            this.profileService.getFollowerDetails(this.followerDetails.userId).subscribe(res => this.handleresponseOfGetFollowerDetails(res),
                error => this.handleError(error));
        }
        // console.log(this.followerDetails);

        // this.followerDetails = JSON.parse(localStorage.getItem('followerDetails'));
        // this.convertCategoriesIdToName();
        // this.getCommonChannels();
    }

    handleresponseOfGetFollowerDetails(res: GetFollowerDetailsResponse) {
        if (res.success) {
            this.followerDetails = res.usersDB;
            this.showfollowerProfile = true;
            this.convertCategoriesIdToName();
            this.getCommonChannels();
        } else {
            this.toastr.info("Error to get follower details.", "Info")
        }
    }

    convertCategoriesIdToName() {
        this.followerAreaOfInterest = [];
        let areaOfInterest = this.followerDetails.categories;
        let followerIntrest = areaOfInterest.split(",")
        this.categoriesService.getCategories().subscribe(categoriesList => {
            let data = [];
            for (let k = 0; k < categoriesList.length; k++) {
                if (!categoriesList[k]['is_occupation']) {
                    data.push(categoriesList[k])
                }
            }
            data.filter(response => {
                for (let i = 0; i < followerIntrest.length; i++) {
                    if (response.id == followerIntrest[i]) {
                        this.followerAreaOfInterest.push({ 'name': response.name, 'image_url': response.imageUrl, 'id': response.id });
                    } else {
                        //this.loggerService.info('categories dont match')

                    }
                }
            });
            //localStorage.setItem('userAreaOfIntrest', JSON.stringify(this.followerAreaOfInterest))
            this.loggerService.info(this.followerAreaOfInterest)
        })

    }

    length: number;
    getCommonChannels() {
        this.dashboardService.getCommonChannels(this.followerDetails.id).subscribe(response => this.handleresponseOfGetMychatList(response),
            error => this.handleError(error));
    }

    handleresponseOfGetMychatList(response: CommonChannelResponse) {

        this.dashboardService.hideLoader()
        if (response.success == true && response.communities.length) {

            this.commonChnlList = response.communities;
            this.length = this.commonChnlList.length;
        } else {
            this.loggerService.info('Error to get common channels');
        }
    }

    closeDrawer() {
        if (localStorage.getItem('closeDrawer') == 'closeRight') {
            this.notify.emit('closeRightDrawer');
        } else {
            this.notify.emit('closeDrawer');
        }
    }

    userImagePopup(channelProfileImageUrl) {
        this.dialog.open(showImgComponent, {
            panelClass: 'my-full-screen-dialog',
            data: {
                imgSrc: channelProfileImageUrl
            }
        });
    }

    myChatChannelDashboard(chnlDetails) {
        this.profileService.showLoader();
        this.profileService.getCommunityDetails(chnlDetails.communityKey).subscribe(result => this.handleresponseOfGetCommunityDetails(result),
            error => this.handleError(error));
    }

    handleresponseOfGetCommunityDetails(result: GetChannelDetailsResponse) {
        this.profileService.hideLoader();
        if (result.success) {
            let chnlDetails = result.communityDetails;
            localStorage.setItem('createCommunityData', JSON.stringify(result.communityDetails))

            let userData = JSON.parse(localStorage.getItem('userDetails'))
            if (chnlDetails.ownerId == userData.user.userId) {

                if (localStorage.getItem('currentPath') == '/channel-dashboard') {
                    window.location.reload();
                } else {
                    this.router.navigate(['/channel-dashboard'])
                }
            } else {
                if (localStorage.getItem('currentPath') == '/welcome-dashboard') {
                    this.notify.emit('setDashboard');
                } else {
                    this.router.navigate(['/welcome-dashboard'])
                }
            }
        }
    }

}
