import { Component, OnInit, Output, EventEmitter, Inject } from '@angular/core';
import { Router } from "@angular/router";
import { TranslateService } from 'ng2-translate';
import { BehaviorSubject, Observable } from "rxjs";
import { FacebookLoginStrings, UserStrings, NavMenu } from '@app/shared/base.constants';
import { MatDialog, MatDialogRef } from '@angular/material';
import { BaseComponent } from '@app/shared/base/base.component'
import { LoggerService } from '@app/shared/logger/logger.service';
import { userDetails } from '@app/profile/profile-interface';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-navigation-drawer',
  templateUrl: './navigation-drawer.component.html'
})
export class NavigationDrawerComponent extends BaseComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  isLoginSubject = new BehaviorSubject<boolean>(this.hasToken());
  navMenu: any;
  userDetails: any;

  constructor(public router: Router, private translate: TranslateService,
    public dialog: MatDialog, public loggerService: LoggerService, public toastr: ToastrService
  ) { super(loggerService, router, toastr); }

  ngOnInit() {
    this.navMenu =
      {
        MY_CHATS: NavMenu.MY_CHATS,
        MY_CONTACTS: NavMenu.MY_CONTACTS,
        START_CHANNEL: NavMenu.START_CHANNEL,
        LANGUAGE: NavMenu.LANGUAGE,
        SETTINGS: NavMenu.SETTINGS,
        SUPPORT: NavMenu.SUPPORT,
        LOGOUT: NavMenu.LOGOUT,
      }
    this.userDetails = UserStrings.LOGGEDIN_USER_DETAILS = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS));
  }

  openDrawer() {
    this.notify.emit('showUserProfile');
  }

  closeDrawer() {
    this.notify.emit('myChatReset');
    // this.notify.emit('closeDrawer');
  }

  logout(): void {
    let dialogRef = this.dialog.open(LogoutPopUpComponent)
  }

  createChannel() {
    localStorage.removeItem('createCommunityData');
    this.router.navigate(['/create-community'])
  }

  private hasToken(): boolean {
    return !!localStorage.getItem(FacebookLoginStrings.AUTHENTICATION_TOKEN);
  }

}


@Component({
  selector: 'app-logout-popup',
  template: `<div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Are you sure you want to logout? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack"  mat-dialog-close> No</button>
    <button type="submit" class="btnPopup btnRed" (click)="yesClick()"> Yes</button>
  </mat-dialog-actions>
  </div>`,
})

export class LogoutPopUpComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<LogoutPopUpComponent>, public dialog: MatDialog
    , private router: Router) { }

  ngOnInit() {
  }

  yesClick() {

    localStorage.clear();
    this.dialog.closeAll();
    this.router.navigate(['select-language'])
  }
}