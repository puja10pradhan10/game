import { Component, OnInit, Output, EventEmitter, Input, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
//Service
import { CategoriesService } from '@app/shared/categories//categories.service'
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';
import { ProfileService } from '@app/profile/profile.service';

import { BaseComponent } from '@app/shared/base/base.component';
//import { DiscoverChannelsComponent } from '@app/community/discover/discover-channels/discover-channels.component';

import { FollowerListInterface } from '@app/dashboard/dashboard-interface';
import { PassParamsToDrawer, connectionXmpp } from '@app/shared/base.constants';
import { UserStrings, Strings } from '@app/shared/base.constants';
import { GetFollowerListRequest, GetFollowerListResponse } from '@app/profile/profile.messages';
import {
    ChannelsRemoveFollowerRequest, ChannelsRemoveFollowerResponse, DeleteCommunityRequest,
    DeleteCommunityResponse, LeaveCommunityRequest, LeaveCommunityResponse,
    BlockUnblockFollowerRequest, BlockUnblockFollowerResponse, GetChannelDetailsResponse
} from '@app/profile/profile.messages';

declare var jQuery: any;
declare var $: any;


@Component({
    selector: 'app-show-channel-profile',
    templateUrl: './show-channel-profile.component.html'
})
export class ShowChannelProfileComponent extends BaseComponent implements OnInit {
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    userName: string;
    loggedInuserId: any;
    chnlData: any;
    chnlFollowers: number;
    chnlAbout: string;
    channelName: string;
    channelKey: string;
    channelColor: string;
    currentPath: string;
    chnlCategories = [];
    channelProfileImageUrl: string
    @Input() followerList: any;
    followerListService: any;
    closeBtnDrawer: string = 'closeLeft';
    @Input() clickedChnlDetails: any;
    userDetails: any;
    showBtns: boolean = false;
    showViewAll: boolean = false;
    leaveCommunityRequest = new LeaveCommunityRequest();
    getFollowerRequest = new GetFollowerListRequest();
    blockUnblockFollowerRequest = new BlockUnblockFollowerRequest();
    blockUnblockFollowerResponse = new BlockUnblockFollowerResponse();
    showMuteBtn:boolean=false;

    @Input() showChnlProfile: any;
    showFollowerOptionPopup: boolean = false;
    currentTime: any;

    constructor(public router: Router, public dialog: MatDialog, public loggerService: LoggerService,
        public categoriesService: CategoriesService, public toastr: ToastrService,
        public profileService: ProfileService) {
        super(loggerService, router, toastr)
    }

    ngOnChanges(): void {
    }

    ngOnInit() {
        this.currentPath = localStorage.getItem(Strings.CURRENT_PATH)
        this.userDetails = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS));
        this.chnlData = JSON.parse(localStorage.getItem('createCommunityData'));
        this.userName = this.chnlData.ownerId;
        this.loggedInuserId = this.userDetails['user']['userId'];

        if (BaseComponent.onlineOffline) {
            this.channelDetails();
            this.getFollowers();
            this.changeCategoryIdToName();
        } else {
            this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
        }

        if (this.currentPath == "/channel-list") {
            //this.changeCategoryIdToName()
        } else if (this.currentPath == "/channel-dashboard") {
            localStorage.setItem('closeDrawer', 'closeLeft')
            // this.changeCategoryIdToName()
        } else { }
    }

    setChnlDashboardStyles() {
        let styles;
        styles = {
            'background': this.chnlData.communityDominantColour + " ! important",
        }
        return styles;
    }

    messageBroadcast() {
        if (localStorage.getItem('currentPath') == '/channel-list') {
            this.router.navigate(["channel-dashboard"])
        } else if (localStorage.getItem('currentPath') == '/channel-dashboard') {
            this.channelDetails();
            this.notify.emit(PassParamsToDrawer.CLOSEDRAWER);
        }
    }

    enlargeImg: string;
    channelDetails() {
        //alert('show chnl details')
        this.currentPath = localStorage.getItem(Strings.CURRENT_PATH)
        this.profileService.showLoader();

        this.profileService.getCommunityDetails(this.chnlData.communityKey).subscribe(result => this.handleresponseOfGetCommunityDetails(result),
            error => this.handleError(error));
    }

    handleresponseOfGetCommunityDetails(result: GetChannelDetailsResponse) {

        this.profileService.hideLoader();
        if (result.success) {
            this.chnlData = result.communityDetails;
            localStorage.setItem('createCommunityData', JSON.stringify(result.communityDetails))
            this.channelKey = this.chnlData.communityKey;
            this.channelColor = this.chnlData.communityDominantColour;
            // mat-ink-bar.mat-ink-bar
            this.currentTime = this.profileService.generateMessagetime();
            this.channelName = this.chnlData.communityName;
            this.channelProfileImageUrl = this.categoriesService.validateNotEmptyAndNull(this.chnlData.communityImageBigThumbUrl)
            this.enlargeImg = this.chnlData.communityImageBigThumbUrl + '?timestamp=' + this.currentTime;
            $("h3.greenTxt.font-bold-four.mrgn-b-none.mat-line").css("color", this.chnlData.communityDominantColour);
            $(".tabOuter .mat-tab-header .mat-tab-label-active").css("color", this.chnlData.communityDominantColour + " !important");

            $(".usergroup .profile_heading").css("background", this.chnlData.communityDominantColour + " !important");
            $(".tabOuter .mat-tab-header .mat-ink-bar").css("background-color", this.chnlData.communityDominantColour);
            $(".minimumFive a").css("color", this.chnlData.communityDominantColour + " !important");


            if (this.chnlData.isMember) {
                $("#showleaveChannel").show();
                // document.getElementById('showleaveChannel').style.display="block";
            } else {
                $("#showleaveChannel").hide();
                // document.getElementById('showleaveChannel').style.display="none";
            }

            if (this.currentPath == "/channel-dashboard") {
                this.chnlFollowers = this.chnlData.follower;
                this.chnlAbout = this.chnlData.communityDesc;
                this.showBtns = true;
                this.showFollowerOptionPopup = true;
                this.showMuteBtn=false;
            }
            else {
                this.showFollowerOptionPopup = false;
                this.chnlAbout = this.chnlData.communityDesc;
                if (this.userDetails['user']['userId'] == this.chnlData.ownerId) {
                    this.showBtns = true;
                    this.showMuteBtn=false;
                } else {
                    this.showBtns = false;
                    this.showMuteBtn=true;
                }
            }
        }
    }

    changeCategoryIdToName(): void {
        this.chnlCategories = [];
        let areaOfInterest = this.chnlData.communityCategories
        let areaOfInterestArray = areaOfInterest.split(',');
        this.categoriesService.getCategories().subscribe(categoriesList => {
            let data = [];
            for (let k = 0; k < categoriesList.length; k++) {
                if (!categoriesList[k]['is_occupation']) {
                    data.push(categoriesList[k])
                }
            }
            data.filter(response => {
                for (let i = 0; i < areaOfInterestArray.length; i++) {
                    if (response.id == areaOfInterestArray[i]) {
                        this.chnlCategories.push({ 'name': response.name, 'image_url': response.image_url, 'id': response.id });
                    } else {
                        this.loggerService.info('categories dont match')
                    }
                }
            });
        })
    }


    getFollowers() {
        this.profileService.showLoader();
        this.getFollowerRequest.chnlKey = this.chnlData.communityKey;

        this.profileService.getChannelFollower(this.getFollowerRequest).subscribe(result => this.handleresponseOfGetFollowersList(result),
            error => this.handleError(error));

    }

    handleresponseOfGetFollowersList(response: GetFollowerListResponse) {
        //this.profileService.hideLoader();
        this.followerListService = response.communityMembersList;
        if (this.followerListService.length > 5) {
            this.showViewAll = true;
            this.profileService.hideLoader()

        } else {
            this.showViewAll = false;
            this.profileService.hideLoader()

        }
    }


    leaveChannel() {
        // let dialogRef = this.dialog.open(confirmLeavePopupComponent);
        // dialogRef.afterClosed().subscribe(() => {
        //     this.notify.emit('closeRightDrawer');
        // });

        if ((this.userDetails.user.userId == this.chnlData.ownerId) && this.chnlData.isMember) {
            this.toastr.info('Owner Cannot leave channel', 'Info !!');
        }
        else {
            let dialogRef = this.dialog.open(confirmLeavePopupComponent, {
                data: {
                    communityJabberId: this.chnlData.communityJabberId,
                    chnlKey: this.chnlData.communityKey,
                    new_admin_user_id: "",
                    ownerId: this.chnlData.ownerId,
                    isMember: this.chnlData.isMember,
                    userId: this.userDetails.user.userId
                }

            });

            const sub = dialogRef.componentInstance.onAdd.subscribe((data) => {
                sub.unsubscribe();
                if (data == 'successleave') {
                    this.notify.emit('successleave');
                }
            });
            // dialogRef.afterClosed().subscribe(() => {
            //     sub.unsubscribe();
            // });
            localStorage.setItem("channelName", this.channelName)
        }

    }


    viewFollowerprofile(followerDetails) {
        localStorage.removeItem('Selectedfollower')
        localStorage.setItem('followerDetails', JSON.stringify(followerDetails));
        if (this.userDetails.user.userId == followerDetails.id) {
            this.notify.emit(PassParamsToDrawer.SHOWUSERPROFILE)
        } else {
            if (localStorage.getItem('currentPath') == '/channel-dashboard') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONCHNL)
            }
            else if (localStorage.getItem('currentPath') == '/channel-list') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONDISCOVER)
            }
            else if (localStorage.getItem('currentPath') == '/welcome-dashboard') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONWELCOME)
            } else {
                this.notify.emit(PassParamsToDrawer.SHOWOTHERUSERPROFILE)
            }
        }
    }

    blockRemoveFollower(details, operation) {
        let memberData = {
            memberId: details.userId,
            chnlKey: this.chnlData.communityKey
        }

        let dialogRef = this.dialog.open(confirmOptionPopupComponent);
        dialogRef.componentInstance.state = operation;
        dialogRef.componentInstance.details = memberData;
        dialogRef.componentInstance.onAdd.subscribe((res) => {
            if (res == 'success') {
                this.getFollowers();
            } else {
                console.log('cancel')
            }
        });
    }

    RemoveFollower(follow) {
        // let global = this;
        localStorage.setItem("channelKey", this.channelKey)
        localStorage.setItem("FolowerName", follow)
        let dialogRef = this.dialog.open(confirmRemoveFolowerPopupComponent);
        dialogRef.afterClosed().subscribe(() => {
            // this.notify.emit('closeDrawer');
            setTimeout(() => {
                this.getFollowers();
            }, 7000)

        });
        localStorage.setItem("channelName", this.channelName)
        this.profileService.hideLoader()

    }

    deleteChannel() {
        let dialogRef = this.dialog.open(confirmDeletePopupComponent);
        dialogRef.afterClosed().subscribe(() => {
            this.notify.emit('closeRightDrawer');
        });
        localStorage.setItem("channelName", this.channelName)
    }

    clickedFollow() {
        this.notify.emit("followChannel");
        this.closeDrawer();
    }

    openDrawer(name: string): void {
        localStorage.setItem('closeDrawer', 'closeRight')
        this.notify.emit(PassParamsToDrawer.EDITCHANNELPROFILE);

    }
    closeDrawer() {
        if (localStorage.getItem('closeDrawer') == 'closeRight') {
            this.notify.emit('closeRightDrawer');
        } else {
            this.notify.emit('closeDrawer');
        }
    }
    openDialogblockFollowers() {
        this.dialog.open(BlockFollowerComponent);
        if (this.currentPath == "/channel-list") {
            this.notify.emit('closeRightDrawer');
        } else if (this.currentPath == "/channel-dashboard") {
            this.notify.emit('closeDrawer');
        } else { }
    }

    showChannelsYouFollowPopup() {
        this.dialog.open(ViewAllFollowersComponent);
    }
    channelImagePopup(channelProfileImageUrl) {
        this.dialog.open(showImgComponent, {
            panelClass: 'my-full-screen-dialog',
            data: {
                imgSrc: channelProfileImageUrl
            }
        });
    }


}


@Component({
    selector: 'app-block-follwer',
    template: `
  <div class="forwardMsgPopup blockedFollower">
    <mat-dialog-actions class="topHead pad-all-md">
        <button matDialogClose class="closeBtn">
            <i class="zmdi zmdi-close"></i>
        </button>
        <span> Blocked Members</span>
    </mat-dialog-actions>
    <mat-dialog-content>
        <div class="forwardMsgContent pad-all-md-lg">
            <mat-list class="mat-pad-none mrgn-none" *ngFor="let user of communityMembersList">
                <ng-container >
                <mat-list-item class="mrgn-b-sm">
                    <img matListAvatar src="{{user.imageUrl}}" />
                    <h4 class="font-bold-five mrgn-l-md mrgn-b-none widthfull">{{user.firstName}} {{user.lastName}}</h4>
                    <p (click)="unblockMember(user)">Unblock</p>
                </mat-list-item>
                </ng-container>
            </mat-list>
        </div>
    </mat-dialog-content>
</div>
`
})
export class BlockFollowerComponent extends BaseComponent implements OnInit {

    chnlData: any;
    getFollowerRequest = new GetFollowerListRequest();
    blockedFollowerList = new GetFollowerListResponse();
    blockUnblockFollowerRequest = new BlockUnblockFollowerRequest();
    blockUnblockFollowerResponse = new BlockUnblockFollowerResponse();
    communityMembersList: any;

    constructor(public dialogRef: MatDialogRef<BlockFollowerComponent>, public dialog: MatDialog,
        public profileService: ProfileService, public router: Router, public loggerService: LoggerService,
        public toastr: ToastrService) {
        super(loggerService, router, toastr)
    }

    ngOnInit() {

        this.chnlData = JSON.parse(localStorage.getItem('createCommunityData'));
        this.profileService.showLoader();
        this.getFollowerRequest.chnlKey = this.chnlData.communityKey;

        this.profileService.getBlockedFollowerList(this.getFollowerRequest).subscribe(result => this.handleresponseOfGetBlockedFollowersList(result),
            error => this.handleError(error));
    }

    handleresponseOfGetBlockedFollowersList(result: GetFollowerListResponse) {
        this.profileService.hideLoader();
        this.communityMembersList = result.communityMembersList
    }

    unblockMember(details) {
        let memberData = {
            memberId: details.userId,
            chnlKey: this.chnlData.communityKey
        }

        let dialogRef = this.dialog.open(confirmOptionPopupComponent);
        dialogRef.componentInstance.state = "unblock";
        dialogRef.componentInstance.details = memberData;
        dialogRef.componentInstance.onAdd.subscribe((res) => {
            if (res == 'success') {
                this.ngOnInit();
            } else {
                console.log('cancel')
            }
        });
    }
}

@Component({
    selector: 'app-confirm-popup',
    template: `<div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Are you sure you want to delete this channel? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" (click)="onNoClick('no')" mat-dialog-close>No</button>
    <button type="submit" class="btnPopup btnRed" (click)="yesClick()" mat-dialog-close>Yes</button>
  </mat-dialog-actions>
  </div>`
})
export class confirmDeletePopupComponent extends BaseComponent implements OnInit {
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    deleteCommunityRequest = new DeleteCommunityRequest();

    constructor(public router: Router, public dialogRef: MatDialogRef<confirmDeletePopupComponent>, public toastr: ToastrService, public dialog: MatDialog,
        public profileService: ProfileService, public loggerService: LoggerService) {
        super(loggerService, router, toastr)
    }
    ngOnInit() {
    }
    onNoClick(option: string): void {
        this.dialogRef.close(option);
    }

    yesClick() {
        let channel = JSON.parse(localStorage.getItem("createCommunityData"))

        this.profileService.showLoader()
        this.deleteCommunityRequest.communityKey = channel.communityKey
        this.profileService.deleteCommunity(this.deleteCommunityRequest).subscribe(response => this.handleresponseOfDeleteCommunity(response),
            error => this.handleError(error));

    }

    handleresponseOfDeleteCommunity(response: DeleteCommunityResponse) {

        this.loggerService.info('response   :   ', response)

        if (response.success == true) {
            if (localStorage.getItem('currentPath') == '/channel-dashboard') {
                this.router.navigate(["welcome-dashboard"])
            }
            this.profileService.hideLoader()
            this.toastr.success('Channel Deleted successfully.', 'Success !!');

        } else {
            this.profileService.hideLoader()
            this.toastr.error('Error to delete channel.', 'Error !!');

        }
    }
}
@Component({
    selector: 'app-confirm-popup',
    template: `
    <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Are you sure you want to leave this channel? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" (click)="onNoClick('no')" mat-dialog-close>No</button>
    <button type="submit" class="btnPopup btnRed" (click)="yesClick('yes')" mat-dialog-close>Yes</button>
  </mat-dialog-actions>
  </div>`
})
export class confirmLeavePopupComponent extends BaseComponent implements OnInit {
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    leaveCommunityRequest = new LeaveCommunityRequest();
    onAdd = new EventEmitter();


    constructor(public dialogRef: MatDialogRef<confirmLeavePopupComponent>, public toastr: ToastrService,
        private profileService: ProfileService, public dialog: MatDialog, public loggerService: LoggerService,
        public router: Router, @Inject(MAT_DIALOG_DATA) public leaveData: any) {
        super(loggerService, router, toastr)
    }
    ngOnInit() {

    }
    onNoClick(option: string): void {
        this.dialogRef.close(option);
    }
    debuggingMode: true;

    yesClick(option: string): void {

        // let channel = JSON.parse(localStorage.getItem('createCommunityData'))
        // let userDetails = JSON.parse(localStorage.getItem('userDetails'));


        // if (userDetails.user.userId == channel.ownerId && channel.isMember) {
        //     this.toastr.info('Owner Cannot leave channel', 'Info !!');
        // } else {
        this.profileService.showLoader()
        this.leaveCommunityRequest.communityJabberId = this.leaveData.communityJabberId;
        this.leaveCommunityRequest.new_admin_user_id = this.leaveData.new_admin_user_id;
        // let chnlKey = this.leaveData.chnlKey;


        // this.toastr.success('Channel left successfully.', 'Success !!');
        // this.onAdd.emit('successleave');

        this.profileService.leaveCommunity(this.leaveCommunityRequest, this.leaveData.chnlKey).subscribe(response => this.handleresponseOfLeaveCommunity(response),
            error => this.handleError(error));

        // }
    }

    handleresponseOfLeaveCommunity(response: LeaveCommunityResponse) {
        this.loggerService.info('response   :   ', response)

        if (response.success == true) {
            if (localStorage.getItem('currentPath') == '/channel-dashboard') {
                this.router.navigate(["welcome-dashboard"])
            }
            this.profileService.hideLoader();
            this.toastr.success('Channel left successfully.', 'Success !!');
            this.onAdd.emit('successleave');

        } else {
            this.profileService.hideLoader()
            this.toastr.error('Channel left Error.', 'Error !!');

        }
    }


}

@Component({
    selector: 'app-confirm-option-popup',
    template: `
    <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Are you sure you want to Remove this Follower? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" (click)="onNoClick()">No</button>
    <button type="submit" class="btnPopup btnRed" (click)="yesClick()">Yes</button>
  </mat-dialog-actions>
  </div>`,
    providers: [ProfileService, BaseComponent],


})
export class confirmOptionPopupComponent extends BaseComponent implements OnInit {
    ChannelsRemoveFollowerRequest: ChannelsRemoveFollowerRequest = new ChannelsRemoveFollowerRequest();
    ChannelsRemoveFollowerResponse: ChannelsRemoveFollowerResponse = new ChannelsRemoveFollowerResponse();
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();

    blockUnblockFollowerRequest = new BlockUnblockFollowerRequest();
    blockUnblockFollowerResponse = new BlockUnblockFollowerResponse();
    state: string;
    details: any;
    chnlData: any = JSON.parse(localStorage.getItem('createCommunityData'));
    @Output() onAdd = new EventEmitter<any>(true);

    constructor(private profileService: ProfileService, public dialogRef: MatDialogRef<confirmRemoveFolowerPopupComponent>, public toastr: ToastrService,
        public dialog: MatDialog, public loggerService: LoggerService, public router: Router) {
        super(loggerService, router, toastr);
    }
    ngOnInit() { }

    onNoClick(): void {
        this.dialogRef.close('cancel');
    }

    yesClick(): void {
        this.profileService.showLoader()
        this.blockUnblockFollowerRequest.new_admin_user_id = "";
        this.blockUnblockFollowerRequest.operation = this.state;
        this.blockUnblockFollowerRequest.communityJabberId = this.chnlData.communityJabberId;
        this.profileService.blockUnblockFollower(this.blockUnblockFollowerRequest, this.details).subscribe(result => this.handleresponseOfBlockUnblockRemoveFollower(result, this.state),
            error => this.handleError(error));

    }

    handleresponseOfBlockUnblockRemoveFollower(result: BlockUnblockFollowerResponse, operation) {
        if (result.success) {
            this.profileService.hideLoader();
            this.toastr.success(result.message, 'Success !!');
            this.onAdd.emit('success');
            this.dialogRef.close();
        } else {
            this.toastr.info("Error to " + operation + " member", 'Info !!');
            this.onAdd.emit('cancel');
            this.dialogRef.close();
        }
    }
}



@Component({
    selector: 'app-confirm-popup',
    template: `
    <div class="whiteOuter memberConfirmPopup deleteMsgPopup">
  <h2 mat-dialog-title>Are you sure you want to Remove this Follower? </h2>
  <mat-dialog-actions class="twoBtn">
    <button type="button" class="btnPopup btnBlack" (click)="onNoClick('no')" mat-dialog-close>No</button>
    <button type="submit" class="btnPopup btnRed" (click)="yesClick('yes')" mat-dialog-close>Yes</button>
  </mat-dialog-actions>
  </div>`,
    providers: [ProfileService, BaseComponent],


})
export class confirmRemoveFolowerPopupComponent extends BaseComponent implements OnInit {
    ChannelsRemoveFollowerRequest: ChannelsRemoveFollowerRequest = new ChannelsRemoveFollowerRequest();
    ChannelsRemoveFollowerResponse: ChannelsRemoveFollowerResponse = new ChannelsRemoveFollowerResponse();
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();

    constructor(private profileService: ProfileService, public dialogRef: MatDialogRef<confirmRemoveFolowerPopupComponent>, public toastr: ToastrService,
        public dialog: MatDialog, public loggerService: LoggerService, public router: Router) {
        super(loggerService, router, toastr);
    }
    ngOnInit() {
    }
    onNoClick(option: string): void {
        this.dialogRef.close(option);
    }
    debuggingMode: true;

    yesClick(option: string): void {
        this.profileService.showLoader()

        this.dialogRef.close(option);


        this.profileService.removeChannelFollower(this.ChannelsRemoveFollowerRequest).subscribe(response => this.handleResponseOfRemoveFollower(response),
            error => this.handleError(error)
        )
    }


    handleResponseOfRemoveFollower(response: ChannelsRemoveFollowerResponse) {
        if (Response['success'] = true) {
            localStorage.removeItem('FolowerName')
            localStorage.removeItem('nodeSubscriber')
            this.profileService.hideLoader()

            this.toastr.success('Follower Removed Successfully ', 'Success !!')
            // this.router.navigate(["welcome-dashboard"])
        } else {
            this.profileService.hideLoader()

            this.toastr.error('Follower not removed ', 'Error !!')
        }
    }
}



@Component({
    selector: 'app-view-all-followers-popup',
    template: `<div class="forwardMsgPopup blockedFollower channelYouFollow maxWidthPopup">
  <mat-dialog-actions class="topHead pad-all-md">
      <button matDialogClose class="closeBtn" >
          <i class="zmdi zmdi-close"></i>
      </button>
      <span> Followers </span>
  </mat-dialog-actions>
  <mat-dialog-content>
  <div class="forwardMsgContent pad-all-md">
  <ng-container *ngFor="let follow of followerListService">
  <mat-list  *ngIf="userName != follow.id">
      <mat-list-item  class="mrgn-b-xs">
          <img mat-list-avatar *ngIf="follow.bigThumbUrl!=''" src="{{follow.bigThumbUrl}}" onerror="this.style.display='none'" />
          <img mat-list-avatar *ngIf="(!follow.bigThumbUrl)" src="./assets/img/default_user.png" />

          <h3 matLine class="font-bold-five"> {{follow.firstName}} {{follow.lastName}}
          </h3>
          
      </mat-list-item>
      </mat-list>
  </ng-container>
  </div>
</mat-dialog-content>
</div>`
})
export class ViewAllFollowersComponent extends BaseComponent implements OnInit {
    userName: string;
    followerListService: any;
    userDetails: any;

    getFollowerRequest = new GetFollowerListRequest();
    chnlData: any;
    @Output() notify: EventEmitter<string> = new EventEmitter<string>();
    showFollowerOptionPopup: boolean = false;

    // constructor(public router: Router, public dialog: MatDialog, public loggerService: LoggerService,
    //     public categoriesService: CategoriesService, public toastr: ToastrService,
    //     public profileService: ProfileService) {
    //     super(loggerService, router, toastr)
    // }

    constructor(public dialogRef: MatDialogRef<ViewAllFollowersComponent>, public dialog: MatDialog,
        public profileService: ProfileService, public loggerService: LoggerService, public router: Router,
        public toastr: ToastrService) {
        super(loggerService, router, toastr)
    }

    ngOnInit() {
        localStorage.removeItem('Selectedfollower')
        this.chnlData = JSON.parse(localStorage.getItem('createCommunityData'))
        this.profileService.showLoader();
        this.getFollowerRequest.chnlKey = this.chnlData.communityKey;
        this.chnlData = JSON.parse(localStorage.getItem('createCommunityData'));
        this.userName = this.chnlData.ownerId;
        this.profileService.getChannelFollower(this.getFollowerRequest).subscribe(result => this.handleresponseOfGetFollowersList(result),
            error => this.handleError(error));

    }

    handleresponseOfGetFollowersList(response: GetFollowerListResponse) {
        //this.profileService.hideLoader();

        this.followerListService = response.communityMembersList;
        if (this.followerListService.length > 5) {
            //this.showViewAll = true;
            this.profileService.hideLoader()

        } else {
            //this.showViewAll = false;
            this.profileService.hideLoader()

        }
    }

    viewFollowerprofile(followerDetails) {

        localStorage.setItem('followerDetails', JSON.stringify(followerDetails));

        if (this.userDetails.user.userId == followerDetails.id) {
            this.notify.emit(PassParamsToDrawer.SHOWUSERPROFILE)
        } else {
            if (localStorage.getItem('currentPath') == '/channel-dashboard') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONCHNL)
            }
            else if (localStorage.getItem('currentPath') == '/channel-list') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONDISCOVER)
            }
            else if (localStorage.getItem('currentPath') == '/welcome-dashboard') {
                this.notify.emit(PassParamsToDrawer.SHOWFOLLOWERPROFILEONWELCOME)
            } else {
                this.notify.emit(PassParamsToDrawer.SHOWOTHERUSERPROFILE)
            }
        }
    }
}



@Component({
    selector: 'app-channel-image',
    template: `
  <div class="displayFullImage">
    <div class="topLink topLinkGreen box-shadow-top-strip mrgn-none" id='topLinkGreen'>
        <div class="container-fluid">
            <mat-list>
                <mat-list-item>
                    <p class="fullImagehead">{{heading}}</p>
                </mat-list-item>
                <mat-list-item>
                    <button matDialogClose class="closeBtn text-right widthfull">
                            <i class="zmdi zmdi-close"></i>
                    </button>
                </mat-list-item>
            </mat-list>
        </div>
    </div>
    <mat-dialog-content class="text-center">
    <ng-container *ngIf="showImg">
        <div class="fullscreenImgHeight">
            <img id="showChnlImg" src="{{imgSrc}}" alt="channel Image">
        </div>
    </ng-container>
    <ng-container *ngIf="showVideo">
    <div class="fullscreenImgHeight">
        <video  style="max-width:100%;" autoplay controls playsinline webkit-playsinline>
                <source  id="chatVideo" src="{{videoSrc}}">
        </video>
    </div>
    </ng-container>
    </mat-dialog-content>
</div>
`
})
export class showImgComponent implements OnInit {
    heading: string;
    showImg: boolean;
    showVideo: boolean;
    imgSrc: string;
    videoSrc: string;
    constructor(public dialogRef: MatDialogRef<showImgComponent>, public dialog: MatDialog, @Inject(MAT_DIALOG_DATA) public imgData: any) { }
    ngOnInit() {
        // $('#showChnlImg').src =this.imgData.imgSrc;

        if (this.imgData.srcType && this.imgData.srcType == "Broadcast Image") {
            this.heading = this.imgData.srcType;
            this.showImg = true;
            this.showVideo = false;
            this.imgSrc = this.imgData.imgSrc
        } else if (this.imgData.srcType && this.imgData.srcType == "Broadcast Video") {
            this.heading = this.imgData.srcType;
            this.showImg = false;
            this.showVideo = true;
            this.videoSrc = this.imgData.imgSrc;
        }
        else if (this.imgData.srcType && this.imgData.srcType == "Chat Image") {
            this.heading = this.imgData.srcType;
            this.showImg = true;
            this.showVideo = false;
            this.imgSrc = this.imgData.imgSrc
        } else if (this.imgData.srcType && this.imgData.srcType == "Chat Video") {
            this.heading = this.imgData.srcType;
            this.showImg = false;
            this.showVideo = true;
            this.videoSrc = this.imgData.imgSrc;
        }
        else {
            this.heading = "Profile Image";
            this.imgSrc = this.imgData.imgSrc
            //$('#showChnlImg').attr("src", this.imgData.imgSrc);
            this.showImg = true;
            this.showVideo = false;
        }

        // $('#chatVideo').attr("src", this.imgData.imgSrc);
    }
}