// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ShowChannelProfileComponent } from './show-channel-profile.component';

// describe('ShowChannelProfileComponent', () => {
//   let component: ShowChannelProfileComponent;
//   let fixture: ComponentFixture<ShowChannelProfileComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ShowChannelProfileComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ShowChannelProfileComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
