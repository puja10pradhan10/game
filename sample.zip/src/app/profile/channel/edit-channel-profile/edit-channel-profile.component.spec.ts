// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { EditChannelProfileComponent } from './edit-channel-profile.component';

// describe('EditChannelProfileComponent', () => {
//   let component: EditChannelProfileComponent;
//   let fixture: ComponentFixture<EditChannelProfileComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ EditChannelProfileComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EditChannelProfileComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
