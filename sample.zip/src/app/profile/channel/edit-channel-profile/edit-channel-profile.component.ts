import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Strings } from '@app/shared/base.constants';
import { MatDialog } from '@angular/material';
import { CategoriesComponent } from '@app/shared/categories/categories.component';
import { ToastrService } from 'ngx-toastr';
import { CategoriesService } from '@app/shared/categories/categories.service';
import { LoaderStrings, DefaultColor } from '@app/shared/base.constants';
import { cropImageComponent } from '@app/shared/base/base.component'
import { BaseService } from '@app/shared/base.service';
declare var $: any;
import { Observable } from 'rxjs/Observable';
import { ProfileService } from '@app/profile/profile.service';
import { UpdateChannelRequest, UpdateChannelResponse } from '@app/profile/profile.messages';

@Component({
  selector: 'app-edit-channel-profile',
  templateUrl: './edit-channel-profile.component.html'
})
export class EditChannelProfileComponent implements OnInit {
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  channelColor: string;
  channelData: any;
  userAreaOfInterest = [];
  chnlImageToUpload: any;
  channelName: string;
  updateChannelRequest = new UpdateChannelRequest();
  ColorPick: any;
  clickcolorpick: boolean = false;
  chnlAbout: any;
  currentTime:any;

  constructor(public dialog: MatDialog, private toastr: ToastrService, public profileService: ProfileService,
    public categoriesService: CategoriesService, public baseService: BaseService) { }

  ngOnInit() {
    this.channelData = JSON.parse(localStorage.getItem('createCommunityData'));
    this.channelColor = this.channelData['communityDominantColour'];
    localStorage.setItem('chnlIntrestCat', this.channelData['communityCategories'])
    this.channelName = this.channelData.communityName;
    this.chnlAbout = this.channelData.communityDesc;
    this.currentTime=this.baseService.generateMessagetime();
    this.convertCategoriesIdToName();
  }



  colorPicker(event) {
    this.clickcolorpick = true;
    this.ColorPick = event;
    this.channelColor = "red";
  }

  convertCategoriesIdToName() {
    var areaOfInterest = [];
    this.userAreaOfInterest = [];
    let temp = localStorage.getItem('chnlIntrestCat');
    areaOfInterest = temp.split(",");
    this.categoriesService.getCategories().subscribe(categoriesList => {
      let data = [];
      for (let k = 0; k < categoriesList.length; k++) {
        if (!categoriesList[k]['is_occupation']) {
          data.push(categoriesList[k])
        }
      }
      data.filter(response => {
        for (let i = 0; i < areaOfInterest.length; i++) {
          if (response.id == areaOfInterest[i]) {
            this.userAreaOfInterest.push({ 'name': response.name, 'image_url': response.image_url, 'id': response.id });
          } else {
            //this.loggerService.info('categories dont match')
          }
        }
      });
      localStorage.setItem('userAreaOfIntrest', JSON.stringify(this.userAreaOfInterest))
    })
  }

  removeIntrest(id) {
    for (let s = 0; s < this.userAreaOfInterest.length; s++) {
      if (this.userAreaOfInterest[s]['id'] == id) {
        this.userAreaOfInterest.splice(s, 1);
        document.getElementById(id).style.display = 'none';
        return true;
      }
    }
  }

  closeDrawer(option) {
    if (option == 'closeLeft') {
      this.notify.emit('closeDrawer');
    }
    if (localStorage.getItem('closeDrawer') == 'closeLeft') {
      this.notify.emit('closeDrawer');
    } else {
      this.notify.emit('closeRightDrawer');
    }
  }

  openFilterDialog(value) {
    this.getUpdatedChnlIntrest();
    localStorage.setItem(Strings.NAVIGATE_FROM, Strings.ADD_MORE_CHANNEL_PROFILE);

    let dialogRef = this.dialog.open(CategoriesComponent, {
      panelClass: 'my-full-screen-dialog',
      data: { id: value }
    });

    const sub = dialogRef.componentInstance.onAdd.subscribe((data) => {
      localStorage.setItem('chnlIntrestCat', data);
      this.convertCategoriesIdToName();
    });
    dialogRef.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  base64String: any;
  communityImageUrl: any;

  fileChangeEvent(fileInput: any) {
    this.chnlImageToUpload = fileInput.target.files[0];

    let filename = fileInput.target.files[0]['name'];
    var reader = new FileReader();
    reader.readAsDataURL(fileInput.target.files[0]);
    reader.onload = (e: Event) => {
      let fileUrl = e.target['result'];

      this.base64String = e.target['result'].split(',').pop();



      let index = filename.lastIndexOf(".");
      var strsubstring = filename.substring(index, filename.length);
      localStorage.setItem('communityJabberId', this.channelData['communityJabberId']);

      if (strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') {

        let dialogRef = this.dialog.open(cropImageComponent, {
          data: {
            uploadedFile: fileInput,
            case: 'editChannel',
          }
        });

        const sub = dialogRef.componentInstance.onAdd.subscribe((data) => {

          document.getElementById("myImg").setAttribute('src', data.base64);
          this.chnlImageToUpload = data.fileObj;
        })
        // this.updateChannelRequest.communityDetails.communityImageBigThumbUrl = this.channelData.communityImageBigThumbUrl;
        // this.updateChannelRequest.communityDetails.communityImageSmallThumbUrl = this.channelData.communityImageSmallThumbUrl;
        // this.updateChannelRequest.communityDetails.communityImageUrl = this.channelData.communityImageUrl;
      }
      else {
        this.toastr.error('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Error!');
        return false;
      }
    }

  }

  getUpdatedChnlIntrest() {
    let arr = [];
    for (let k = 0; k < this.userAreaOfInterest.length; k++) {

      arr.push(this.userAreaOfInterest[k]['id'])
    }
    localStorage.setItem('chnlIntrestCat', arr.join())
  }

  updateChannelProfile() {
    if (this.userAreaOfInterest.length) {
      this.getUpdatedChnlIntrest();
    } else {
      this.toastr.info('Please select atleast one intreast', 'Info !!')
      return false;
    }
    if (this.channelName == "" || this.channelName == undefined) {
      this.toastr.info('Please enter first name', 'Info !!')
      return false;
    }
    this.updateChannelRequest.communityDetails.communityName = this.channelName;
    this.updateChannelRequest.communityDetails.communityKey = this.channelData.communityKey;
    this.updateChannelRequest.communityDetails.communityCategories = localStorage.getItem('chnlIntrestCat');
    this.updateChannelRequest.communityDetails.communityDominantColour = this.channelColor;

    this.updateChannelRequest.communityDetails.communityJabberId = this.channelData.communityJabberId;

    this.updateChannelRequest.communityDetails.communityDesc = this.chnlAbout || "";
    this.updateChannelRequest.communityDetails.privacy = this.channelData.privacy;
    this.updateChannelRequest.communityDetails.ownerId = this.channelData.ownerId;
    this.updateChannelRequest.communityDetails.ownerName = this.channelData.ownerName;
    this.updateChannelRequest.communityDetails.type = "channel";
    this.updateChannelRequest.resource = "web";
    this.updateChannelRequest.communityDetails.isMember = true;
    if (this.chnlImageToUpload && this.chnlImageToUpload != "") {

      BaseService.fileObj = this.chnlImageToUpload;
      BaseService.getSource = 'chnlProfileImage';
      let sendMsgFileObject = {
        'chnlKey': this.channelData['communityJabberId'],
        'source': 'chnlProfileImage',
        'filename': this.chnlImageToUpload.name
      }
      localStorage.setItem('sendMsgFileObject', JSON.stringify(sendMsgFileObject))

      new Observable(this.baseService.uploadFile).subscribe(
        (res) => {
          new Observable(this.baseService.getUplodedFileUrl).subscribe(
            (actualMessageUrl) => {
              if (actualMessageUrl != "") {
                this.communityImageUrl = actualMessageUrl;
                localStorage.setItem('communityImageUrl', '"' + actualMessageUrl + '"');

                this.updateChannelRequest.communityDetails.communityImageBigThumbUrl = "" + actualMessageUrl + "";
                this.updateChannelRequest.communityDetails.communityImageSmallThumbUrl = "" + actualMessageUrl + "";
                this.updateChannelRequest.communityDetails.communityImageUrl = "" + actualMessageUrl + "";

              } else {
                this.communityImageUrl = "";
                this.updateChannelRequest.communityDetails.communityImageBigThumbUrl = this.channelData.communityImageBigThumbUrl;
                this.updateChannelRequest.communityDetails.communityImageSmallThumbUrl = this.channelData.communityImageSmallThumbUrl;
                this.updateChannelRequest.communityDetails.communityImageUrl = this.channelData.communityImageUrl;
              }
              this.updateProfile();
            })
        }, (complete) => {
        })
    } else {
      this.communityImageUrl = "";
      this.updateChannelRequest.communityDetails.communityImageBigThumbUrl = this.channelData.communityImageBigThumbUrl;
      this.updateChannelRequest.communityDetails.communityImageSmallThumbUrl = this.channelData.communityImageSmallThumbUrl;
      this.updateChannelRequest.communityDetails.communityImageUrl = this.channelData.communityImageUrl;
      this.updateProfile();
    }

  }

  updateProfile() {
    this.baseService.showLoader();
    this.profileService.updateChannelProfile(this.updateChannelRequest).subscribe(response => this.handleresponseOfUpdateChannelProfile(response),
      error => { console.log(error) });
  }

  handleresponseOfUpdateChannelProfile(response) {
    this.baseService.hideLoader();
    this.toastr.success('Channel profile updated successfully', 'Success !!');
    localStorage.setItem('createCommunityData', JSON.stringify(this.updateChannelRequest.communityDetails));
    this.closeDrawer('closeLeft');
    this.notify.emit('updateDashboard');
  }
}
