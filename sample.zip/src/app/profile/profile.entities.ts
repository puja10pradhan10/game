export class communityDetails {
    communityKey: string;
    communityCategories: string;
    communityDominantColour: string;
    communityImageBigThumbUrl: string;
    communityImageSmallThumbUrl: string;
    communityImageUrl: string;
    communityJabberId: string;
    communityJoinedTimestamp: any;
    communityName: string;
    communityScore: number = 0;
    communityDesc: string;
    isCommunityWithRssFeed: boolean = false;
    isDefault: boolean = false;
    ownerId: string;
    ownerName: string;
    privacy: string;
    totalMembers: number = 0;
    type: string = "channel";
    finalScore: number = 0;
    isMember: boolean = true;
    ownerImageUrl: string;
    communityCreatedTimestamp: string;
    feed: boolean = false;
}


export class followerDetails {
    account_type: 1;
    big_thumb_url: string;
    categories: string;
    city: string;
    country: string;
    created_datetime: string;
    email: string;
    first_name: string;
    id: string;
    image_url: string;
    is_blocked: boolean;
    is_deleted: boolean;
    is_spam: boolean;
    last_active_datetime: string;
    last_login_datetime: string;
    last_name: string;
    mobile: string;
    password: string;
    profile_status: string;
    small_thumb_url: string;
    state: string;
    username: string;
}