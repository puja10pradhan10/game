import { BaseRequest, BaseResponse } from '@app/shared/base.messages';
import { communityDetails, followerDetails } from '@app/profile/profile.entities';
import { extend } from 'webdriver-js-extender';

export class ChannelsRemoveFollowerRequest extends BaseRequest {

    userName: string;
    password: string;
    resource: string;
    nodeJID: string;
    removeUserName: string;
    nodeOwnerUserName: string;
}

export class ChannelsRemoveFollowerResponse extends BaseResponse {
    userName: string;
    password: string;
    resource: string;
    nodeJID: string;
    removeUserName: string;
    nodeOwnerUserName: string;
}

export class DeleteCommunityRequest extends BaseRequest {

    resource: string;
    communityKey: string;
    userId: string;
}

export class DeleteCommunityResponse extends BaseResponse {

}

export class LeaveCommunityRequest {
    new_admin_user_id: string;
    operation: string = "leave";
    communityJabberId: string
}

export class LeaveCommunityResponse extends BaseResponse {

}

export class GetFollowerListRequest extends BaseRequest {
    chnlKey: string;
}

export class GetFollowerListResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    communityMembersList: any = [];
}

export class UpdateChannelRequest extends BaseRequest {
    communityDetails = new communityDetails();
    password: string;
    resource: string;
}

export class UpdateChannelResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    recordsAffected: number;
}

export class GetFollowerDetailsResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    myChats: any = [];
    usersDB: followerDetails;
}

export class BlockUnblockFollowerRequest extends BaseRequest {
    new_admin_user_id: string;
    operation: string;
    communityJabberId: string;
}

export class BlockUnblockFollowerResponse extends BaseResponse {

}

export class GetChannelDetailsResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: boolean;
    communityDetails = new communityDetails();
}