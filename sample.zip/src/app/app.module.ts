import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoutingModule } from "@app/app-routing.module";
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { CookieService } from 'ngx-cookie-service';

//Modules
import { MembershipModule } from '@app/membership/membership.module';
import { CommunityModule } from '@app/community/community.module';
import { DashboardModule } from '@app/dashboard/dashboard.module';
import { SharedModule } from '@app/shared/shared.module';
import { ProfileModule } from '@app/profile/profile.module';

// Components
import { AppComponent } from '@app/app.component';
import { PageNotFoundComponent } from '@app/page-not-found/page-not-found.component'
import { SplashScreenComponent } from '@app/splash-screen.component';

//services
import { AuthGuard } from '@app/auth-guard.service';
import { SelectLanguageComponent } from '@app/select-language/select-language.component';
import { MobileSplashComponent } from '@app/mobile-splash/mobile-splash.component';

import { environment } from 'environments/environment.test';
// import { AngularFireModule } from 'angularfire2';
// import { AngularFireAuthModule } from 'angularfire2/auth';
// import { AngularFireDatabaseModule } from 'angularfire2/database';
import * as firebase from "firebase/app";

firebase.initializeApp(environment.firebase);


@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    SelectLanguageComponent,
    SplashScreenComponent,
    MobileSplashComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    RoutingModule,
    MembershipModule,
    CommunityModule,
    DashboardModule,
    SharedModule,
    ProfileModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
    })

  ],
  providers: [AuthGuard,
    { provide: LocationStrategy, useClass: HashLocationStrategy },CookieService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
