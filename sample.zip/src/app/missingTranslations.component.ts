import {MissingTranslationHandler, MissingTranslationHandlerParams} from 'ng2-translate';
 
export class MissingTranslationsComponent implements MissingTranslationHandler {
    handle(params: MissingTranslationHandlerParams) {
        return 'Translations not available for ' + params.key;
    }
}
