import { Component, OnInit } from '@angular/core';
import { MembershipService } from '@app/membership/membership.service';
import { ToastrService } from 'ngx-toastr';
import { UpdateUserRequest, UpdateUserResponse } from '@app/membership/membership.messages';
import { BaseComponent } from '@app/shared/base/base.component';
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-state-filed',
  templateUrl: './state-filed.component.html'
})


export class StateFiledComponent extends BaseComponent implements OnInit {
  states = [];
  cities = [];
  selectedState: string;
  selecteddistrict: string;
  updateUserRequest: UpdateUserRequest = new UpdateUserRequest();
  userDetails: any;

  constructor(public membershipService: MembershipService, public toastr: ToastrService,
    public router: Router, public loggerService: LoggerService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");
    this.membershipService.getStates().subscribe(stateData => {
      this.states = stateData[0].stateArray.item;
    });
  }

  getDistrict(state) {
    this.selectedState = state.value;
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'));
    this.membershipService.getDistrict().subscribe(districtData => {
      this.cities = districtData[0]['districtArray'][this.selectedState];
    });
  }

  setDistrict(district) {
    this.selecteddistrict = district.value
  }

  intrArr: string;
  getUpdatedUserIntrest() {
    let arr = [];
    let intr = this.userDetails.user.userProfile.interests;
    for (let k = 0; k < intr.length; k++) {
      arr.push(intr[k])
    }
    this.intrArr = arr.join();
  }

  updateUserProfile() {
    if (this.selectedState == "" || this.selectedState == "-- Select State --" || this.selectedState == undefined) {
      this.toastr.info('Please select state.', 'Info !!');
      return false;
    }
    else if (this.selecteddistrict == "" || this.selecteddistrict == "-- Select District --" || this.selecteddistrict == undefined) {
      this.toastr.info('Please select District.', 'Info !!');
      return false;
    }
    else {
      this.getUpdatedUserIntrest();
      this.updateUserRequest.categories = this.intrArr;
      this.updateUserRequest.firstName = this.userDetails.user.firstName;
      this.updateUserRequest.lastName = this.userDetails.user.lastName;
      this.updateUserRequest.about = this.userDetails.user.userProfile.about;

      if (this.userDetails.user.userProfile.mobile1 == "") {
        this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile2;
      } else {
        this.updateUserRequest.mobile = this.userDetails.user.userProfile.mobile1;
      }
      this.updateUserRequest.accountType = this.userDetails.user.userProfile.accountType;
      this.updateUserRequest.image_url = this.userDetails.user.userProfile.imageUrl;
      this.updateUserRequest.country = this.userDetails.user.userProfile.country;
      this.updateUserRequest.state = this.selectedState;
      this.updateUserRequest.city = this.selecteddistrict;
      this.updateUserRequest.email = this.userDetails.user.email;
      this.updateUserRequest.small_thumb_url = this.userDetails.user.userProfile.imageSmallthumbUrl;
      this.updateUserRequest.oAuthToken = this.userDetails.oAuthToken;
      this.updateUserRequest.password = this.userDetails.user.userId;

      this.membershipService.updateUserAreaOfInterest("", this.updateUserRequest)
        .subscribe(response => this.handleResponseOfUpdateUserAreaOfInterest(response),
          error => this.handleError(error)
        )
    }
  }

  handleResponseOfUpdateUserAreaOfInterest(response: UpdateUserResponse) {
    if (response.success) {
      this.toastr.success('Updated successfuly', 'Success !! ')
      this.userDetails['user']['userProfile']['city'] = response.data.userProfile.city;
      this.userDetails['user']['userProfile']['state'] = response.data.userProfile.state;
      localStorage.setItem('userDetails', JSON.stringify(this.userDetails));
      this.membershipService.hideLoader();
      this.router.navigate(['welcome-dashboard']);
    }
    else {
      this.membershipService.hideLoader()
      this.toastr.error('Error occured while updating interest', 'Error !!')
    }
  }

}
