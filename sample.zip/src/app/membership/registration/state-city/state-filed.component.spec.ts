import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateFiledComponent } from './state-filed.component';

describe('StateFiledComponent', () => {
  let component: StateFiledComponent;
  let fixture: ComponentFixture<StateFiledComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateFiledComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateFiledComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
