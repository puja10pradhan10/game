import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
//Components
import { BaseComponent, cropImageComponent, webcamPopupComponent } from '@app/shared/base/base.component';
//Service
import { LoggerService } from '@app/shared/logger/logger.service';
import { MembershipService } from '@app/membership/membership.service';
import { ToastrService } from 'ngx-toastr';

import { FacebookLoginStrings, Strings, UserStrings, RegistrationStrings, connectionXmpp } from '@app/shared/base.constants';
import { RegisterUserRequest, RegisterUserResponse } from '@app/membership/membership.messages';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html'
})

export class RegistrationComponent extends BaseComponent implements OnInit {

  registerUserRequest: RegisterUserRequest = new RegisterUserRequest();
  firstName: string;
  lastName: string;
  pincode: number;
  validFirstName: boolean;
  validLastName: boolean;
  validPincode: boolean;
  @ViewChild('hardwareVideo') hardwareVideo: any;
  base64String: string;
  rightTickTakePhoto: boolean = false;
  cancelTakePhoto: boolean = false;

  constructor(public loggerService: LoggerService, public membershipService: MembershipService,
    public router: Router, public dialog: MatDialog,
    public toastr: ToastrService) {
    super(loggerService, router, toastr);
  }

  ngOnInit() {
    this.disableBack();
    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");
  }

  fileChangeEvent(fileInput: any) {
    let filename = fileInput.target.files[0]['name'];
    var reader = new FileReader();
    reader.readAsDataURL(fileInput.target.files[0]);
    reader.onload = (e: Event) => {
      let fileUrl = e.target['result'];
      // this.base64String = e.target['result'].split(',').pop();
      let index = filename.lastIndexOf(".");
      var strsubstring = filename.substring(index, filename.length);

      if (strsubstring == '.jpeg' || strsubstring == '.jpg' || strsubstring == '.png') {
        // document.getElementsByTagName('canvas')[0].style.display = "none";
        // document.getElementById("myImg").setAttribute('src', fileUrl);

        let dialogRef = this.dialog.open(cropImageComponent, {
          data: {
            uploadedFile: fileInput,
            case: 'register',
            using: 'gallery'
          }
        });

        const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {
          this.base64String = result.split(',').pop();
          document.getElementById("myImg").setAttribute('src', result);
          document.getElementsByTagName('canvas')[0].style.display = "none";
        })


      } else {
        this.toastr.error('Please upload correct File Name, File extension should be .jpeg/jpg/png', 'Error!');
        return false;
      }
    }

  }

  startwebcam() {

    let dialogRef = this.dialog.open(webcamPopupComponent)
    const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {

      this.base64String = result.split(',').pop();
      document.getElementById("myImg").setAttribute('src', result);
      document.getElementsByTagName('canvas')[0].style.display = "none";
    })

    // document.getElementById("myImg").setAttribute('src', '')
    // document.getElementsByTagName('video')[0].style.display = "block";
    // let video = this.hardwareVideo.nativeElement;
    // let n = <any>navigator;
    // if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    //   this.rightTickTakePhoto = false;
    //   this.cancelTakePhoto = false;
    //   navigator.mediaDevices.getUserMedia({ video: true })
    //     .then((stream) => {
    //       this.rightTickTakePhoto = true;
    //       this.cancelTakePhoto = true;
    //       //video.src = window.URL.createObjectURL(stream);
    //       video.srcObject = stream;
    //       video.play();
    //     }).catch((x) => { this.toastr.error("Please connect webcam or allow camera access", 'Error!'); });
    // } else {
    //   this.toastr.error("No webcam found", 'Error!');
    // }
  }

  //capture a snapshot of video
  capture(): void {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    document.getElementsByTagName('canvas')[0].style.display = "block";
    const video = <any>document.getElementsByTagName('video')[0];
    const canvas = <any>document.getElementsByTagName('canvas')[0];
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    //draw image of a snapshot
    canvas.getContext('2d').drawImage(video, 0, 0);
    let dataUrl = canvas.toDataURL('image/jpeg', 0.5);
    document.getElementsByTagName('video')[0].style.display = "none";

    // this.base64String = dataUrl.split(',').pop();
    // document.getElementById("myImg").setAttribute('src', this.base64String);

    let dialogRef = this.dialog.open(cropImageComponent, {
      data: {
        uploadedFile: dataUrl,
        case: 'register',
        using: 'webcam'
      }
    });

    const sub = dialogRef.componentInstance.onAdd.subscribe((result) => {

      this.base64String = result.split(',').pop();
      document.getElementById("myImg").setAttribute('src', result);
      document.getElementsByTagName('canvas')[0].style.display = "none";
    })

  }

  cancel() {
    this.rightTickTakePhoto = false;
    this.cancelTakePhoto = false;
    document.getElementsByTagName('video')[0].style.display = "none";
  }


  registerUser(): void {

    localStorage.setItem(Strings.NAVIGATE_FROM, Strings.REGISTRATION)
    this.validFirstName = false;
    this.validLastName = false;
    this.validPincode = false;

    if (this.firstName != undefined) {
      if (this.firstName.length >= 2) {
        if (this.firstName.charCodeAt(0) != 32) {
          this.validFirstName = true;
          this.registerUserRequest.firstName = encodeURIComponent(this.firstName);
        }
      }
    }
    if (this.lastName != undefined) {
      if (this.lastName.length >= 2) {
        if (this.lastName.charCodeAt(0) != 32) {
          this.validLastName = true;
          this.registerUserRequest.lastName = encodeURIComponent(this.lastName);
        }
      }
    }
    if (this.pincode != undefined) {
      if (this.pincode.toString().length == 6) {
        this.validPincode = true;
        this.registerUserRequest.pinCode = this.pincode;
      }
    }

    if (this.validFirstName == true && this.validLastName == true && this.validPincode == true) {

      this.registerUserRequest.firstName = this.firstName;
      this.registerUserRequest.lastName = this.lastName;
      this.registerUserRequest.pinCode = this.pincode;
      this.registerUserRequest.registrationId = localStorage.getItem('RegistrationId');
      this.registerUserRequest.fcmDeviceId = localStorage.getItem('FCMtoken');
      // "ev_NiYjv4lA:APA91bG9Dj5Ojs15y7fY1QDE2JYA5nt5Hq--3XUrcXnXPJKpgtWXyJvvOnQ3LJzwMiGA5WGAWIgRlAjee8DhQ7hfyLkwCBWSiMx5zdr3tGpxiYVqXs9KaGwYDe5tFTAmP8CioxdNGS9k";
      this.registerUserRequest.imageBlob = this.base64String;
      //localStorage.setItem('pushNotificationResourceId', this.registerUserRequest.fcmDeviceId)

      this.membershipService.showLoader();
      if (!BaseComponent.onlineOffline) {
        this.toastr.info('No internet connection, Please connect your internet ', 'Info !!');
        this.membershipService.hideLoader()
      } else {
        this.membershipService.registerUser(this.registerUserRequest)
          .subscribe(response => this.handleResponseOfRegisterUser(response),
            error => this.handleError(error));
      }
    } else if (this.validFirstName != true) {
      this.toastr.error("First Name Need Atleast 2 character", 'Error!');

    } else if (this.validLastName != true) {
      this.toastr.error("Last Name Need Atleast 2 character", 'Error!');

    } else if (this.validPincode != true) {
      this.toastr.error("Pincode Need 6 Numeric value", 'Error!');

    } else if (this.pincode != undefined || this.lastName != undefined || this.firstName != undefined) {
      this.toastr.error("All Fields Are Compulsory...", 'Error!');

    }
  }

  handleResponseOfRegisterUser(response: RegisterUserResponse) {

    //if registration success land to categories 
    if (response.responseCode == 1001) {
      let userDetails = JSON.stringify(response);

      localStorage.setItem(UserStrings.USER_DETAILS, userDetails)
      localStorage.setItem(FacebookLoginStrings.USERID, response.user.userId + connectionXmpp.HOST);

      if (response.user.userProfile.mobile1 == null || undefined) {
        localStorage.setItem(FacebookLoginStrings.PASSWORD, '"' + response.user.userProfile.mobile2 + '"');
      } else {
        localStorage.setItem(FacebookLoginStrings.PASSWORD, '"' + response.user.userProfile.mobile1 + '"');
      }
      localStorage.setItem(FacebookLoginStrings.MIDDLEWARE_TOKEN, response.middlewareToken);

      this.membershipService.hideLoader();
      this.toastr.success(response.message, 'Success')

      this.router.navigate(['categories']);

    }
    else {
      this.membershipService.hideLoader();

      this.toastr.error('Error occured while registering', 'Error!');

    }
  }
}
