export class UserDetails {

    first_name: string;
    username: string;
    email: string;
    user_profile: {
        about: string;
        address1: string;
        address2: string;
        address3: string;
        city: string;
        state: string;
        pin: number;
        country: string;
        land_line: string;
        mobile1: number;
        mobile2: number;
        email: string;
        website: string;
        longitude: number;
        latitude: number;
        designation: string;
        occupation: string;
        occupation_other: string;
        gender: string;
        avatar: any;
        organisation_name: string;
        image_url: any;
        image_bigthumb_url: any;
        image_smallthumb_url: any;
        interests: [
            string
        ];
        interest_other: string;
        location: number;
        contact_first_name: string;
        contact_last_name: string;
        is_email_verified: string;
        is_mobile_verified: string;
        email2: string;
        has_paid: string;
        visited_kisan: string;
        source: string;
        kisan_net_status: boolean;
    };
    last_name: string;

}

export class userData {
    email: string;
    firstName: string;
    lastName: string;
    username: string;
    userProfile: {
        about: string;
        accountType: number;
        city: string;
        country: string;
        imageBigthumbUrl: string;
        imageSmallthumbUrl: string;
        imageUrl: string;
        interestOther: string;
        interests: [string];
        isEmailVerified: false;
        isMobileVerified: true;
        mobile1: number;
        mobile2: number;
        pin: number;
        state: string;
        visitedKisan: boolean
    }

}

export class temp {
    success: boolean;
    message: string;
    responseCode: number;
    registrationToken: string;
    responseCodeFromOAuth: string;
    requestId: string;
    token: string;
    oAuthToken: string;
    middlewareToken: string;

    httpStatusCode: number;
    recordsAffected: number;
    country: string;
    user: {
        email: string;
        firstName: string;
        lastName: string;
        username: string;
        sessionId: string;
        userId: string;

        userProfile: {
            about: string;
            accountType: number;
            city: string;
            country: string;
            imageBigthumbUrl: string;
            imageSmallthumbUrl: string;
            imageUrl: string;
            interestOther: string;
            interests: [string];
            isEmailVerified: false;
            isMobileVerified: true;
            mobile1: number;
            mobile2: number;
            pin: number;
            state: string;
            visitedKisan: boolean;


            //old responnse

            // about: string;
            // accountType: number;
            // address1: string;
            // address2: string;
            // address3: string;
            // city: string;
            // state: string;
            // pin: number;
            // country: string;
            // land_line: string;
            // mobile1: any;
            // mobile2: any;
            // email: string;
            // website: string;
            // longitude: number;
            // latitude: number;
            // designation: string;
            // occupation: string;
            // occupation_other: string;
            // gender: string;
            // avatar: any;
            // organisationName: string;
            // image_url: any;
            // image_bigthumb_url: any;
            // image_smallthumb_url: any;
            // interests: any[];
            // interestOther: string;
            // location: number;
            // contact_first_name: string;
            // contact_last_name: string;
            // isEmailVerified: string;
            // isMobileVerified: string;
            // email2: string;
            // has_paid: string;
            // visitedKisan: string;
            // source: string;
            // kisan_net_status: boolean;
        }
    }
}