import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from '@app/membership/login/login.component';
import { MembershipService } from '@app/membership/membership.service';
import { RegistrationComponent } from '@app/membership/registration/registration.component'
import { StateFiledComponent } from '@app/membership/registration/state-city/state-filed.component';
import { SharedModule } from '@app/shared/shared.module'

@NgModule({
  imports: [
    CommonModule,
    SharedModule
  ],
  declarations: [LoginComponent, RegistrationComponent, StateFiledComponent],
  providers:[MembershipService]
})
export class MembershipModule { }
