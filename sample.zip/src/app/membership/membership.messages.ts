import { BaseRequest, BaseResponse } from '@app/shared/base.messages';
import { userData } from '@app/membership/membership.entities';

export class GenerateAccessTokenRequest extends BaseRequest {
    authorization_code: string;
}

export class GenerateAccessTokenResponse extends BaseResponse {
    access_token: string;
}

export class VerifyUserRequest extends BaseRequest {
    id_token: string;
    token: string;
    requestID: string;
    callingUserName: string;
    fcmDeviceId: string;
    facebookToken: string;
    app: string = "chat";
    source: string = "web";
}

export class VerifyUserResponse extends BaseResponse {
    success: boolean;
    message: string;
    responseCode: number;
    registrationToken: string;
    responseCodeFromOAuth: string;
    requestId: string;
    token: string;
    oAuthToken: string;
    middlewareToken: string;
    httpStatusCode: number;
    recordsAffected: number;
    country: string;
    user: {
        email: string;
        firstName: string;
        lastName: string;
        sessionId: string;
        userId: String;
        username: string;
        userProfile: {
            about: string;
            accountType: number;
            city: string;
            country: string;
            imageBigthumbUrl: string;
            imageSmallthumbUrl: string;
            imageUrl: string;
            interestOther: string;
            interests: [string];
            isEmailVerified: false;
            isMobileVerified: true;
            mobile1: any;
            mobile2: any;
            pin: number;
            state: string;
            visitedKisan: boolean
        };
    }
}


export class RegisterUserRequest extends BaseRequest {
    // first_name: string;
    // last_name: string;
    // pin_code: number;
    // registration_id: string;
    // login_type: string;

    firstName: string;
    lastName: string;
    pinCode: number;
    loginType: string = "otp";
    registrationId: string;
    email: string;
    resource: string;
    fcmDeviceId: string;
    imageBlob: string;
    app: string = "chat";
    source: string = "web";
}


export class RegisterUserResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    responseCode: number;
    success: true;
    recordsAffected: number;
    country: string;
    middlewareToken: string;
    registrationToken: string;
    responseCodeFromOAuth: number;
    user: {
        email: string;
        firstName: string;
        lastName: string;
        sessionId: string;
        userId: string;
        userProfile: {
            about: string;
            accountType: number;
            city: string;
            country: string;
            imageBigthumbUrl: string;
            imageSmallthumbUrl: string;
            imageUrl: string;
            interestOther: string;
            interests: [string];
            isEmailVerified: boolean;
            isMobileVerified: boolean;
            mobile1: string;
            mobile2: string;
            pin: number;
            state: string;
            visitedKisan: boolean
        },
        username: string
    }

}

export class UpdateUserRequest extends BaseRequest {
    categories: string;
    firstName: string;
    lastName: string;
    mobile: string;
    about: string;
    accountType: number;
    big_thumb_url: string;
    city: string;
    country: string;
    email: string;
    imageBlob: string;
    image_url: string;
    oAuthToken: string;
    password: string;
    profile_status: string = "myStatus";
    small_thumb_url: string;
    state: string;
}


export class UpdateUserResponse extends BaseResponse {
    httpStatusCode: number;
    message: string;
    requestId: number;
    success: boolean;
    responseCode: number;
    data = new userData();
}