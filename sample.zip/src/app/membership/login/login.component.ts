//general
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var jQuery: any;
declare var $: any;
import { AccountKit, AuthResponse } from 'ng2-account-kit';

//Component
import { BaseComponent } from '@app/shared/base/base.component';

//Services
import { MembershipService } from '@app/membership/membership.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';
import { CookieService } from 'ngx-cookie-service';

import { FacebookLoginStrings, Strings, UserStrings, RegistrationStrings, connectionXmpp } from '@app/shared/base.constants';
import { GenerateAccessTokenRequest, GenerateAccessTokenResponse, VerifyUserRequest, VerifyUserResponse } from '@app/membership/membership.messages';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent extends BaseComponent implements OnInit {

  generateAccessTokenRequest = new GenerateAccessTokenRequest();
  verifyUserRequest = new VerifyUserRequest();

  cookieValue = 'UNKNOWN';
  cookieExists: boolean


  constructor(public router: Router,
    private membershipService: MembershipService, public cookieService: CookieService,
    public loggerService: LoggerService, public toastr: ToastrService) {
    super(loggerService, router, toastr)

    /* login slider */
    jQuery(document).ready(function ($) {
      $('#banner-slide').bjqs({
        animtype: 'slide',
        height: 320,
        width: 320,
        responsive: true,
        randomstart: true
      });

    });

  }

  ngOnInit() {

    /* bg color change code */
    document.getElementsByTagName("body")[0].setAttribute("id", "greenColorBody");
    localStorage.setItem(Strings.CURRENT_PATH, '/login');
    this.membershipService.getPermission();
    this.loginViaFacebook();
  }



  loginViaFacebook(): void {
    if (localStorage.getItem('permission') && (localStorage.getItem('permission') == 'notAllowed')) {
      this.toastr.info('Please change setting for allow us to show notification, it is mandatory to login', 'Info !!');
      return;
    }
    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet ', 'Info !!')
    } else {
      AccountKit.login(FacebookLoginStrings.PHONE,
        { countryCode: '+91', phoneNumber: '' }).then(
          (response: AuthResponse) => this.loginCallback(response),
          (error: any) => console.log(error)

          // (error: any) => this.loginCallback(error)
        );
    }

  }


  loginCallback(response): void {
    if (response.status == FacebookLoginStrings.PARTIALLY_AUTHENTICATED) {

      // this.membershipService.showLoader()
      //Generate Access token 
      // this.generateAccessTokenRequest.authorization_code = response.code
      // this.membershipService.generateAccessTokenForOAuthCall(this.generateAccessTokenRequest).subscribe(response => this.handleresponseOfGenerateAccessToken(response),
      //   error => this.handleError(error));

      // console.log('access token => ', response)

      localStorage.setItem(FacebookLoginStrings.AUTHENTICATION_TOKEN, response.code)

      this.verifyUserRequest.facebookToken = response.code;
      // this.verifyUserRequest.fcmDeviceId = "ev_NiYjv4lA:APA91bG9Dj5Ojs15y7fY1QDE2JYA5nt5Hq--3XUrcXnXPJKpgtWXyJvvOnQ3LJzwMiGA5WGAWIgRlAjee8DhQ7hfyLkwCBWSiMx5zdr3tGpxiYVqXs9KaGwYDe5tFTAmP8CioxdNGS9k";
      this.verifyUserRequest.fcmDeviceId = localStorage.getItem('FCMtoken');

      if (!BaseComponent.onlineOffline) {
        this.toastr.info('No internet connection, Please connect your internet ', 'Info !!');
        this.membershipService.hideLoader()
      } else {


        var date = new Date();
        var minutes = 1.5;
        date.setTime(date.getTime() + (minutes * 60 * 1000));


        this.cookieService.set("AuthenticationToken", response.code, date);
        this.cookieValue = this.cookieService.get(FacebookLoginStrings.AUTHENTICATION_TOKEN);


        console.log(this.cookieValue)

        this.membershipService.verifyUser(this.verifyUserRequest).subscribe(response => this.handleresponseOfVerifyUser(response),
          error => this.handleError(error));
      }
    }
    else if (response.status == FacebookLoginStrings.NOT_AUTHENTICATED) {
      // handle authentication failure

      this.toastr.info('Please login to continue', 'Info !!')
      this.membershipService.hideLoader()
    }
    else if (response.status == FacebookLoginStrings.BAD_PARAMS) {
      // handle bad parameters
      this.toastr.info('Please login to continue', 'Info !!')
      this.membershipService.hideLoader()

    }
  }

  handleresponseOfGenerateAccessToken(response: GenerateAccessTokenResponse) {

    var date = new Date();
    var minutes = 1.5;
    date.setTime(date.getTime() + (minutes * 60 * 1000));


    this.cookieService.set("AuthenticationToken", response.access_token, date);
    this.cookieValue = this.cookieService.get(FacebookLoginStrings.AUTHENTICATION_TOKEN);


    console.log(this.cookieValue)
    // localStorage.setItem(FacebookLoginStrings.AUTHENTICATION_TOKEN, response.access_token)

    this.verifyUserRequest.facebookToken = response.access_token;
    // this.verifyUserRequest.fcmDeviceId = "ev_NiYjv4lA:APA91bG9Dj5Ojs15y7fY1QDE2JYA5nt5Hq--3XUrcXnXPJKpgtWXyJvvOnQ3LJzwMiGA5WGAWIgRlAjee8DhQ7hfyLkwCBWSiMx5zdr3tGpxiYVqXs9KaGwYDe5tFTAmP8CioxdNGS9k";
    this.verifyUserRequest.fcmDeviceId = localStorage.getItem('FCMtoken');

    if (!BaseComponent.onlineOffline) {
      this.toastr.info('No internet connection, Please connect your internet ', 'Info !!');
      this.membershipService.hideLoader()
    } else {
      this.membershipService.verifyUser(this.verifyUserRequest).subscribe(response => this.handleresponseOfVerifyUser(response),
        error => this.handleError(error));
    }
  }

  handleresponseOfVerifyUser(response: VerifyUserResponse) {
    if (response.responseCode == 1002) {
      this.membershipService.hideLoader()
      localStorage.setItem(RegistrationStrings.REGISTRATION_ID, response.registrationToken)
      this.router.navigate(['register'])
    }
    else {

      let userDetails = JSON.stringify(response);
      localStorage.setItem(UserStrings.USER_DETAILS, userDetails)
      localStorage.setItem(FacebookLoginStrings.USERID, response.user.userId + connectionXmpp.HOST);
      if (response.user.userProfile.mobile1 == null || undefined) {
        localStorage.setItem(FacebookLoginStrings.PASSWORD, response.user.userProfile.mobile2);
      } else {
        localStorage.setItem(FacebookLoginStrings.PASSWORD, response.user.userProfile.mobile1);
      }
      localStorage.setItem(FacebookLoginStrings.MIDDLEWARE_TOKEN, response.middlewareToken);
      let xmppResponse = new Observable(this.connectToServer);
      xmppResponse.subscribe(
        (res) => {
          this.membershipService.hideLoader();
          this.navigation();
        },
        (complete) => {
        }
      );

    }
  }

  navigation() {
    this.membershipService.hideLoader();
    let str = localStorage.getItem('currentPath')
    str = str.replace('/', '');
    if (str == 'login') {
      this.router.navigate(['welcome-dashboard'])
    } else {
      this.router.navigate([str])
    }

  }

}
