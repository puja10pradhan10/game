import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { environment } from '@env/environment';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

//Service
import { BaseService } from '@app/shared/base.service';
import { LoggerService } from '@app/shared/logger/logger.service';
import { ToastrService } from 'ngx-toastr';

import { FacebookLoginStrings, VerifyUserStrings, Strings, UserStrings } from '@app/shared/base.constants';
import {
  GenerateAccessTokenRequest, GenerateAccessTokenResponse, VerifyUserRequest, VerifyUserResponse, RegisterUserRequest, RegisterUserResponse,
  UpdateUserRequest, UpdateUserResponse
} from '@app/membership/membership.messages';

import { HeaderString } from '@app/shared/base.constants';
var firebase = require("firebase/app");
require("firebase/messaging");

// Add additional services you want to use
// require("firebase/auth");
// require("firebase/database");
// require("firebase/firestore");
// require("firebase/functions");

// import * as firebase from 'firebase';
// import "firebase/messaging";

@Injectable()
export class MembershipService extends BaseService {
  messaging = firebase.messaging();
  constructor(public http: Http, public toastr: ToastrService,
    public loggerService: LoggerService) {
    super(loggerService, http)

  }

  getPermission() {

    if (firebase.messaging.isSupported()) {
      this.messaging.requestPermission()
        .then(() => {
          return this.messaging.getToken()
        })
        .then(token => {
          localStorage.setItem('permission', 'allowed')
          localStorage.setItem('FCMtoken', token);
        })
        .catch((err) => {
          localStorage.setItem('permission', 'notAllowed')
          this.toastr.info('Please change setting for allow us to show notification, it is mandatory to login OR this site not work in incognito browser mode.', 'Info !!');
          return false;
        });
    } else {
      this.toastr.info('FCM notification is not supported', 'Info !!');
    }

  }

  generateAccessTokenForOAuthCall(generateAccessTokenRequest: GenerateAccessTokenRequest): Observable<GenerateAccessTokenResponse> {
    let appAccessToken = ['AA', environment.facebookConfig.APP_ID, environment.facebookConfig.ACCOUNT_KIT_APP_SECRET].join('|');

    let params = {
      grant_type: FacebookLoginStrings.AUTHORIZATION_CODE,
      code: generateAccessTokenRequest.authorization_code,
      access_token: appAccessToken
    };

    let tokenExchangeUrl = environment.facebookConfig.TOKEN_EXCHANGE_BASE_URL +
      '?' + FacebookLoginStrings.GRANT_TYPE + '=' + params.grant_type +
      '&' + FacebookLoginStrings.CODE + '=' + params.code +
      '&' + FacebookLoginStrings.ACCESS_TOKEN + '=' + params.access_token;
    // this.loggerService.info(params)
    // this.loggerService.info(tokenExchangeUrl)

    return this.http.get(tokenExchangeUrl)
      .map((response: Response) => <GenerateAccessTokenResponse>response.json())
      // .do(data => this.loggerService.info(' MembershipService GenerateAccessTokenResponse Response : ' + JSON.stringify(data)))
      .catch(this.handleError);


  }


  verifyUser(verifyUserRequest: VerifyUserRequest): Observable<VerifyUserResponse> {

    let verifyUserUrl = environment.oAuthConfig.API_BASE_URL + VerifyUserStrings.SOCIAL_AUTH + '/' + VerifyUserStrings.FACEBOOK;
    
    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);

    return this.http.post(verifyUserUrl, verifyUserRequest, options)
      .map((response: Response) => <VerifyUserResponse>response.json())
      // .do(data => this.loggerService.info(' MembershipService VerifyUserResponse Response : ' + JSON.stringify(data)))
      .catch(this.handleError);
  }



  registerUser(request: RegisterUserRequest): Observable<RegisterUserResponse> {
    let registerUserUrl = environment.oAuthConfig.API_BASE_URL + "users/";

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    request.resource = "web_" + this.generateMessageGuid();

    return this._http.post(registerUserUrl, request, options)
      .map((response: Response) => <RegisterUserResponse>response.json())
      .do(data => this.loggerService.info('RegisterUser Response: ' + data))
      .catch(this.handleError);
  }


  updateUserAreaOfInterest(interest: any, request: UpdateUserRequest): Observable<UpdateUserResponse> {

    let options = this.getHeaderForAPICall();
    options.headers.append(HeaderString.CONTENT_TYPE, HeaderString.APPLICATION_JSON);
    options.headers.append(HeaderString.X_API_KEY, environment.oAuthConfig.CLIENT_ID);
    options.headers.append(HeaderString.X_API_SECRET, environment.oAuthConfig.CLIENT_SECRET);
    options.headers.append(HeaderString.X_REQUEST_ID, HeaderString.X_REQUEST_ID_VAL);
    options.headers.append(HeaderString.AUTHORIZATION, HeaderString.BEARER + localStorage.getItem('middleware_token'));

    let details = JSON.parse(localStorage.getItem(UserStrings.USER_DETAILS))

    let updateUserUrl = environment.oAuthConfig.API_BASE_URL + "users/" + details.user.userId;

    this.loggerService.info('updateUserAreaOfInterest request :   ', JSON.stringify(request))
    return this._http.put(updateUserUrl, request, options)
      .map((response: Response) => <UpdateUserResponse>response.json())
      .do(data => this.loggerService.info('updateUserAreaOfInterest Response: ' + JSON.stringify(data)))
      .catch(this.handleError);
  }

  getStates(): Observable<any> {
    return this.http.get('../assets/json/state.json')
      .map(response => response.json());
  }

  getDistrict(): Observable<any> {
    return this.http.get('../assets/json/district.json')
      .map(response => response.json());
  }
}
