

export var connection;

export function connect(jid, password) {
 
    
     connection = new Strophe.Connection("http://13.126.172.180:7070/http-bind/");
    // connection = new Strophe.Connection("https://kisan-test.m.in-app.io/http-bind");
   // connection = new Strophe.Connection("https://kisan.m.in-app.io/http-bind");

    connection.connect(jid, password, onConnect);
    localStorage.setItem('username', jid)
    localStorage.setItem('password', password)
}
function onConnect(status) {
    if (status === Strophe.Status.CONNECTING) {
    }
    else if (status === Strophe.Status.CONNFAIL) {
    }
    else if (status === Strophe.Status.DISCONNECTING) {
    }
    else if (status === Strophe.Status.DISCONNECTED) {
        connect(localStorage.getItem('username'), localStorage.getItem('password'))

    }
    else if (status === Strophe.Status.CONNECTED) {

        connection.send($pres());
        connection.addHandler(receiveLatestMessage, null, 'message');



    }
}





export function sendMsg(messageTo, message) {
  
    var type = "sent";
    sendMessage(messageTo, message)
}

function sendMessage(messgeTo, message, type) {
    var messagetype = (type) ? type : 'chat';
    var reply;
    if (messagetype === 'groupchat') {
        reply = $msg({
            to: messgeTo,
            from: connection.jid,
            type: messagetype,
            id: connection.getUniqueId()
        }).c("body", { xmlns: Strophe.NS.CLIENT }).t(message);
    }
    else {
        reply = $msg({
            to: messgeTo,
            from: connection.jid,
            type: messagetype
        }).c("body").t(message);
    }
    connection.send(reply.tree());
    
}

export function receiveLatestMessage(msg) {
    var to = msg.getAttribute('to');
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var elems = $(msg).find('body').text();
    $("ol").prepend("<li>" + from + ":-" + elems + "</li>");
    newMsg = from + ":-" + elems;
    return newMsg;
}
