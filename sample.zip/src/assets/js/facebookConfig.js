
//dev
AccountKit_OnInteractive = function () {

  AccountKit.init(
    {
      appId: "2022980537921344",
      state: "44482dedb318183e7a0def2c22691029",
      version: "v1.3",
      display: 'modal'
    }
  );
};


//test
//  AccountKit_OnInteractive = function () {

//   AccountKit.init(
//     {
//       appId: "191829714701825",
//       state: "cbd70feb896629377a8fcbacc54b691f",
//       version: "v1.3",
//       display: 'modal'
//     }
//   );
// }; 