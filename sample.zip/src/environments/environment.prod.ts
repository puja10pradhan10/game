export const environment = {
  production: true,
  facebookConfig: {
    // APP_ID: '191829714701825',
    // ACCOUNT_KIT_CLIENT_TOKEN: '77078e774ee224fb66e8ba4f22fc130a',
    // ACCOUNT_KIT_API_VERSION: 'v1.3',
    // ACCOUNT_KIT_APP_SECRET: 'cbd70feb896629377a8fcbacc54b691f',
    // TOKEN_EXCHANGE_BASE_URL: 'https://graph.accountkit.com/v1.3/access_token'
    APP_ID: '2022980537921344',
    ACCOUNT_KIT_CLIENT_TOKEN: 'd562ed9ce5cc9c55082bb17a707e83db',
    ACCOUNT_KIT_API_VERSION: 'v1.3',
    ACCOUNT_KIT_APP_SECRET: '44482dedb318183e7a0def2c22691029',
    TOKEN_EXCHANGE_BASE_URL: 'https://graph.accountkit.com/v1.3/access_token'
  },
  jerseyConfig: {
    API_BASE_URL: "http://kcm-test.ap-southeast-1.elasticbeanstalk.com/webapi/",
    APP_KEY: "8b88e789-d091-4379-be3b-8107cce27c24",
    APP_SECRET: "0221ee84-c793-418a-bbaa-1441d4200933"
    // API_BASE_URL: "http://Testing.izpxtirkev.ap-south-1.elasticbeanstalk.com/webapi/",
    //API_BASE_URL: "http://192.168.10.122:8080/kisanchat-services/webapi/",
    // APP_KEY: "diuvwipXMHh7pigOT5Xp494642P7w6lm",
    // APP_SECRET: "B42DCBC99843E928F9A784D61A9AE"
  },
  oAuthConfig: {
    // API_BASE_URL: "https://middleware.kisan.co.in/webapi/",
    // API_BASE_URL: "http://192.168.10.155:8080/kisanchat/webapi/",
    API_BASE_URL: "https://middleware.kisanlab.com/webapi/",
    CLIENT_ID: "8b88e789-d091-4379-be3b-8107cce27c24",
    CLIENT_SECRET: "0221ee84-c793-418a-bbaa-1441d4200933"
  },
  awsConfig: {
    BUCKET_NAME: "kisannet-channelmedias-dev",
    BUCKET_REGION: "ap-south-1",
    BUCKET_BASEURL: "https://s3.ap-south-1.amazonaws.com/",
    BUCKET_ACCESS_KEY_ID: 'AKIAJMDC2KEF4XSCCQKQ',
    BUCKET_SECRET_ACCESS_KEY: '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'
  },
  autoLogin: {
    AUTO_LOGIN_BASE_URL: "http://id.kisan.co.in/"
  },
  IS_DEBUG_MODE: false
};
