import { createFeatureSelector,createSelector,MemoizedSelector } from '@ngrx/store';
import { IHome } from '../../interfaces';
import { featureAdapter, State } from './state';

export const getError = (state: State): any => state.error;
export const getIsLoading = (state: State): boolean => state.isLoading;
export const getIsLoaded = (state: State): boolean => state.isLoaded;
export const selectMyFeatureState: MemoizedSelector<object,State> = createFeatureSelector<State>('home');

export const selectAllMyFeatureItems: (
  state: object
) => IHome[] = featureAdapter.getSelectors(selectMyFeatureState).selectAll;

export const selectMyFeatureById = (id: any) =>
  createSelector(this.selectAllMyFeatureItems, (allMyFeatures: IHome[]) => {
    if (allMyFeatures) {
      return allMyFeatures.find(p => p.id === id);
    } else {
      return null;
    }
  });

export const selectMyFeatureError: MemoizedSelector<object, any> = createSelector(
  selectMyFeatureState,
  getError
);

export const selectMyFeatureIsLoading: MemoizedSelector<
  object,
  boolean
> = createSelector(selectMyFeatureState, getIsLoading);

export const selectMyFeatureIsLoaded: MemoizedSelector<
  object,
  boolean
> = createSelector(selectMyFeatureState, getIsLoaded);