import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { IHome } from '../../interfaces';

export const featureAdapter: EntityAdapter<IHome> = createEntityAdapter<IHome>({
  selectId: model => model.id,
  sortComparer: (a: IHome, b: IHome): number =>
    b.id.toString().localeCompare(a.id.toString())
});

export interface State extends EntityState<IHome> {
  isLoading?: boolean;
  isLoaded?: boolean;
  error?: any;
}

export const initialState: State = featureAdapter.getInitialState(
  {
    isLoading: false,
    isLoaded: false,
    error: null
  }
);