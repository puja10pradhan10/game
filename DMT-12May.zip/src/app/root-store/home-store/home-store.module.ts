import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { HomeStoreEffects } from './effects';
import { homeReducer } from './reducer';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class HomeStoreModule { }
