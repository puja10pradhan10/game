import { HomeStoreState } from './home-store';
import { MdlStoreState } from './mdl-store';
import { UserStoreState } from './user-store';
import { GlobalStoreState } from './global-store';
import { AdminStoreState } from './admin-store';


export interface State {
  home: HomeStoreState.State;
  mdl: MdlStoreState.State;
  user: UserStoreState.State;
  global: GlobalStoreState.State;
  admin: AdminStoreState.State;
}