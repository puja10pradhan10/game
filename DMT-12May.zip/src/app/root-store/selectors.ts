import { createSelector, MemoizedSelector } from '@ngrx/store';
import { HomeStoreSelectors } from './home-store';
import { MdlStoreSelectors } from './mdl-store';
import { UserStoreSelectors } from './user-store';
import { GlobalStoreSelectors } from './global-store';
import { AdminStoreSelectors } from './admin-store'; 

/* Home store selector */
export const selectError: MemoizedSelector<object, string> = createSelector(
  HomeStoreSelectors.selectMyFeatureError,
  (jokeError: string) => {
    return jokeError;
  }
);

export const selectIsLoading: MemoizedSelector<
  object,
  boolean
> = createSelector(
  HomeStoreSelectors.selectMyFeatureIsLoading,
  (token: boolean) => {
    return token;
  }
);

export const selectIsLoaded: MemoizedSelector<
  object,
  boolean
> = createSelector(
  HomeStoreSelectors.selectMyFeatureIsLoaded,
  (token: boolean) => {
    return token;
  }
);

/* MDL store selector */
export const selectErrorMdl: MemoizedSelector<object, string> = createSelector(
  MdlStoreSelectors.selectMyFeatureError,
  (jokeError: string) => {
    return jokeError;
  }
);

export const selectIsLoadingMdl: MemoizedSelector<
  object,
  boolean
> = createSelector(
  MdlStoreSelectors.selectMyFeatureIsLoading,
  (token: boolean) => {
    return token;
  }
);

export const selectIsLoadedMdl: MemoizedSelector<
  object,
  boolean
> = createSelector(
  MdlStoreSelectors.selectMyFeatureIsLoaded,
  (token: boolean) => {
    return token;
  }
);


/* User store selector */
export const selectErrorUser: MemoizedSelector<object, string> = createSelector(
  UserStoreSelectors.selectMyFeatureError,
  (jokeError: string) => {
    return jokeError;
  }
);

export const selectIsLoadingUser: MemoizedSelector<
  object,
  boolean
> = createSelector(
  UserStoreSelectors.selectMyFeatureIsLoading,
  (token: boolean) => {
    return token;
  }
);

export const selectIsLoadedUser: MemoizedSelector<
  object,
  boolean
> = createSelector(
  UserStoreSelectors.selectMyFeatureIsLoaded,
  (token: boolean) => {
    return token;
  }
);

/* Global store selector */
export const selectErrorGlobal: MemoizedSelector<object, string> = createSelector(
  GlobalStoreSelectors.selectMyFeatureError,
  (jokeError: string) => {
    return jokeError;
  }
);

export const selectIsLoadingGlobal: MemoizedSelector<
  object,
  boolean
> = createSelector(
  GlobalStoreSelectors.selectMyFeatureIsLoading,
  (token: boolean) => {
    return token;
  }
);

export const selectIsLoadedGlobal: MemoizedSelector<
  object,
  boolean
> = createSelector(
  GlobalStoreSelectors.selectMyFeatureIsLoaded,
  (token: boolean) => {
    return token;
  }
);

/* User store selector */
export const selectErrorAdmin: MemoizedSelector<object, string> = createSelector(
  AdminStoreSelectors.selectMyFeatureError,
  (jokeError: string) => {
    return jokeError;
  }
);

export const selectIsLoadingAdmin: MemoizedSelector<
  object,
  boolean
> = createSelector(
  AdminStoreSelectors.selectMyFeatureIsLoading,
  (token: boolean) => {
    return token;
  }
);

export const selectIsLoadedAdmin: MemoizedSelector<
  object,
  boolean
> = createSelector(
  AdminStoreSelectors.selectMyFeatureIsLoaded,
  (token: boolean) => {
    return token;
  }
); 