import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { HomeStoreModule } from './home-store/home-store.module';
import { MdlStoreModule } from './mdl-store/mdl-store.module';
import { UserStoreModule } from './user-store/user-store.module';
import { GlobalStoreModule } from './global-store/global-store.module';
import { AdminStoreModule } from './admin-store/admin-store.module'; 


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forRoot({}),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
    }),
    HomeStoreModule,
    MdlStoreModule,
    UserStoreModule,
    GlobalStoreModule,
    AdminStoreModule
  ]
})
export class RootStoreModule { }
