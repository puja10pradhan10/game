import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { IGlobal } from '../../interfaces';

export const featureAdapter: EntityAdapter<IGlobal> = createEntityAdapter<IGlobal>({});

export interface State extends EntityState<IGlobal> {
  isLoading?: boolean;
  isLoaded?: boolean;
  error?: any;
}

export const initialState: State = featureAdapter.getInitialState(
  {
    isLoading: false,
    isLoaded: false,
    error: null
  }
);