import {
  createFeatureSelector,
  createSelector,
  MemoizedSelector
} from '@ngrx/store';
		
import { IGlobal } from '../../interfaces';

import { featureAdapter, State } from './state';



export const getError = (state: State): any => state.error;

export const getIsLoading = (state: State): boolean => state.isLoading;

export const getIsLoaded = (state: State): boolean => state.isLoaded;

export const selectMyFeatureState: MemoizedSelector<
  object,
  State
> = createFeatureSelector<State>('global');

export const selectAllMyFeatureItems: (
  state: object
) => IGlobal[] = featureAdapter.getSelectors(selectMyFeatureState).selectAll;

export const selectMyFeatureError: MemoizedSelector<object, any> = createSelector(
  selectMyFeatureState,
  getError
);

export const selectMyFeatureIsLoading: MemoizedSelector<
  object,
  boolean
> = createSelector(selectMyFeatureState, getIsLoading);

export const selectMyFeatureIsLoaded: MemoizedSelector<
  object,
  boolean
> = createSelector(selectMyFeatureState, getIsLoaded);