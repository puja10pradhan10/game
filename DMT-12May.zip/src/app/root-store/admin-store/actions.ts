import { Action } from '@ngrx/store';
import { IAdmin } from '../../interfaces';

export enum ActionTypes {
  LOAD_REQUEST = '[Admin] Load Request',
  LOAD_FAILURE = '[Admin] Load Failure',
  LOAD_SUCCESS = '[Admin] Load Success',
  LOAD_USER_REQUEST = '[LOAD_USER] Load Request',
  LOAD_USER_FAILURE = '[LOAD_USER] Load Failure',
  LOAD_USER_SUCCESS = '[LOAD_USER] Load Success',
  ADD_USER_REQUEST = '[ADD_USER] Load Request',
  ADD_USER_FAILURE = '[ADD_USER] Load Failure',
  ADD_USER_SUCCESS = '[ADD_USER] Load Success',
  EDIT_USER_REQUEST = '[EDIT_USER] Load Request',
  EDIT_USER_FAILURE = '[EDIT_USER] Load Failure',
  EDIT_USER_SUCCESS = '[EDIT_USER] Load Success'
}

export class LoadRequestAction implements Action {
  readonly type = ActionTypes.LOAD_REQUEST;
}

export class LoadFailureAction implements Action {
  readonly type = ActionTypes.LOAD_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class LoadSuccessAction implements Action {
  readonly type = ActionTypes.LOAD_SUCCESS;
  constructor(public payload: { items: any }) {}
}

// Load Users

export class LoadUserRequest implements Action {
  readonly type = ActionTypes.LOAD_USER_REQUEST;
}

export class LoadUserFailure implements Action {
  readonly type = ActionTypes.LOAD_USER_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class LoadUserSuccess implements Action {
  readonly type = ActionTypes.LOAD_USER_SUCCESS;
  constructor(public payload: { items: any }) {}
}

// ADD USER

export class AddUserRequest implements Action {
  readonly type = ActionTypes.ADD_USER_REQUEST;
}

export class AddUserFailure implements Action {
  readonly type = ActionTypes.ADD_USER_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class AddUserSuccess implements Action {
  readonly type = ActionTypes.ADD_USER_SUCCESS;
  constructor(public payload: { items: any }) {}
}


// EDIT USER

export class EditUserRequest implements Action {
  readonly type = ActionTypes.EDIT_USER_REQUEST;
}

export class EditUserFailure implements Action {
  readonly type = ActionTypes.EDIT_USER_FAILURE;
  constructor(public payload: { error: string }) {}
}

export class EditUserSuccess implements Action {
  readonly type = ActionTypes.EDIT_USER_SUCCESS;
  constructor(public payload: { items: any }) {}
}

export type Actions = LoadRequestAction | 
                      LoadFailureAction | 
                      LoadSuccessAction | 
                      LoadUserRequest | 
                      LoadUserFailure | 
                      LoadUserSuccess |
                      AddUserRequest | 
                      AddUserFailure | 
                      AddUserSuccess |                      
                      EditUserRequest | 
                      EditUserFailure | 
                      EditUserSuccess ;