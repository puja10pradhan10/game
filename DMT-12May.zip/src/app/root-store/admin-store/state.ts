import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { IAdmin } from '../../interfaces';


export const featureAdapter: EntityAdapter<IAdmin> = createEntityAdapter<IAdmin>({
  selectId: model => model.userId
});


export interface State extends EntityState<IAdmin> {
  isLoading?: boolean;
  isLoaded?: boolean;
  error?: any;
}

export const initialState: State = featureAdapter.getInitialState(
  {
    isLoading: false,
    isLoaded: false,
    error: null
  }
);