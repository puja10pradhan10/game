import { Actions, ActionTypes } from './actions';
import { featureAdapter, initialState, State } from './state';

export function adminReducer(state = initialState, action: Actions): State {
  switch (action.type) {
    
    case ActionTypes.LOAD_REQUEST: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
        error: null
      };
    }
    case ActionTypes.LOAD_SUCCESS: {
      return featureAdapter.addAll(action.payload.items, {
        ...state,
        isLoading: false,
        isLoaded: true,
        error: null
      });
    }
    case ActionTypes.LOAD_FAILURE: {
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        error: action.payload.error
      };
    }

    // Load USER  _____________________________________________

    case ActionTypes.LOAD_USER_REQUEST: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
        error: null
      };
    }
    case ActionTypes.LOAD_USER_SUCCESS: {
      return featureAdapter.addAll(action.payload.items, {
        ...state,
        isLoading: false,
        isLoaded: true,
        error: null
      });
    }
    case ActionTypes.LOAD_USER_FAILURE: {
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        error: action.payload.error
      };
    }

    // ADD USER  _____________________________________________

    case ActionTypes.ADD_USER_REQUEST: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
        error: null
      };
    }
    case ActionTypes.ADD_USER_SUCCESS: {
      return featureAdapter.addOne(action.payload.items, {
        ...state,
        isLoading: false,
        isLoaded: true,
        error: null
      });
    }
    case ActionTypes.ADD_USER_FAILURE: {
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        error: action.payload.error
      };
    }


    // EDIT USER  _____________________________________________

    case ActionTypes.EDIT_USER_REQUEST: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
        error: null
      };
    }
    case ActionTypes.EDIT_USER_SUCCESS: {
      return featureAdapter.updateOne(action.payload.items, {
        ...state,
        isLoading: false,
        isLoaded: true,
        error: null
      });
    }
    case ActionTypes.EDIT_USER_FAILURE: {
      return {
        ...state,
        isLoading: false,
        isLoaded: false,
        error: action.payload.error
      };
    }


    default: {
      return state;
    }
  }
}