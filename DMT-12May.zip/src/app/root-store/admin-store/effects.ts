import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of as observableOf } from 'rxjs';
import { catchError, map, startWith, switchMap } from 'rxjs/operators';
import { AdminService } from '../../modules/admin/services/admin.service';
import * as featureActions from './actions';

@Injectable()
export class AdminStoreEffects {
  constructor(private adminService: AdminService, private actions$: Actions) {}
/*
  @Effect()
  loadRequestEffect$: Observable<Action> = this.actions$.pipe(
    ofType<featureActions.LoadRequestAction>(
      featureActions.ActionTypes.LOAD_REQUEST
    ),
    startWith(new featureActions.LoadRequestAction()),
    switchMap(action =>
      this.adminService
        .getAllEmployees()
        .pipe(
          map(
            items =>
              new featureActions.LoadSuccessAction({
                items
              })
            ),
            catchError(error =>
              observableOf(new featureActions.LoadFailureAction({ error }))
            )
      	)
     )
  );

*/
  @Effect()
  loadUserRequestEffect$: Observable<Action> = this.actions$.pipe(
    ofType<featureActions.LoadUserRequest>(
      featureActions.ActionTypes.LOAD_USER_REQUEST
    ),
    startWith(new featureActions.LoadUserRequest()),
    switchMap(action =>
      this.adminService
        .LoadUsers()
        .pipe(
          map(
            items =>
              new featureActions.LoadUserSuccess({
                items
              })
            ),
            catchError(error =>
              observableOf(new featureActions.LoadUserFailure({ error }))
            )
      	)
     )
  );
/*
  @Effect()
  AddUserRequestEffect$: Observable<Action> = this.actions$.pipe(
    ofType<featureActions.AddUserRequest>(
      featureActions.ActionTypes.ADD_USER_REQUEST
    ),
    startWith(new featureActions.AddUserRequest()),
    switchMap(action =>
      this.adminService
        .AddUser()
        .pipe(
          map(
            items =>
              new featureActions.AddUserSuccess({
                items
              })
            ),
            catchError(error =>
              observableOf(new featureActions.AddUserFailure({ error }))
            )
      	)
     )
  );


  @Effect()
  EditUserRequestEffect$: Observable<Action> = this.actions$.pipe(
    ofType<featureActions.EditUserRequest>(
      featureActions.ActionTypes.EDIT_USER_REQUEST
    ),
    startWith(new featureActions.EditUserRequest()),
    switchMap(action =>
      this.adminService
        .UpdateUser()
        .pipe(
          map(
            items =>
              new featureActions.EditUserSuccess({
                items
              })
            ),
            catchError(error =>
              observableOf(new featureActions.EditUserFailure({ error }))
            )
      	)
     )
  );*/

}