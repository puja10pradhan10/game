import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { IUser } from '../../interfaces';
import { RootStoreState, UserStoreActions, UserStoreSelectors } from '../../root-store';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})

export class UserComponent implements OnInit {

  result$: Observable<IUser[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;

  mode = new FormControl('side');
  shouldRun = true;

  constructor(
    private store: Store<RootStoreState.State>
  ) { }

  ngOnInit() {

    this.error$ = this.store.select(
      UserStoreSelectors.selectMyFeatureError
    );

    this.isLoading$ = this.store.select(
      UserStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(UserStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);

    if (!this.isLoaded) {
      this.store.dispatch(new UserStoreActions.LoadRequestAction());
      this.result$ = this.store.select(UserStoreSelectors.selectAllMyFeatureItems);
      console.log("this.result$",this.result$);
    } else {
      this.result$ = this.store.select(UserStoreSelectors.selectAllMyFeatureItems);
      console.log("this.result$",this.result$);
    }

  }
}
