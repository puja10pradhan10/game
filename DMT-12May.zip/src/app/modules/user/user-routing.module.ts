import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';

import { AuthGuard } from './../../shared/guards/auth.guard';

const userRoutes: Routes = [
  { path:'', component: UserComponent } ,
  { path:'add-user', component: AddUserComponent } ,
  { path:'edit-user', component: EditUserComponent } ,
  { path:'delete-user', component: UserComponent } ,
  { path:'change-user', component: UserComponent } 
];

@NgModule({
  imports: [RouterModule.forChild(userRoutes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
