import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { UserStoreEffects } from '../../root-store/user-store/effects';
import { userReducer } from '../../root-store/user-store/reducer';



import { SharedModule } from '../../shared/shared.module';
import { UserComponent } from './user.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';

import { UserRoutingModule } from './user-routing.module';

@NgModule({
  declarations: [ UserComponent, AddUserComponent, EditUserComponent ],
  imports: [
    CommonModule,
    UserRoutingModule,
    StoreModule.forFeature('user', userReducer),
    EffectsModule.forFeature([UserStoreEffects]),
    SharedModule
  ]
})
export class UserModule { }
