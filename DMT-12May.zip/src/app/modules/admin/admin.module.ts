import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AdminStoreEffects } from '../../root-store/admin-store/effects';
import { adminReducer } from '../../root-store/admin-store/reducer';

import { SharedModule } from '../../shared/shared.module';
import { AdminComponent } from './admin.component';

import { DataManagementComponent } from './data-management/data-management.component';
import { RoleManagementComponent } from './role-management/role-management.component';
import { UserManagementComponent } from './user-management/user-management.component';
import { UserActivate } from './user-management/user-management.component';
import { UserDeactivate } from './user-management/user-management.component';

import { AdminRoutingModule } from './admin-routing.module';

@NgModule({
  declarations: [ AdminComponent, DataManagementComponent, RoleManagementComponent, UserManagementComponent, UserActivate, UserDeactivate  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    StoreModule.forFeature('admin', adminReducer),
    EffectsModule.forFeature([AdminStoreEffects]),
    SharedModule
  ],
  entryComponents: [UserActivate, UserDeactivate]
})
export class AdminModule { }
