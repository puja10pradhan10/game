import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AuthGuard } from './../../shared/guards/auth.guard';

const userRoutes: Routes = [
  { path:'', component: AdminComponent }
 /* { path:'add-user', component: AddUserComponent } ,
  { path:'edit-user', component: EditUserComponent } ,
  { path:'delete-user', component: AdminComponent } ,
  { path:'change-user', component: AdminComponent } */
];

@NgModule({
  imports: [RouterModule.forChild(userRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
