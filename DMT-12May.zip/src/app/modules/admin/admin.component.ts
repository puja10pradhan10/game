import { Component, OnInit,ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { IHome } from '../../interfaces';
import { RootStoreState, HomeStoreActions, HomeStoreSelectors } from '../../root-store';

@Component({
  selector: 'app-user',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})

export class AdminComponent implements OnInit {
  result$: Observable<IHome[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;
  mode = new FormControl('side');
  shouldRun = true;
  getMetadatajson:any = [];

  constructor(private store: Store<RootStoreState.State>) { }

  ngOnInit() {
    console.log("admin Loaded ngOnInit");
    this.error$ = this.store.select(
      HomeStoreSelectors.selectMyFeatureError
    );

    this.isLoading$ = this.store.select(
      HomeStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(HomeStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);

    if (!this.isLoaded) {
      console.log("admin Loaded");
      this.store.dispatch(new HomeStoreActions.LoadRequestAction());
      this.result$ = this.store.select(HomeStoreSelectors.selectAllMyFeatureItems);
      this.result$.subscribe(
        (getMetadata)=>{
     
              localStorage.setItem('getMetaData', JSON.stringify(getMetadata));
              console.log("getMetadatajson",getMetadata);
              this.getMetadatajson = JSON.parse(localStorage.getItem('getMetaData'));
         });

    } else {
      this.result$ = this.store.select(HomeStoreSelectors.selectAllMyFeatureItems);
    }

    this.getMetadatajson = JSON.parse(localStorage.getItem('getMetaData'));

  }
}
