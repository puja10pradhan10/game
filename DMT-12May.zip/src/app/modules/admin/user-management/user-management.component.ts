import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl,FormGroup,FormBuilder,Validators } from '@angular/forms';
import { MatPaginator, MatSort, MatTableDataSource, MatButtonToggleModule } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatChipsModule } from '@angular/material/chips';
import { Store } from '@ngrx/store';

import { IAdmin } from '../../../interfaces';
import { RootStoreState, AdminStoreActions, AdminStoreSelectors } from '../../../root-store';

import {merge, Observable, of as observableOf} from 'rxjs';
import {catchError, map, startWith, switchMap} from 'rxjs/operators';

import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatChipInputEvent} from '@angular/material';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.scss']
})

export class UserManagementComponent implements OnInit {

  userForm: FormGroup;
  submitted = false;
  
  formErrors = {
    'firstName': '',
    'lastName': '',
    'loginName':'',
    'testemail':'',
    'userRole':'',
    'region': '',
    'emptypeid': '',
    'department': '',
    'buildsite': ''
  };
  
  validationMessages = {
    'firstName': {
      'required': 'First Name is required.',
      'minlength': 'First Name must be greater than 2 characters.',
      'maxlength': 'First Name must be less than 10 characters.'
    },
    'lastName': {
      'required': 'Last Name is required.'
    },
    'loginName': {
      'required': 'Login Name is required.'
    },
    'email': {
      'required': 'Email is required.',
      'email': 'Email must be a valid email address.'
    },
    'userRole': {
      'required': 'User Role is required.'
    },
    'region': {
      'required': 'Region is required.'
    },
    'emptypeid': {
      'required': 'Employee Type id is required.'
    },
    'department': {
      'required': 'Department is required.'
    },
    'buildsite': {
      'required': 'Build Site is required.'
    },
  }


  result$: Observable<IAdmin[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;

  mode = new FormControl('side');
  shouldRun = true;

  displayedColumns: string[] = [ 'select' ,'empid', 'username', 'emailid', 'role', 'loginid', 'location', 'action'];
  //dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSource: MatTableDataSource<IAdmin>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selection = new SelectionModel<IAdmin>(true, []);

  constructor(private store: Store<RootStoreState.State>,public fb: FormBuilder,public dialog: MatDialog) {   
   }
 
  ngOnInit() {

    this.userForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
      lastName: ['', Validators.required],
      loginName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      userRole: ['', Validators.required],
      region: ['', Validators.required],
      emptypeid: ['', Validators.required],
      department: ['', Validators.required],
      buildsite: ['', Validators.required]
    });

   this.userForm.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.userForm);
    });



    
    this.error$ = this.store.select(
      AdminStoreSelectors.selectMyFeatureError
    );
    this.isLoading$ = this.store.select(
      AdminStoreSelectors.selectMyFeatureIsLoading
    );
    this.store.select(AdminStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);
    if (!this.isLoaded) {
      this.store.dispatch(new AdminStoreActions.LoadRequestAction());
      this.result$ = this.store.select(AdminStoreSelectors.selectAllMyFeatureItems);
    } else {
      this.result$ = this.store.select(AdminStoreSelectors.selectAllMyFeatureItems);
    }

    this.result$.subscribe(data => this.dataSource = new MatTableDataSource(data));
    
    this.dataSource.sort = this.sort;

  }

  ngAfterViewInit (){
    this.dataSource.sort = this.sort;
  }

  // convenience getter for easy access to form fields
  get f() { return this.userForm.controls; }

  onSubmit() {
      this.submitted = true;
      this.logValidationErrors(this.userForm,'onsubmit');
      // stop here if form is invalid
      if (this.userForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)')
  }

 checkError(){
    var finalArray = "";
    for (var key in this.formErrors) {
      if (this.formErrors.hasOwnProperty(key)) {
        finalArray = this.formErrors[key];

        return finalArray == '' ?  false : true;
      }
    }
 }

 logValidationErrors(group: FormGroup = this.userForm, status?:string): void {
    console.log("first ", this.userForm);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  openActiveDialog(): void {
    const dialogRef = this.dialog.open(UserActivate, {
      width: '600px',
      data: {name: 'test'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  openDeactiveDialog(): void {
    const dialogRef = this.dialog.open(UserDeactivate, {
      width: '600px',
      data: {name: 'test'}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: IAdmin): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.userId + 1}`;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}


@Component({
  selector: 'useractivate',
  templateUrl: './user-activate.html',
})
export class UserActivate {

  constructor(public dialogRef: MatDialogRef<UserActivate>) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}


export interface Fruit {
  name: string;
}
@Component({
  selector: 'userdeactivate',
  templateUrl: './user-deactivate.html',
})
export class UserDeactivate {

  constructor(public dialogRef: MatDialogRef<UserDeactivate>) {}

  onNoClick(): void {
    this.dialogRef.close();
  }


  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  fruits: Fruit[] = [
    {name: 'Lemon'},
    {name: 'Lime'},
    {name: 'Apple'},
  ];

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.fruits.push({name: value.trim()});
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(fruit: Fruit): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }


}