import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  api = environment.homURL;

  loadUser = environment.LoadUsers;
  addUser = environment.baseURL;
  updateUser = environment.baseURL;

  constructor(
    private http: HttpClient
  ) { }

  getAllEmployees() {
    return this.http.get(this.api);
  }
  LoadUsers() {
    return this.http.get(this.loadUser);
  }
  AddUser() {
    return this.http.get(this.addUser);
  }
  UpdateUser() {
    return this.http.get(this.updateUser);
  }

}
