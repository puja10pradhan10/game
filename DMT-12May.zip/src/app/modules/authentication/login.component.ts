import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { SharedComponent } from './../../shared/component/shared/shared.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent extends SharedComponent implements OnInit {
  loginObj = {};
  isError: boolean = false;
  constructor(
    private service: AuthService,
    private route: Router,
    private translate: TranslateService
  ) {
    super(translate)
   }

  ngOnInit() {

  }

  login() {
    this.service.loginUser(this.loginObj).subscribe(
      (response) => {
        sessionStorage.setItem('token', response.token);
        this.route.navigate(['/home']);
      },
      (error) => {
        this.isError = true;
      }
    )
  }
}
