import * as mdlActions from "../state/mdl.actions";
import { createFeatureSelector, createSelector } from "@ngrx/store";

import { EntityState, EntityAdapter, createEntityAdapter } from "@ngrx/entity";

import { Mdl } from "./../mdl-inteface.model";

import * as fromRoot from "../../state/app-state";

export interface MdlState extends EntityState<Mdl> {
  selectedCustomerId: number | null;
  loading: boolean;
  loaded: boolean;
  error: string;
}

export interface AppState extends fromRoot.AppState {
  mdls: MdlState;
}

export const mdlAdapter: EntityAdapter<Mdl> = createEntityAdapter<
  Mdl
>();

export const defaultMdl: MdlState = {
  ids: [],
  entities: {},
  selectedCustomerId: null,
  loading: false,
  loaded: false,
  error: ""
};

export const initialState = mdlAdapter.getInitialState(defaultMdl);

export function mdlReducer(
  state = initialState,
  action: mdlActions.Action
): MdlState {
  switch (action.type) {
    case mdlActions.MdlActionTypes.LOAD_CUSTOMERS_SUCCESS: {
      return mdlAdapter.addAll(action.payload, {
        ...state,
        loading: false,
        loaded: true
      });
    }
    case mdlActions.MdlActionTypes.LOAD_CUSTOMERS_FAIL: {
      return {
        ...state,
        entities: {},
        loading: false,
        loaded: false,
        error: action.payload
      };
    }
    case mdlActions.MdlActionTypes.LOAD_CUSTOMERS_Test_SUCCESS: {
      return mdlAdapter.addAll(action.payload, {
        ...state,
        loading: false,
        loaded: true
      });
    }
    case mdlActions.MdlActionTypes.LOAD_CUSTOMERS_Test_FAIL: {
      return {
        ...state,
        entities: {},
        loading: false,
        loaded: false,
        error: action.payload
      };
    }
	

    default: {
      return state;
    }
  }
}

const getMdlFeatureState = createFeatureSelector<MdlState>(
  "mdl"
);

export const getCustomers = createSelector(
  getMdlFeatureState,
  mdlAdapter.getSelectors().selectAll
);

export const getCustomersLoading = createSelector(
  getMdlFeatureState,
  (state: MdlState) => state.loading
);

export const getCustomersLoaded = createSelector(
  getMdlFeatureState,
  (state: MdlState) => state.loaded
);

export const getError = createSelector(
  getMdlFeatureState,
  (state: MdlState) => state.error
);

export const getCurrentCustomerId = createSelector(
  getMdlFeatureState,
  (state: MdlState) => state.selectedCustomerId
);
export const getCurrentCustomer = createSelector(
  getMdlFeatureState,
  getCurrentCustomerId,
  state => state.entities[state.selectedCustomerId]
);
