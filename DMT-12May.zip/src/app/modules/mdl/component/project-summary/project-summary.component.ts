import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
//import { default as _rollupMoment } from 'moment';


import { animate, state, style, transition, trigger } from '@angular/animations';

const moment = _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-project-summary',
  templateUrl: './project-summary.component.html',
  styleUrls: ['./project-summary.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ProjectSummaryComponent implements OnInit {

  selected = 'oci';
  //selected1 = 'option12';

  date = new FormControl(moment());

  constructor() { }

  ngOnInit() {
  }

  displayedColumns =
    ['statusDescriptions', 'week10', 'week9', 'week8', 'week7', 'week6', 'week5', 'week4', 'week3', 'week2', 'week1'];
  dataSource = ELEMENT_DATA;



  columnsToDisplay = ['statusDescriptions', 'week10', 'week9', 'week8', 'week7', 'week6', 'week5', 'week4', 'week3', 'week2', 'week1'];
  expandedElement: PeriodicElement | null;

}


export interface PeriodicElement {
  statusDescriptions: string;
  week10: number;
  week9: number;
  week8: number;
  week7: number;
  week6: number;
  week5: number;
  week4: number;
  week3: number;
  week2: number;
  week1: number;
  description: {};
}


const ELEMENT_DATA: PeriodicElement[] = [
  { statusDescriptions: 'Deleted Documents', week10: 104, week9: 104, week8: 104, week7: 104, week6: 104, week5: 104, week4: 104, week3: 104, week2: 104, week1: 104, description: [] },
  {
    statusDescriptions: 'Documents Information', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0,
    description: [
      { statusDescriptions: 'Approved as Submitted', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
      { statusDescriptions: 'Approved as Noted', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
      { statusDescriptions: 'Revise & Resubmit', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
      { statusDescriptions: 'Rejected', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
      { statusDescriptions: 'Info Only', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
    ]
  },

  // {statusDescriptions: 'Approved as Submitted', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
  // {statusDescriptions: 'Approved as Noted', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
  // {statusDescriptions: 'Revise & Resubmit', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
  // {statusDescriptions: 'Rejected', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },
  // {statusDescriptions: 'Info Only', week10: 0, week9: 0, week8: 0, week7: 0, week6: 0, week5: 0, week4: 0, week3: 0, week2: 0, week1: 0, },

  { statusDescriptions: 'Processing', week10: 1, week9: 1, week8: 1, week7: 1, week6: 1, week5: 1, week4: 1, week3: 1, week2: 1, week1: 1, description: [] },
  { statusDescriptions: 'Documents for Customer', week10: 222, week9: 222, week8: 222, week7: 222, week6: 222, week5: 222, week4: 222, week3: 222, week2: 222, week1: 222, description: [] },
  { statusDescriptions: 'Documents to be issued for Customer', week10: 148, week9: 148, week8: 148, week7: 148, week6: 148, week5: 148, week4: 148, week3: 148, week2: 148, week1: 148, description: [] },
  { statusDescriptions: 'Submisiion for Customer(%)', week10: 33.33, week9: 33.33, week8: 33.33, week7: 33.33, week6: 33.33, week5: 33.33, week4: 33.33, week3: 33.33, week2: 33.33, week1: 33.33, description: [] },
  { statusDescriptions: 'Internal Used', week10: 8, week9: 8, week8: 8, week7: 8, week6: 8, week5: 8, week4: 8, week3: 8, week2: 8, week1: 8, description: [] },
  { statusDescriptions: 'Internal Documents', week10: 361, week9: 361, week8: 361, week7: 361, week6: 361, week5: 361, week4: 361, week3: 361, week2: 361, week1: 361, description: [] },
  { statusDescriptions: 'Internal documents to be used', week10: 353, week9: 353, week8: 353, week7: 353, week6: 353, week5: 353, week4: 353, week3: 353, week2: 353, week1: 353, description: [] },
  { statusDescriptions: 'Internal Submisiion(%)', week10: 2.22, week9: 2.22, week8: 2.22, week7: 2.22, week6: 2.22, week5: 2.22, week4: 2.22, week3: 2.22, week2: 2.22, week1: 2.22, description: [] },
  { statusDescriptions: 'Overall Submisiion(%)', week10: 14.07, week9: 14.07, week8: 14.07, week7: 14.07, week6: 14.07, week5: 14.07, week4: 14.07, week3: 14.07, week2: 14.07, week1: 14.07, description: [] },
];



