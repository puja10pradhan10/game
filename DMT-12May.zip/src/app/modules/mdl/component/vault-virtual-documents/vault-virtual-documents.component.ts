import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vault-virtual-documents',
  templateUrl: './vault-virtual-documents.component.html',
  styleUrls: ['./vault-virtual-documents.component.scss']
})
export class VaultVirtualDocumentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
