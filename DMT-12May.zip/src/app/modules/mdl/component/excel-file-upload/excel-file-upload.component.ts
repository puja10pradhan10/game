import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-excel-file-upload',
  templateUrl: './excel-file-upload.component.html',
  styleUrls: ['./excel-file-upload.component.scss']
})
export class ExcelFileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
