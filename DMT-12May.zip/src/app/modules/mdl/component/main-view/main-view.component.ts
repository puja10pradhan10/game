import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatDialogRef, MatDialog } from '@angular/material';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IPost } from '../../../../interfaces';
import { IGlobal } from '../../../../interfaces';


import { RootStoreState, MdlStoreActions, MdlStoreSelectors } from '../../../../root-store';
import { GlobalStoreActions, GlobalStoreSelectors } from '../../../../root-store';

import { TranslateService } from '@ngx-translate/core';
import { SharedComponent } from './../../../../shared/component/shared/shared.component';

import { Overlay } from '@angular/cdk/overlay';

import * as mdlActions from "./../../state/mdl.actions";
import * as fromMdl from "./../../state/mdl.reducer";

@Component({
  selector: 'app-main-view',
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.scss']
})
export class MainViewComponent extends SharedComponent implements OnInit {


  result$: Observable<IPost[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;

  result_global$: Observable<IGlobal[]>;
  error_global$: Observable<any>;
  isLoading_global$: Observable<boolean>;
  isLoaded_global;

  mode = new FormControl('side');

  constructor(private store: Store<RootStoreState.State>, private translate: TranslateService, public dialog: MatDialog, private overlay: Overlay) {
    super(translate)

  }

  ngOnInit() {

    this.error$ = this.store.select(
      MdlStoreSelectors.selectMyFeatureError
    );

    this.isLoading$ = this.store.select(
      MdlStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(MdlStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);

    if (!this.isLoaded) {
      this.store.dispatch(new MdlStoreActions.LoadRequestAction());
      this.result$ = this.store.select(MdlStoreSelectors.selectAllMyFeatureItems);
    } else {
      this.result$ = this.store.select(MdlStoreSelectors.selectAllMyFeatureItems);
    }


    this.error_global$ = this.store.select(
      GlobalStoreSelectors.selectMyFeatureError
    );

    this.isLoading_global$ = this.store.select(
      GlobalStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(GlobalStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded_global = state);

    if (!this.isLoaded_global) {
      this.store.dispatch(new GlobalStoreActions.LoadRequestAction());
      this.result_global$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);
    } else {
      this.result_global$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);
    }

    this.store.dispatch(new mdlActions.LoadCustomersTest());


    this.store.select(fromMdl.getCustomers).subscribe(
      (data) => {
        // console.log(data);

      });
  }


}
