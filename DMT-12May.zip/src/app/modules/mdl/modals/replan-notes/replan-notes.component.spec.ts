import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplanNotesComponent } from './replan-notes.component';

describe('ReplanNotesComponent', () => {
  let component: ReplanNotesComponent;
  let fixture: ComponentFixture<ReplanNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReplanNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplanNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
