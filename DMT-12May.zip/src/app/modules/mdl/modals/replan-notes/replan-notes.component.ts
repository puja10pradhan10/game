import { Component, OnInit, Inject } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";

import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import { animate, state, style, transition, trigger } from '@angular/animations';

const moment = _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};



export interface replanNotesData {
  id: number;
  docNo: any;
  title: any;
  reason: any;
  date: any;
  replanNotes: any;
}

@Component({
  selector: 'app-replan-notes',
  templateUrl: './replan-notes.component.html',
  styleUrls: ['./replan-notes.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})


export class ReplanNotesComponent implements OnInit {

  date = new FormControl(moment());

  displayedColumns = ['docNo', 'title', 'reason', 'date', 'replanNotes', 'action']
  replanNotes: replanNotesData[] = [
    { id: 1, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
    { id: 2, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
    { id: 3, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
    { id: 4, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
    { id: 5, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
    { id: 6, docNo: 541234, title: 'Lorem Ipsum', reason: 'Lorem Ipsum', date: '24-FEB-2019', replanNotes: 1234321 },
  ]

  constructor(private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    console.log(this.data.checkedData)
  }

  close() {
    this.dialogRef.close();
  }
}
