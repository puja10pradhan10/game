import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";

export interface customerTransmittalData {
  id: number;
  transmittalNo: number;
  transmittalDate: any;
  reason: string;
  revision: string;
  custTrans: any;
  custDate: any;
  custStatus: string;
  suezStatus: string;
  statusDelay: any;
}

export interface revisionHistoryData {
  id: number;
  description: any;
  dueDate: any;
  promise: any;
  actual: any;
}

@Component({
  selector: 'app-mdl-history-modal',
  templateUrl: './mdl-history-modal.component.html',
  styleUrls: ['./mdl-history-modal.component.scss']
})
export class MdlHistoryModalComponent implements OnInit {

  displayedColumns = ['transmittalNo', 'transmittalDate', 'reason', 'revision', 'custTrans', 'custDate', 'custStatus', 'suezStatus', 'statusDelay', 'Action'];

  customerTransmittal: customerTransmittalData[] = [
    { id: 1, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '0' },
    { id: 2, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'PR', statusDelay: 53, suezStatus: 'n/a' },
    { id: 3, transmittalDate: '24-FEB-2019', reason: 'F1', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '65' },
    { id: 4, transmittalDate: '24-FEB-2019', reason: 'F2', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '45' },
    { id: 5, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'PR', statusDelay: 53, suezStatus: 'n/a' },
    { id: 6, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '0' },
    { id: 7, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'V', statusDelay: 53, suezStatus: '44' },
    { id: 8, transmittalDate: '24-FEB-2019', reason: 'F5', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '65' },
    { id: 9, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'PR', statusDelay: 53, suezStatus: 'n/a' },
    { id: 10, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'V', statusDelay: 53, suezStatus: '4' },
    { id: 11, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '82' },
    { id: 12, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'A', statusDelay: 53, suezStatus: '58' },
    { id: 13, transmittalDate: '24-FEB-2019', reason: 'F7', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'V', statusDelay: 53, suezStatus: '0' },
    { id: 14, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'PR', statusDelay: 53, suezStatus: 'n/a' },
    { id: 15, transmittalDate: '24-FEB-2019', reason: 'FA', revision: 'Lorem Ipsum', transmittalNo: 1234321, custTrans: 28, custDate: '25-FEB-2019', custStatus: 'S', statusDelay: 53, suezStatus: '7' }
  ];

  inr = 0;

  revHistorydisplayedColumns = ['description', 'dueDate', 'promise', 'actual', 'action']
  revisionHistory: revisionHistoryData[] = [
    { id: 1, dueDate: '24-FEB-2019', description: 'Lorem Ipsum', promise: 1234321, actual: 28 },
    { id: 2, dueDate: '24-FEB-2019', description: 'Lorem Ipsum', promise: 1234321, actual: 28 },
    { id: 3, dueDate: '24-FEB-2019', description: 'Lorem Ipsum', promise: 1234321, actual: 28 },
    { id: 4, dueDate: '24-FEB-2019', description: 'Lorem Ipsum', promise: 1234321, actual: 28 },
    { id: 5, dueDate: '24-FEB-2019', description: 'Lorem Ipsum', promise: 1234321, actual: 28 },
  ]

  revInr: number = 0;
  custInr: number = 0;
  VenInr: number = 0;
  VdlInr: number = 0;
  constructor(private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) data) { }

  ngOnInit() {
  }

  editCustTransHistory(val) {
    this.custInr = val;
  }

  editRevisionHistory(val) {
    this.revInr = val
  }
  editVendorHistory(val) {
    this.VenInr = val
  }
  editVDLItemHistory(val) {
    this.VdlInr = val
  }

  close() {
    this.dialogRef.close();
  }

}
