import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Mdl } from "./mdl-inteface.model";

@Injectable({
  providedIn: "root"
})
export class MdlService {
  private customersUrl = "https://jsonplaceholder.typicode.com/users";
   private customersUrl1 = "https://jsonplaceholder.typicode.com/users1";

  constructor(private http: HttpClient) {}

  getCustomers(): Observable<Mdl[]> {
    return this.http.get<Mdl[]>(this.customersUrl);
  }
  
  getCustomersForTest(): Observable<Mdl[]> {
    return this.http.get<Mdl[]>(this.customersUrl1);
  }
}
