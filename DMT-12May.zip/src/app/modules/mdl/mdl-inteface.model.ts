export interface Mdl{
  id?: number;
  name: string;
  phone: string;
  address: string;
  membership: string;
}
