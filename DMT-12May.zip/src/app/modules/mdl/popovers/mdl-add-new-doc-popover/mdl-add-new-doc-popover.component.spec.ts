import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MdlAddNewDocPopoverComponent } from './mdl-add-new-doc-popover.component';

describe('MdlAddNewDocPopoverComponent', () => {
  let component: MdlAddNewDocPopoverComponent;
  let fixture: ComponentFixture<MdlAddNewDocPopoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MdlAddNewDocPopoverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MdlAddNewDocPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
