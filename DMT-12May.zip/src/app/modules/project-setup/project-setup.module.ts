import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';

import { ProjectSetupComponent } from './project-setup.component';
import { AdditionalInfoComponent } from './additional-info/additional-info.component';
import { ProcurementComponent } from './procurement/procurement.component';
import { ProductionOrderComponent } from './production-order/production-order.component';
import { TransmittalSetupComponent } from './transmittal-setup/transmittal-setup.component';
import { ClientListComponent } from './transmittal-setup/client-list/client-list.component';
import { VendorListComponent } from './transmittal-setup/vendor-list/vendor-list.component';
import { ProductionListComponent } from './transmittal-setup/production-list/production-list.component';
import { AddRemoveComponenet } from './production-order/add-remove.component';
import { AddRemComponenet } from './procurement/addrem.component';

const projectSetupRoutes: Routes = [
  { 
    path: '',
    component: ProjectSetupComponent
  }
];

@NgModule({
  declarations: [
    ProjectSetupComponent,
    AdditionalInfoComponent,
    ProcurementComponent,
    ProductionOrderComponent,
    TransmittalSetupComponent,
    ClientListComponent,
    VendorListComponent,
    AddRemoveComponenet,
    AddRemComponenet,
    ProductionListComponent
  ],
  entryComponents: [AddRemoveComponenet,AddRemComponenet],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(projectSetupRoutes)
  ]
})
export class ProjectSetupModule {

 }
