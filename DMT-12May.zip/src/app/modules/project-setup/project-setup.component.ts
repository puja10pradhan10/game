import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import { MatTableDataSource,MatInputModule, MatButtonModule, MatAutocompleteModule,MatIconRegistry } from '@angular/material';
//import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import { SelectionModel } from '@angular/cdk/collections';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IGlobal } from '../../interfaces';
import { RootStoreState, GlobalStoreActions, GlobalStoreSelectors } from '../../root-store';

@Component({
  selector: 'app-project-setup',
  templateUrl: './project-setup.component.html',
  styleUrls: ['./project-setup.component.scss']
})

export class ProjectSetupComponent implements OnInit {

  options: FormGroup;
  isLinear = false;
  projectFormGroup: FormGroup;
  minDate = new Date(2000, 0, 1);
  maxDate = new Date(2020, 0, 1);
  
  result$: Observable<IGlobal[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;

  mode = new FormControl('side');
  shouldRun = true;

  projectStatus = {};

  submitted = false;
  formErrors = {
    'projectcodectrl': '',
    'prjnamectrl': '',
    'clnamectrl': '',
    'clpoctrl': '',
    'prStatus':'',
    'strdtctrl':''
  };

  validationMessages = {
    'projectcodectrl': {
      'required': 'Project code is required.'
    },
    'prjnamectrl': {
      'required': 'Project name is required.'
    },
    'clnamectrl': {
      'required': 'Client name is required.'
    },
    'clpoctrl': {
      'required': 'Client PO is required.'
    },    
    'prStatus': {
      'required': 'Project status is required.'
    },    
    'strdtctrl': {
      'required': 'Start date is required.'
    }
  }
 
   constructor(private store: Store<RootStoreState.State>, fb: FormBuilder, private _formBuilder: FormBuilder ) {
    this.options = fb.group({
      hideRequired: true,
      floatLabel: 'never',
    });
  }

  ngOnInit() {
    this.projectFormGroup = this._formBuilder.group({
      projectcodectrl: ['', Validators.required],
      prjnamectrl: ['', Validators.required],
      clnamectrl: ['', Validators.required],
      clpoctrl: ['', Validators.required],
      prStatus: ['', Validators.required],
      strdtctrl: ['', Validators.required]
    });

     this.projectFormGroup.valueChanges.subscribe((data) => {
      this.logValidationErrors(this.projectFormGroup);
    });

    this.result$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);
   
    this.result$.subscribe(
      (data: any)=>{
        this.projectStatus = data[10].ProjectStatus;   
       }); 

    
  }

  logValidationErrors(group: FormGroup = this.projectFormGroup, status?:string): void {
    console.log("first ", this.projectFormGroup);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.logValidationErrors(this.projectFormGroup,'onsubmit');
    // stop here if form is invalid
    if (this.projectFormGroup.invalid) {
        return;
    }

    alert('SUCCESS!! :-)')
} 

}



