import { Component, OnInit, Renderer2,ElementRef,ViewChild } from '@angular/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';

export interface PeriodicElement {
  fname: string;
  lname: string;
  toCC: any;
  email: string;
  actn: any;
  sclient: any;
}

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss']
})

export class ClientListComponent implements OnInit {
   ELEMENT_DATA: PeriodicElement[] = [
    {toCC: '', fname: 'Alberto', lname: 'Mejia', email: 'alberto.mejia@suez.com', actn: '',sclient:''},
    {toCC: '', fname: 'John', lname: 'Smith', email: 'john.smith@suez.com', actn: '',sclient:''},
    {toCC: '', fname: 'Peter', lname: 'Parker', email: 'peter.parker@suez.com', actn: '',sclient:''}
  ];

  //addData: PeriodicElement[] = this.ELEMENT_DATA; 

  displayedColumns: string[] = ['sclient','fname', 'lname', 'email', 'toCC', 'actn'];
  dataSource = new MatTableDataSource(this.ELEMENT_DATA);
  fnameval = '';
  lnameval = '';
  emailval = '';

  //firstName = new FormControl();
 


  addClientListRecord() {
    this.ELEMENT_DATA.push({sclient:'', toCC: '', fname: this.fnameval, lname: this.lnameval, email: this.emailval, actn: '',})
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
    this.fnameval = '';
    this.lnameval = '';
    this.emailval = '';
  }

addRow(){
    
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);

    const fnameinput = this.renderer.createElement('input');
    this.renderer.setAttribute(fnameinput, 'placeholder', 'enter first name');    
    //this.renderer.setAttribute(fnameinput, 'ng-model', 'fnameval');
   // this.renderer.setAttribute(fnameinput, 'formControlName', 'firstName');
    this.renderer.setAttribute(fnameinput, 'type', 'text');
    this.renderer.appendChild(this.fn.nativeElement, fnameinput);

    const lnameinput = this.renderer.createElement('input');
    this.renderer.setAttribute(lnameinput, 'placeholder', 'enter last name');
    this.renderer.setAttribute(lnameinput, 'type', 'text');
    this.renderer.appendChild(this.ln.nativeElement, lnameinput);

    const emailinput = this.renderer.createElement('input');
    this.renderer.setAttribute(emailinput, 'placeholder', 'enter email address');
    this.renderer.setAttribute(emailinput, 'type', 'text');
    this.renderer.appendChild(this.em.nativeElement, emailinput);
    
    /* this.firstName.valueChanges.subscribe((data) => {
      console.log("data",data);
   });  */
  }

  deleteClientListRecord(){
    this.ELEMENT_DATA.pop;
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
  }

  constructor(private renderer:Renderer2) {}
  @ViewChild('fn') fn:ElementRef;
  @ViewChild('ln') ln:ElementRef;
  @ViewChild('em') em:ElementRef;
  
  ngOnInit(){

}   


}



