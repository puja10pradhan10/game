import { Component, OnInit } from '@angular/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IGlobal } from '../../../interfaces';
import { RootStoreState, GlobalStoreActions, GlobalStoreSelectors } from '../../../root-store';

@Component({
  selector: 'app-transmittal-setup',
  templateUrl: './transmittal-setup.component.html',
  styleUrls: ['./transmittal-setup.component.scss']
})
export class TransmittalSetupComponent implements OnInit {
  options: FormGroup;
  transmittalsetupFormGroup: FormGroup;
  custfields = new FormControl();
  fieldsList: string[] = ['Client Doc Code	#1', 'Client Doc Code	#2', 'Client Document Number', 'Supplier Document Number', 'Ref Number'];
  
  result$: Observable<IGlobal[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;
  trtype = {};

  submitted = false;
  formErrors = {
    'trtype':'',
    'tadays':'',
    'sueztadays':'',
    'cladd':'',
    'fldcust':''
  };

  validationMessages = {
    'trtype': {
      'required': 'Transmittal type is required.'
    },
    'tadays': {
      'required': 'Client turn around days is required.'
    },
    'sueztadays': {
      'required': 'Suez turn around days is required.'
    },
    'cladd': {
      'required': 'Client address is required.'
    },
    'fldcust': {
      'required': 'Custom field is required.'
    }
  }

  constructor(private store: Store<RootStoreState.State>,fb: FormBuilder, private _formBuilder: FormBuilder ) {
    this.options = fb.group({
      hideRequired: true,
      floatLabel: 'never',
    });
  }

  ngOnInit() {
    this.transmittalsetupFormGroup = this._formBuilder.group({
      trtype: ['', Validators.required],
      tadays: ['', Validators.required],
      sueztadays: ['', Validators.required],
      cladd: ['', Validators.required],
      fldcust: ['', Validators.required]
    });


    this.result$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);

    this.result$.subscribe(
      (data: any)=>{
        this.trtype = data[11].TRFormTypeLookup;
       });

  }
  
  logValidationErrors(group: FormGroup = this.transmittalsetupFormGroup, status?:string): void {
    console.log("first ", this.transmittalsetupFormGroup);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.logValidationErrors(this.transmittalsetupFormGroup,'onsubmit');
    // stop here if form is invalid
    if (this.transmittalsetupFormGroup.invalid) {
        return;
    }
    alert('SUCCESS!! :-)')
}
}
