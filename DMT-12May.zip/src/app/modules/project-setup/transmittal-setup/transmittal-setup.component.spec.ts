import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransmittalSetupComponent } from './transmittal-setup.component';

describe('TransmittalSetupComponent', () => {
  let component: TransmittalSetupComponent;
  let fixture: ComponentFixture<TransmittalSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransmittalSetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransmittalSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
