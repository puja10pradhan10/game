import { Component, OnInit } from '@angular/core';
import {FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material';

export interface State {
  //addicon: string;
  firstname: string;
  lastname: string;
  email: string;
  id: number;
  enable: boolean;
}

export interface PeriodicElement {
  firstname: string;
  lastname: string;
  email: string;
  id: number;
  enable: boolean;
}

@Component({
  selector: 'app-vendor-list',
  templateUrl: './vendor-list.component.html',
  styleUrls: ['./vendor-list.component.scss']
})
export class VendorListComponent implements OnInit {

 stateCtrl = new FormControl();
 filteredNames: Observable<State[]>;

  ELEMENT_DATA: PeriodicElement[] = [];

 displayedColumns: string[] = ['fname', 'lname', 'email', 'actn'];
 dataSource = new MatTableDataSource(this.ELEMENT_DATA);

  states: State[] = [
    {
      firstname: 'John',
      lastname:'Smith',
      id: 1566117,
      email: 'john.s@suez.com',
      enable: true
    },
    {
      firstname: 'Smith',
      lastname:'John',
      id: 1234511,
      email: 'smith.j@suez.com',
      enable: true
    },
    {
      firstname: 'Alberto',
      lastname:'Mejia',
      id: 1458759,
      email: 'alberto.m@suez.com',
      enable: true
    },
    {
      firstname: 'Peter',
      lastname:'Parker',
      id: 1025854,
      email: 'peter.p@suez.com',
      enable: true
    },
    {
      firstname: 'John11',
      lastname:'Smith',
      id: 1566117,
      email: 'john.s@suez.com',
      enable: true
    },
    {
      firstname: 'Smith11',
      lastname:'John',
      id: 1234500,
      email: 'smith.j@suez.com',
      enable: true
    },
    {
      firstname: 'Alberto11',
      lastname:'Mejia',
      id: 1458745,
      email: 'alberto.m@suez.com',
      enable: true
    },
    {
      firstname: 'Peter11',
      lastname:'Parker',
      id: 1025343,
      email: 'peter.p@suez.com',
      enable: true
    }
  ];


  constructor() {
     this.filteredNames = this.stateCtrl.valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this._filteredNames(state) : this.states.slice())
      ); 
  }

  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // }

  private _filteredNames(value: string): State[] {
    const filterValue = value.toLowerCase();

    return this.states.filter(state => state.firstname.toLowerCase().indexOf(filterValue) === 0);
    //return this.states.filter(state => state.lastname.toLowerCase().indexOf(filterValue) === 0);
  }

  
  addVendorListRecord(id:number) {
    
    var that = this;
    this.states.forEach(function(element) {

      if(id == element.id){
        that.ELEMENT_DATA.push({
          firstname: element.firstname,
          lastname:element.lastname,
          id: element.id,
          email: element.email,
          enable:element.enable
        });
       that.filteredNames.subscribe(
        (data)=>{
              data.forEach(function(element,index) {
                  if(id == element.id){
                    data[index].enable = false;
                  }
              });
         }); 
      }
    });

  // console.log(this.ELEMENT_DATA);
    this.dataSource = new MatTableDataSource(this.ELEMENT_DATA);
    
    
  }


  ngOnInit() {
  }

}
