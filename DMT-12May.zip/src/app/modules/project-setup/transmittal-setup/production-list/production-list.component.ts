import { Component, OnInit } from '@angular/core';
import {FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

export interface State {
  //addicon: string;
  name: string;
  email: string;
  id: number;
}

@Component({
  selector: 'app-production-list',
  templateUrl: './production-list.component.html',
  styleUrls: ['./production-list.component.scss']
})
export class ProductionListComponent implements OnInit {

  stateCtrl = new FormControl();
 filteredStates: Observable<State[]>;

  states: State[] = [
    {
      name: 'John Smith',
      id: 1566117,
      email: 'john.s@suez.com'
    },
    {
      name: 'Smith John',
      id: 1234511,
      email: 'smith.j@suez.com'
    },
    {
      name: 'Alberto Mejia',
      id: 1458759,
      email: 'alberto.m@suez.com'
    },
    {
      name: 'Peter Parker',
      id: 1025854,
      email: 'peter.p@suez.com'
    }
  ];

  constructor() {
     this.filteredStates = this.stateCtrl.valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this._filterStates(state) : this.states.slice())
      ); 
  }


  private _filterStates(value: string): State[] {
    const filterValue = value.toLowerCase();

    return this.states.filter(state => state.name.toLowerCase().indexOf(filterValue) === 0);
  }

  ngOnInit() {
  }

}
