import { Component,ComponentFactoryResolver, ElementRef, TemplateRef, ViewChild, ViewContainerRef, OnInit } from '@angular/core';
import { FormControl,FormBuilder,FormGroup,Validators,FormArray } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IGlobal } from '../../../interfaces';
import { RootStoreState, GlobalStoreActions, GlobalStoreSelectors } from '../../../root-store';
import { AddRemoveComponenet } from './add-remove.component'

@Component({
  selector: 'app-production-order',
  templateUrl: './production-order.component.html',
  styleUrls: ['./production-order.component.scss']
})
export class ProductionOrderComponent implements OnInit {
  options: FormGroup;
  public productionorderFormGroup: FormGroup;
  result$: Observable<IGlobal[]>;
  submitted = false;
  formErrors = {
    'poordr':'',
    'bldlist':''
  };

  validationMessages = {
    'poordr': {
      'required': 'Production order is required.'
    },
    'bldlist': {
      'required': 'Build list is required.'
    }
  }

  //public invoiceForm: FormGroup;

  constructor(private store: Store<RootStoreState.State>,fb: FormBuilder, private _formBuilder: FormBuilder, private _fbb: FormBuilder,private _cfr: ComponentFactoryResolver ) {
    this.options = fb.group({
      hideRequired: true,
      floatLabel: 'never',
    });
  }
 

  @ViewChild('viewContainer', {read: ViewContainerRef}) viewContainer: ViewContainerRef;
  @ViewChild('template') template: TemplateRef<any>;


  @ViewChild('parent', { read: ViewContainerRef }) container: ViewContainerRef;

  insertView() {
    const template = this.template.createEmbeddedView(null);
    this.viewContainer.insert(template);
  }

  removeView() {
  }
  
  
  ngOnInit() {
    
    this.productionorderFormGroup = this._formBuilder.group({
      poordr: ['', Validators.required],
      bldlist: ['', Validators.required]
    });

    this.result$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);
    this.result$.subscribe(
      (data: any)=>{
        console.log("underproductionOrder.result$",data[10].ProjectStatus);
   
       }); 

       this.productionorderFormGroup = this._fbb.group({
        itemRows: this._fbb.array([this.initItemRows()])
      });

      this.addComponent();
  }
  addComponent(){
    
        var comp = this._cfr.resolveComponentFactory(AddRemoveComponenet);
        var expComponent = this.container.createComponent(comp);
        expComponent.instance._ref = expComponent;
  }

  get formArr() {
    return this.productionorderFormGroup.get('itemRows') as FormArray;
  }

  initItemRows() {
    return this._fbb.group({
      itemname: ['']
    });
  }

  addNewRow() {
    this.formArr.push(this.initItemRows());
  }

  deleteRow(index: number) {
    this.formArr.removeAt(index);
  }

  logValidationErrors(group: FormGroup = this.productionorderFormGroup, status?:string): void {
    console.log("first ", this.productionorderFormGroup);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.logValidationErrors(this.productionorderFormGroup,'onsubmit');
    // stop here if form is invalid
    if (this.productionorderFormGroup.invalid) {
        return;
    }

    alert('SUCCESS!! :-)')
}

}


