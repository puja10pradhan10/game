import { Component, OnInit } from '@angular/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { IGlobal } from '../../../interfaces';
import { RootStoreState, GlobalStoreActions, GlobalStoreSelectors } from '../../../root-store';

@Component({
  selector: 'app-additional-info',
  templateUrl: './additional-info.component.html',
  styleUrls: ['./additional-info.component.scss']
})
export class AdditionalInfoComponent implements OnInit {
  options: FormGroup;
  additionalinfoFormGroup: FormGroup;

  result$: Observable<IGlobal[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;
  marketdata = {};
  regiondata = {};
  groupdata = {};
  portfoliodata = {};

  submitted = false;
  formErrors = {
    'selmngr':'',
    'ldengr':'',
    'prjldr':'',
    'expdr':'',
    'dctrl':'',
    'sclengr':'',
    'mktplc':'',
    'regn':'',
    'portfl':'',
    'grp':'',
    'prjengln':''
  };

  validationMessages = {
    'selmngr': {
      'required': 'Project manager is required.'
    },
    'ldengr': {
      'required': 'Lead engineer is required.'
    },
    'prjldr': {
      'required': 'Project leader is required.'
    },
    'expdr': {
      'required': 'Expeditor is required.'
    },
    'dctrl': {
      'required': 'Document controller is required.'
    },
    'sclengr': {
      'required': 'Supply chain lead engineer is required.'
    },
    'mktplc': {
      'required': 'Market place is required.'
    },
    'regn': {
      'required': 'Region is required.'
    },
    'portfl': {
      'required': 'Portfolio is required.'
    },
    'grp': {
      'required': 'Group is required.'
    },
    'prjengln': {
      'required': 'Project engineer location is required.'
    }
  }
  
  constructor(private store: Store<RootStoreState.State>,fb: FormBuilder,private _formBuilder: FormBuilder) {
    this.options = fb.group({
      hideRequired: false,
      floatLabel: 'never',
    });
  }

  ngOnInit() {
    this.additionalinfoFormGroup = this._formBuilder.group({
      selmngr: ['', Validators.required],
      ldengr: ['', Validators.required],
      prjldr: ['', Validators.required],
      expdr: ['', Validators.required],
      dctrl: ['', Validators.required],
      sclengr: ['', Validators.required],
      mktplc: ['', Validators.required],
      regn: ['', Validators.required],
      portfl: ['', Validators.required],
      grp: ['', Validators.required],
      prjengln: ['', Validators.required]
    }); 


    this.result$ = this.store.select(GlobalStoreSelectors.selectAllMyFeatureItems);

    this.result$.subscribe(
      (data: any)=>{
        this.marketdata = data[4].MarketLookup;
        this.regiondata = data[7].RegionLookup;
        this.groupdata = data[3].GroupLookup;
        this.portfoliodata = data[6].PortfolioLookup;
       }); 
  }

  logValidationErrors(group: FormGroup = this.additionalinfoFormGroup, status?:string): void {
    console.log("first ", this.additionalinfoFormGroup);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.logValidationErrors(this.additionalinfoFormGroup,'onsubmit');
    // stop here if form is invalid
    if (this.additionalinfoFormGroup.invalid) {
        return;
    }

    alert('SUCCESS!! :-)')
}

}
