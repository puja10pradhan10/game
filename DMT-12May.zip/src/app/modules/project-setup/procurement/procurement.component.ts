import { Component, ElementRef, TemplateRef, ViewChild, ViewContainerRef, OnInit, ComponentFactoryResolver } from '@angular/core';
import { FormControl,FormBuilder,FormGroup,Validators } from '@angular/forms';
import { AddRemComponenet } from './addrem.component'

@Component({
  selector: 'app-procurement',
  templateUrl: './procurement.component.html',
  styleUrls: ['./procurement.component.scss']
})
export class ProcurementComponent implements OnInit {
  options: FormGroup;
  procurementFormGroup: FormGroup;
  submitted = false;
  formErrors = {
    'orgprjcrncy':'',
    'srcloc':'',
    //'prjcrncy':'',
    //'exrates':'',
    'budval':''
  };

  

  validationMessages = {
    'orgprjcrncy': {
      'required': 'Origional project currency is required.'
    },
    'srcloc': {
      'required': 'Sourcing location is required.'
    },
    // 'prjcrncy': {
    //   'required': 'Project currency is required.'
    // },
    // 'exrates': {
    //   'required': 'Exchange rate is required.'
    // },
    'budval': {
      'required': 'Budgeted value is required.'
    }
  }

  constructor(fb: FormBuilder, private _formBuilder: FormBuilder,private _cfr: ComponentFactoryResolver ) {
    this.options = fb.group({
      hideRequired: true,
      floatLabel: 'never',
    });
  }

  @ViewChild('viewContainer', {read: ViewContainerRef}) viewContainer: ViewContainerRef;
  @ViewChild('template') template: TemplateRef<any>;

  @ViewChild('parent', { read: ViewContainerRef }) container: ViewContainerRef;

  insertView1() {
    const template = this.template.createEmbeddedView(null);
    this.viewContainer.insert(template);
  }

  removeView() {
  }

  addCurr(){
    
    var comp = this._cfr.resolveComponentFactory(AddRemComponenet);
    var expComponent = this.container.createComponent(comp);
    expComponent.instance._ref = expComponent;
}
  ngOnInit() {
    this.procurementFormGroup = this._formBuilder.group({
      orgprjcrncy: ['', Validators.required],
      srcloc: ['', Validators.required],
     // prjcrncy: ['', Validators.required],
     // exrates: ['', Validators.required],
      budval: ['', Validators.required]
    });
  }

  logValidationErrors(group: FormGroup = this.procurementFormGroup, status?:string): void {
    console.log("first ", this.procurementFormGroup);
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      if (abstractControl instanceof FormGroup) {
        this.logValidationErrors(abstractControl);
      } else {
        this.formErrors[key] = '';

        if (abstractControl && !abstractControl.valid
            && (abstractControl.touched || abstractControl.dirty) && status != "onsubmit") {
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        } else if(abstractControl && !abstractControl.valid && status == "onsubmit"){
          const messages = this.validationMessages[key];
          for (const errorKey in abstractControl.errors) {
            if (errorKey) {
              this.formErrors[key] += messages[errorKey] + ' ';
            }
          }
        }

      }
    });
  }

  onSubmit() {
    this.submitted = true;
    this.logValidationErrors(this.procurementFormGroup,'onsubmit');
    // stop here if form is invalid
    if (this.procurementFormGroup.invalid) {
        return;
    }

    alert('SUCCESS!! :-)')
}

}
