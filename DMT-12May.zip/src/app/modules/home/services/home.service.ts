import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  api = environment.homURL;

  constructor(
    private http: HttpClient
  ) { }

  getAllEmployees() {
    return this.http.get(this.api);
  }
}
