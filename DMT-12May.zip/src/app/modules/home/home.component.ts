import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { IHome } from '../../interfaces';
import { RootStoreState, HomeStoreActions, HomeStoreSelectors } from '../../root-store';

import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  result$: Observable<IHome[]>;
  error$: Observable<any>;
  isLoading$: Observable<boolean>;
  isLoaded;

  mode = new FormControl('side');
  shouldRun = true;

  constructor(
    private store: Store<RootStoreState.State>
  ) { }

  ngOnInit() {
    console.log("Home Loaded ngOnInit");
    this.error$ = this.store.select(
      HomeStoreSelectors.selectMyFeatureError
    );

    this.isLoading$ = this.store.select(
      HomeStoreSelectors.selectMyFeatureIsLoading
    );

    this.store.select(HomeStoreSelectors.selectMyFeatureIsLoaded).subscribe((state) => this.isLoaded = state);

    if (!this.isLoaded) {
      console.log("Home Loaded");
      this.store.dispatch(new HomeStoreActions.LoadRequestAction());
      this.result$ = this.store.select(HomeStoreSelectors.selectAllMyFeatureItems);

      this.result$.subscribe(
        (getMetadata)=>{
     
              localStorage.setItem('getMetaData', JSON.stringify(getMetadata));
     
         }); 
     

    } else {
      this.result$ = this.store.select(HomeStoreSelectors.selectAllMyFeatureItems);
    }



  }
}
