import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';


import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { HomeStoreEffects } from '../../root-store/home-store/effects';
import { homeReducer } from '../../root-store/home-store/reducer';


import { SharedModule } from './../../shared/shared.module';
const HomeRoutes: Routes = [
  {
    path: '',
    component: HomeComponent
  }
];

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(HomeRoutes),
    StoreModule.forFeature('home', homeReducer),
    EffectsModule.forFeature([HomeStoreEffects]),
    SharedModule
  ]
})
export class HomeModule { }
