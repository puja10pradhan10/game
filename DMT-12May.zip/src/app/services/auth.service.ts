import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
 baseUrl = environment.baseURL;

 constructor(
    private http: HttpClient
 ) { }

  loginUser(user) {
    return this.http.post<any>(this.baseUrl+'api/login', user);
  }

  registerUser(user) {
    return this.http.post<any>(this.baseUrl+'api/register', user);
  }

  loggedIn() {
    return !!sessionStorage.getItem('token');
  }

  getToken() {
    return sessionStorage.getItem('token');
  }

}
