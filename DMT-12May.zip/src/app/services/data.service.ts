import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class DataService {
  constructor(private http: HttpClient) { }
  
  getData(url) {
    return this.http.get(url);
  }

  getPostData(url, payload) {
    return this.http.post(url, payload);
  }

  deletePostData(url, payload) {
    return this.http.delete(url, payload);
  }

  updatePostData(url, payload) {
    return this.http.patch(url, payload);
  }

  getMetaData(url) {
    return this.http.get(url);
  }
  
}