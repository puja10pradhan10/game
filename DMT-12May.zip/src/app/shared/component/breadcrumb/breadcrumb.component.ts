import { Component, OnInit } from '@angular/core';
import { SharedComponent } from './../shared/shared.component';

@Component({
  selector: 'app-breadc',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent extends SharedComponent implements OnInit {

  ngOnInit() {
  }

}
