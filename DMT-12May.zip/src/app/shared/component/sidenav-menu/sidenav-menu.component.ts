import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { SharedComponent } from './../shared/shared.component';

import {NestedTreeControl} from '@angular/cdk/tree';

import {MatTreeNestedDataSource} from '@angular/material/tree';



interface FoodNode {
  name: string;
  children?: FoodNode[];
}

const TREE_DATA: FoodNode[] = [
  {
    name: 'Dashboard'
  }, {
    name: 'Master Document List',
    children: [
      {
        name: 'Main view'
      },
      {
        name: 'Client Transmittal'
      }
    ]
  },
  {
    name: 'Vendor Document List',
    children: [
      {
        name: 'Green'
      },
    ]
  },
  {
    name: 'Purchase',
    children: [
      {
        name: 'Green'
      },
    ]
  },
  {
    name: 'Expediting',
    children: [
      {
        name: 'Green'
      },
    ]
  },
  {
    name: 'Reports',
    children: [
      {
        name: 'Green'
      },
    ]
  },
];

/**
 * @title Tree with nested nodes
 */


@Component({
  selector: 'app-sidenav-menu',
  templateUrl: './sidenav-menu.component.html',
  styleUrls: ['./sidenav-menu.component.scss']
})
export class SidenavMenuComponent extends SharedComponent implements OnInit {
  events = 'open'; 


  ngOnInit() {
  }

  onOpenedChange(e: boolean){
    console.log("Final open",e);
  }

  treeControl = new NestedTreeControl<FoodNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<FoodNode>();

  constructor(private translate: TranslateService) {
    super(translate);
    this.dataSource.data = TREE_DATA;
  }

  hasChild = (_: number, node: FoodNode) => !!node.children && node.children.length > 0;
}
