import { Component, OnInit } from '@angular/core';
import { SharedComponent } from './../shared/shared.component';


@Component({
  selector: 'app-ftr',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent extends SharedComponent implements OnInit {


  ngOnInit() {
  }

}
