import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { SharedComponent } from './../shared/shared.component';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent extends SharedComponent implements OnInit {

  constructor(private translate: TranslateService) {
    super(translate);

  }


  ngOnInit() {
  }

}
