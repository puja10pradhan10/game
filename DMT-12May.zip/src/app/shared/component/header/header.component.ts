import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { SharedComponent } from './../shared/shared.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent extends SharedComponent implements OnInit {

  userName = { value: 'Alberto Mejia' }
  constructor(private translate: TranslateService) {
    super(translate);

  }

  ngOnInit() {

  }

}
