import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.scss']
})
export class SharedComponent implements OnInit {

  constructor(public translateService: TranslateService) {
    let lang = 'en';
    if (lang != null) {
      translateService.use(lang);
      // translateService.setDefaultLang('en');

    } else {
      translateService.use(translateService.getBrowserLang());
    }
  }

  ngOnInit() {
  }

}
