import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {
  MatAutocompleteModule,
  MatNativeDateModule,
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,MatStepperModule,
  MatFormFieldModule, MatSortModule,MatChipsModule
} from '@angular/material';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatBadgeModule } from '@angular/material/badge';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material';
import { MatTreeModule } from '@angular/material/tree';

import { MdePopoverModule } from '@material-extended/mde';
import {MatDatepickerModule} from '@angular/material/datepicker';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { HeaderComponent } from './component/header/header.component';
import { SidenavMenuComponent } from './component/sidenav-menu/sidenav-menu.component';
import { TabsComponent } from './component/tabs/tabs.component';
import { BreadcrumbComponent } from './component/breadcrumb/breadcrumb.component';
import { SharedComponent } from './component/shared/shared.component';
import { FooterComponent } from './component/footer/footer.component';


export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    HeaderComponent,
    SidenavMenuComponent,
    TabsComponent,
    BreadcrumbComponent,
    SharedComponent,
    FooterComponent
  ],
  imports: [
    CommonModule,
    MatNativeDateModule,
    MatDialogModule,
    MatButtonModule,
    MatTreeModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatFormFieldModule,
    FormsModule, ReactiveFormsModule,
    MatExpansionModule,
    MatBadgeModule,
    MatTableModule,
    MatPaginatorModule, MatSortModule,
    MatAutocompleteModule,
    MdePopoverModule,
    MatDatepickerModule,MatChipsModule,MatStepperModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    })
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    SidenavMenuComponent,
    BreadcrumbComponent,
    TabsComponent,
    MatTreeModule,
    MatNativeDateModule,
    MatDialogModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatFormFieldModule,
    FormsModule, ReactiveFormsModule,
    MatExpansionModule,
    MatBadgeModule,
    MatTableModule,
    MatPaginatorModule, MatSortModule,MatStepperModule,
    MatAutocompleteModule,
    MdePopoverModule,MatChipsModule,
    TranslateModule,MatDatepickerModule]
})
export class SharedModule { }