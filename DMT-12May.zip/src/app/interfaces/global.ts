export interface IGlobal {
   id?      : string;
    ProjectStatus: [];
    MarketLookup:[];
    GroupLookup: [];
    PortfolioLookup:[];
    RegionLookup:[];
    TRFormTypeLookup:[];
}