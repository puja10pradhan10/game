export interface IPost {
    id?    : string;
    userId : string;
    title  : string;
    body   : string;
}