export interface IAdmin {
    userId: number;
    userFirstName: string;
    userLastName: string;
    roleId: object;
    userInitials: string;
    password: string;
    regionId: object;
    loginName: string;
    email: string;
    employeeTypeId: object;
    departmentId: object;
    isactive: boolean;
}

export interface UserData1 {
    empid: number;
    username: string;
    emailid: string;
    role : string;
    loginid : number;
    location : string;
    action : string;
  } 