import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RootStoreModule } from './root-store/root-store.module';
import { SharedModule } from './shared/shared.module';
import { AuthGuard } from './shared/guards/auth.guard';
import { AuthService } from './services/auth.service';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { TokenInterceptorService } from './services/token-interceptor.service';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { GlobalStoreEffects } from './root-store/global-store/effects';
import { globalReducer } from './root-store/global-store/reducer';
//import { RouterStoreModule } from '@ngrx/router-store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,   
    BrowserAnimationsModule, 
    HttpClientModule,
    RootStoreModule,    
    AppRoutingModule,
    SharedModule,
    StoreModule.forFeature('global', globalReducer),
    //StoreModule.provideStore(globalReducer),
    //RouterStoreModule.connectRouter(),
    //EffectsModule.run(GlobalStoreEffects),
    //StoreDevtoolsModule.instrumentOnlyWithExtension() 
    StoreDevtoolsModule.instrument({
      maxAge: 10
    }) 
  ],
  providers: [AuthGuard, AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent],
  exports:[]
})
export class AppModule { }
